"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharePointUploader = void 0;
const utils_1 = require("../utils");
const SharePoint_1 = require("./SharePoint/SharePoint");
class SharePointUploader {
    constructor(sharePointSettings) {
        this.sharePointSettings = sharePointSettings;
        this.uploadFile = (file, fileName, dir) => __awaiter(this, void 0, void 0, function* () {
            for (let tryNumber = 0; tryNumber < this.sharePointSettings.number_of_retries; tryNumber++) {
                try {
                    yield new Promise((resolve, reject) => {
                        this.storage.uploadFile(file, fileName, dir).then(resolve).catch(reject);
                        setTimeout(reject, this.sharePointSettings.upload_timeout_s * 1000);
                    });
                    return;
                }
                catch (err) {
                    console.warn(err);
                    if (tryNumber === this.sharePointSettings.number_of_retries - 1) {
                        throw new Error(`Failed to upload ${fileName}`);
                    }
                }
            }
        });
        this.storage = new SharePoint_1.SharePoint(sharePointSettings);
    }
    uploadImages(code, images) {
        return __awaiter(this, void 0, void 0, function* () {
            const dateInfo = (0, utils_1.getDate)();
            yield this.storage.authenticate();
            yield this.storage.createFolder(dateInfo.date);
            const stripedCode = (0, utils_1.stripCode)(code);
            return Promise.all(images.map((imageData) => this.uploadFile(imageData.file, `${dateInfo.dateTime}_${stripedCode}_${imageData.camera}.jpg`, `/${dateInfo.date}`)));
        });
    }
}
exports.SharePointUploader = SharePointUploader;
