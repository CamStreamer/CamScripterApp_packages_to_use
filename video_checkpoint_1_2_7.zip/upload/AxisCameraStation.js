"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AxisCameraStation = void 0;
const https = require("https");
const http = require("http");
const utils_1 = require("../utils");
class AxisCameraStation {
    constructor(acsSettings) {
        this.acsSettings = acsSettings;
    }
    sendEvent(text) {
        return new Promise((resolve, reject) => {
            const date = new Date();
            const year = date.getUTCFullYear();
            const month = (0, utils_1.pad)(date.getUTCMonth() + 1, 2);
            const day = (0, utils_1.pad)(date.getUTCDate(), 2);
            const hours = (0, utils_1.pad)(date.getUTCHours(), 2);
            const minutes = (0, utils_1.pad)(date.getUTCMinutes(), 2);
            const seconds = (0, utils_1.pad)(date.getUTCSeconds(), 2);
            const dateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
            const event = {
                addExternalDataRequest: {
                    occurrenceTime: dateString,
                    source: this.acsSettings.source_key,
                    externalDataType: 'videoCheckpoint',
                    data: {
                        Code: text,
                    },
                },
            };
            const eventData = JSON.stringify(event);
            const client = this.acsSettings.protocol === 'http' ? http : https;
            const req = client.request({
                method: 'POST',
                host: this.acsSettings.ip,
                port: this.acsSettings.port,
                path: '/Acs/Api/ExternalDataFacade/AddExternalData',
                auth: this.acsSettings.user + ':' + this.acsSettings.pass,
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': eventData.length,
                },
                rejectUnauthorized: this.acsSettings.protocol !== 'https_insecure',
                timeout: 10000,
            }, (res) => {
                if (res.statusCode === 200) {
                    resolve();
                }
                else {
                    reject(new Error(`ACS status code: ${res.statusCode}`));
                }
            });
            req.on('timeout', () => {
                reject(new Error('ACS connection timeout'));
                req.destroy();
            });
            req.on('error', reject);
            req.write(eventData);
            req.end();
        });
    }
}
exports.AxisCameraStation = AxisCameraStation;
