export type SensorData = {
    firmware: string;
    temp: number;
    humidity: number;
};
export declare class TempSensorReader {
    private usbDevices;
    readSensorData(): Promise<SensorData>;
    private getUsbDevices;
    private findDevices;
    private isKnownDevice;
    private readDeviceInfoFile;
    private readDeviceData;
    private readWithTimeout;
    private parseBytes;
}
