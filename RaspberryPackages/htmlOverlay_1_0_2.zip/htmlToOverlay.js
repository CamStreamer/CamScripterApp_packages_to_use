"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlToOverlay = void 0;
const puppeteer_core_1 = require("puppeteer-core");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
class HtmlToOverlay {
    constructor(options) {
        this.options = options;
        this.stopped = false;
        this.coConnected = false;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            this.stopped = false;
            if (this.options.enabled) {
                console.log('Start overlay: ' + this.options.configName);
                yield this.startBrowser();
            }
            else {
                this.removeImage();
                this.removeImageTimer = setInterval(() => this.removeImage(), 300000);
            }
        });
    }
    stop() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('Stop overlay: ' + this.options.configName);
            this.stopped = true;
            if (this.takeScreenshotPromise) {
                yield this.takeScreenshotPromise;
            }
            clearTimeout(this.startTimer);
            clearTimeout(this.screenshotTimer);
            clearTimeout(this.removeImageTimer);
            if (this.browser) {
                yield this.browser.close();
            }
            if (this.coConnected) {
                yield this.removeImage();
            }
        });
    }
    startBrowser() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.browser) {
                    yield this.browser.close();
                }
                this.browser = yield puppeteer_core_1.default.launch({
                    executablePath: '/usr/bin/chromium-browser',
                    args: ['--no-sandbox', '--disable-setuid-sandbox'],
                    ignoreHTTPSErrors: true,
                    handleSIGINT: false,
                    handleSIGTERM: false,
                });
                this.browser.on('disconnected', () => {
                    console.log('Browser disconnected');
                    this.restartBrowser();
                });
                this.page = yield this.browser.newPage();
                this.page.on('error', (err) => {
                    console.log('Page error', err);
                    this.restartBrowser();
                });
                this.page.on('close', () => {
                    console.log('Page closed');
                    this.restartBrowser();
                });
                yield this.page.setViewport({
                    width: this.options.imageSettings.renderWidth,
                    height: this.options.imageSettings.renderHeight,
                });
                console.log('Go to: ' + this.options.imageSettings.url);
                yield this.page.goto(this.options.imageSettings.url);
                this.takeScreenshotPromise = this.takeScreenshot();
            }
            catch (err) {
                this.restartBrowser();
            }
        });
    }
    restartBrowser() {
        if (!this.stopped) {
            this.startTimer = setTimeout(() => this.startBrowser(), 5000);
        }
    }
    takeScreenshot() {
        return __awaiter(this, void 0, void 0, function* () {
            let sleepTime = this.options.imageSettings.refreshRate;
            try {
                if (yield this.startCamOverlayConnection()) {
                    const startTime = Date.now();
                    const imageData = yield this.page.screenshot({ type: 'png', omitBackground: true });
                    const surface = (yield this.co.uploadImageData(imageData)).var;
                    const pos = this.computePosition(this.options.coSettings.coordSystem, this.options.coSettings.posX, this.options.coSettings.posY, this.options.imageSettings.renderWidth, this.options.imageSettings.renderHeight, this.options.coSettings.streamWidth, this.options.coSettings.streamHeight);
                    yield this.co.showCairoImageAbsolute(surface, pos.x, pos.y, this.options.coSettings.streamWidth, this.options.coSettings.streamHeight);
                    yield this.co.cairo('cairo_surface_destroy', surface);
                    const endTime = Date.now();
                    sleepTime = Math.max(5, sleepTime - endTime + startTime);
                }
            }
            catch (err) {
                console.error(err);
            }
            finally {
                this.screenshotTimer = setTimeout(() => {
                    this.takeScreenshotPromise = this.takeScreenshot();
                }, sleepTime);
            }
        });
    }
    removeImage() {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.startCamOverlayConnection()) {
                yield this.co.removeImage();
            }
        });
    }
    startCamOverlayConnection() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.coConnected && !this.coDowntimeTimer) {
                const serviceName = this.options.configName.length ? this.options.configName : 'htmlOverlay';
                this.co = new CamOverlayAPI_1.CamOverlayAPI({
                    tls: this.options.cameraSettings.protocol !== 'http',
                    tlsInsecure: this.options.cameraSettings.protocol === 'https_insecure',
                    ip: this.options.cameraSettings.ip,
                    port: this.options.cameraSettings.port,
                    auth: this.options.cameraSettings.user + ':' + this.options.cameraSettings.pass,
                    serviceName,
                    camera: this.options.coSettings.cameraList,
                });
                this.co.on('open', () => {
                    console.log('COAPI: connected');
                    this.coConnected = true;
                });
                this.co.on('error', (err) => {
                    console.log('COAPI-Error: ' + err);
                    this.coDowntimeTimer = setTimeout(() => {
                        this.coDowntimeTimer = undefined;
                    }, 5000);
                });
                this.co.on('close', () => {
                    console.log('COAPI-Error: connection closed');
                    this.coConnected = false;
                });
                yield this.co.connect();
            }
            return this.coConnected;
        });
    }
    computePosition(coordSystem, posX, posY, width, height, streamWidth, streamHeight) {
        let x = posX;
        let y = posY;
        switch (coordSystem) {
            case 'top_right':
                x = streamWidth - width - posX;
                break;
            case 'bottom_left':
                y = streamHeight - height - posY;
                break;
            case 'bottom_right':
                x = streamWidth - width - posX;
                y = streamHeight - height - posY;
                break;
        }
        return { x, y };
    }
}
exports.HtmlToOverlay = HtmlToOverlay;
