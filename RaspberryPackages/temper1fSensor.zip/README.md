# Temper1f sensor package
This package requires Python 3 to be installed on your device.