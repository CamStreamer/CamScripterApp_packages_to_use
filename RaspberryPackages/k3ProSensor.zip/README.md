# Temperature Checking Package
Driver CH340 Drivers  might be defective. Update your system and restart the device.


## Compatibility
Python 3 has to be installed on your device.