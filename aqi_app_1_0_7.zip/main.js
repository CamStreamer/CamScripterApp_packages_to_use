"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs/promises");
const url = require("url");
const follow_redirects_1 = require("follow-redirects");
const Painter_1 = require("camstreamerlib/CamOverlayPainter/Painter");
let settings;
let cam_width;
let cam_height;
let background;
let value;
let label;
let text;
let upperText;
let lowerText;
const fontColor = [1.0, 1.0, 1.0];
const codes = {
    good: {
        text: ['GOOD'],
        img_file: 'Good.png',
        color: [0, 153 / 255, 76 / 255],
    },
    moderate: {
        text: ['MODERATE'],
        img_file: 'Moderate.png',
        color: [1.0, 1.0, 51 / 255],
    },
    sensitive: {
        text: ['UNHEALTHY FOR', 'SENSITIVE GROUPS'],
        img_file: 'sensitive_groups.png',
        color: [1.0, 128 / 255, 0],
    },
    unhealthy: {
        text: ['UNHEALTHY'],
        img_file: 'Unhealthy.png',
        color: [1.0, 51 / 255, 51 / 255],
    },
    very_unhealthy: {
        text: ['VERY UNHEALTHY'],
        img_file: 'Very_Unhealthy.png',
        color: [102 / 255, 0, 204 / 255],
    },
    hazardous: {
        text: ['HAZARDOUS'],
        img_file: 'Hazardous.png',
        color: [153 / 255, 0, 0],
    },
    error: {
        text: ['ERROR'],
        img_file: 'Error.png',
        color: [0, 0, 0],
    },
};
function split(text) {
    if (text.length <= 19) {
        return [text];
    }
    const half = text.length / 2;
    let middle_space = -1;
    for (let f = 0; f < text.length; f += 1) {
        if (text[f] === ' ') {
            if (Math.abs(half - f) < Math.abs(half - middle_space)) {
                middle_space = f;
            }
            else {
                break;
            }
        }
    }
    if (middle_space === -1) {
        return [text];
    }
    else {
        return [text.substring(0, middle_space), text.substring(middle_space + 1)];
    }
}
function setCodeText() {
    var _a;
    (_a = settings.translation) !== null && _a !== void 0 ? _a : (settings.translation = {});
    for (const c in codes) {
        if (settings.translation[c] !== undefined && settings.translation[c] !== '') {
            codes[c].text = split(settings.translation[c]);
        }
    }
}
function registerResources(background) {
    for (const c in codes) {
        background.registerImage(codes[c].img_file, `${settings.serviceName}/${codes[c].img_file}`);
    }
    background.registerFont('OpenSans', 'OpenSans-Regular.ttf');
    background.registerFont('ComicSans', 'ComicSans.ttf');
    background.registerFont('GenShinGothic', 'GenShinGothic-Medium.ttf');
}
function sendRequest(send_url, auth) {
    return new Promise((resolve, reject) => {
        const parsedUrl = url.parse(send_url);
        const options = {
            method: 'GET',
            host: parsedUrl.hostname,
            port: parsedUrl.port,
            path: parsedUrl.path,
            headers: { Authorization: auth },
            timeout: 5000,
        };
        const req = follow_redirects_1.https.request(options, (res) => {
            res.setEncoding('utf8');
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            res.on('end', () => {
                if (res.statusCode !== 200) {
                    reject(new Error('Server returned status code: ' + res.statusCode + ', message: ' + data));
                }
                else {
                    resolve(data);
                }
            });
        });
        req.on('error', (e) => {
            reject(e);
        });
        req.end();
    });
}
function mapData(data) {
    var _a;
    let displayedValue;
    try {
        displayedValue = data.data.aqi;
    }
    catch (err) {
        displayedValue = undefined;
    }
    let code;
    if (displayedValue === undefined) {
        code = codes['error'];
    }
    else if (displayedValue <= 50) {
        code = codes['good'];
    }
    else if (displayedValue <= 100) {
        code = codes['moderate'];
    }
    else if (displayedValue <= 150) {
        code = codes['sensitive'];
    }
    else if (displayedValue <= 200) {
        code = codes['unhealthy'];
    }
    else if (displayedValue <= 300) {
        code = codes['very_unhealthy'];
    }
    else if (displayedValue > 300) {
        code = codes['hazardous'];
    }
    else {
        code = codes['error'];
    }
    if (code.text.length === 1) {
        upperText.disable();
        lowerText.disable();
        text.enable();
        text.setText(code.text[0], 'A_CENTER', 'TFM_SCALE');
    }
    else {
        upperText.enable();
        lowerText.enable();
        text.disable();
        upperText.setText(code.text[0], 'A_CENTER', 'TFM_SCALE');
        lowerText.setText(code.text[1], 'A_CENTER', 'TFM_SCALE');
    }
    value.setText((_a = displayedValue === null || displayedValue === void 0 ? void 0 : displayedValue.toString()) !== null && _a !== void 0 ? _a : '', 'A_CENTER', 'TFM_SCALE');
    label.setText(settings.display_location, 'A_CENTER', 'TFM_SCALE');
    background.setBgImage(code.img_file, 'fit');
}
function genLayout(background) {
    label = new Painter_1.Frame({
        x: 0,
        y: 10,
        height: 30,
        width: 272,
        text: '',
        fontColor: fontColor,
    });
    value = new Painter_1.Frame({
        x: 0,
        y: 35,
        height: 90,
        width: 272,
        text: '0',
        fontColor: fontColor,
    });
    text = new Painter_1.Frame({
        x: 3,
        y: 140,
        height: 30,
        width: 272,
        text: '',
        fontColor: fontColor,
    });
    upperText = new Painter_1.Frame({
        x: 3,
        y: 130,
        height: 25,
        width: 272,
        text: '',
        fontColor: fontColor,
        enabled: false,
    });
    lowerText = new Painter_1.Frame({
        x: 3,
        y: 160,
        height: 25,
        width: 272,
        text: '',
        fontColor: fontColor,
        enabled: false,
    });
    background.insert(value);
    background.insert(label);
    background.insert(text);
    background.insert(upperText);
    background.insert(lowerText);
    value.setFont(settings.font);
    label.setFont(settings.font);
    text.setFont(settings.font);
    upperText.setFont(settings.font);
    lowerText.setFont(settings.font);
}
function requestAQI(location, acc_token) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const api_url = 'https://api.waqi.info/feed/' + location + '/?token=' + acc_token;
            const data = yield sendRequest(api_url, '');
            return JSON.parse(data);
        }
        catch (error) {
            console.error('Cannot get data from AQI');
            console.error(error);
        }
    });
}
function oneAppPeriod() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const data = yield requestAQI(settings.location, settings.access_token);
            mapData(data);
            yield background.display(settings.scale / 100);
        }
        catch (error) {
            console.error(error);
        }
        setTimeout(oneAppPeriod, 5000);
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const data = yield fs.readFile(process.env.PERSISTENT_DATA_PATH + 'settings.json');
            settings = JSON.parse(data.toString());
            setCodeText();
            const resolution = settings.resolution.split('x');
            cam_width = parseInt(resolution[0]);
            cam_height = parseInt(resolution[1]);
        }
        catch (err) {
            console.error('No settings file found');
            return;
        }
        const options = {
            x: settings.pos_x,
            y: settings.pos_y,
            width: 280,
            height: 278,
            screenWidth: cam_width,
            screenHeight: cam_height,
            coAlignment: settings.coordinates,
        };
        const coOptions = {
            ip: settings.camera_ip,
            port: settings.camera_port,
            user: settings.camera_user,
            pass: settings.camera_pass,
            tls: settings.camera_protocol !== 'http',
            tlsInsecure: settings.camera_protocol === 'https_insecure',
        };
        background = new Painter_1.Painter(options, coOptions);
        registerResources(background);
        try {
            yield background.connect();
            genLayout(background);
            yield oneAppPeriod();
        }
        catch (_a) {
            console.error('COAPI-Error: connection error');
            process.exit(1);
        }
    });
}
void main();
process.on('unhandledRejection', (error) => {
    console.error('unhandledRejection', error);
    process.exit(1);
});
process.on('uncaughtException', (error) => {
    console.error('uncaughtException', error);
    process.exit(1);
});
