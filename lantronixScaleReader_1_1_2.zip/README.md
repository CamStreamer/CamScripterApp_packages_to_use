# Scale with Lantronix
Scripts values from scales via Lantronix device. The scales need to be prompted.

## Milestone
The package can trigger Milestone events.
This setting is optional as the code for Milestone update will be skipped if left valueless.
