"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const https = require("https");
const node_fetch_1 = require("node-fetch");
const schema_1 = require("./schema");
const Widget_1 = require("./graphics/Widget");
const utils_1 = require("./utils");
const constants_1 = require("./constants");
let settings;
let widget;
let airQualityReader = false;
let retryTimeout = null;
let dataBuffer = '';
let prevData = null;
let data = constants_1.DEFAULT_DATA;
function readSettings() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return schema_1.serverDataSchema.parse(JSON.parse(data.toString()));
    }
    catch (err) {
        console.log('Read settings error:', err instanceof Error ? err.message : 'unknown');
        process.exit(1);
    }
}
function watchAirQualityData() {
    var _a, e_1, _b, _c;
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Watching air quality data...');
        if (retryTimeout) {
            clearTimeout(retryTimeout);
            retryTimeout = null;
        }
        const isTlsInsecure = settings.source_camera.protocol === 'https_insecure';
        const protocol = isTlsInsecure ? 'https' : settings.source_camera.protocol;
        const url = `${protocol}://${settings.source_camera.ip}/axis-cgi/airquality/metadata.cgi`;
        const agent = new https.Agent({
            rejectUnauthorized: !isTlsInsecure,
        });
        try {
            const response = yield (0, node_fetch_1.default)(url, {
                headers: { Accept: 'text/event-stream' },
                agent: isTlsInsecure ? agent : undefined,
            });
            if (response.body === null) {
                console.error('No data:', response.statusText);
                return;
            }
            const decoder = new TextDecoder('utf-8');
            const stream = response.body;
            try {
                for (var _d = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield stream_1.next(), _a = stream_1_1.done, !_a;) {
                    _c = stream_1_1.value;
                    _d = false;
                    try {
                        const chunk = _c;
                        try {
                            if (typeof chunk === 'string') {
                                dataBuffer += chunk;
                                continue;
                            }
                            else {
                                dataBuffer += decoder.decode(chunk, { stream: true });
                            }
                            const lines = dataBuffer.split('\n');
                            if (lines.length < 2) {
                                continue;
                            }
                            const lineIndex = lines.length - 2;
                            const values = lines[lineIndex].split(', ').map((value) => value.split(' = '));
                            dataBuffer = lines[lines.length - 1];
                            const unit = settings.widget.units;
                            for (const v of values) {
                                const [key, value] = v;
                                if (key === 'Temperature') {
                                    data.Temperature = {
                                        value: (0, utils_1.getTemperature)(value, unit),
                                        severity: (0, utils_1.getSeverity)(key, parseFloat(value)),
                                    };
                                }
                                else {
                                    const typedKey = key;
                                    data[typedKey] = {
                                        value: Number(value) % 1 === 0 ? Number(value) : Number(value).toFixed(1),
                                        severity: (0, utils_1.getSeverity)(typedKey, Number(value)),
                                    };
                                }
                            }
                            const shouldUpdate = shouldUpdateWidget();
                            if (shouldUpdate) {
                                widget === null || widget === void 0 ? void 0 : widget.displayWidget(data, unit);
                            }
                        }
                        catch (err) {
                            console.error('Error processing stream data:', err);
                            break;
                        }
                    }
                    finally {
                        _d = true;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = stream_1.return)) yield _b.call(stream_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        catch (err) {
            console.error('Error fetching air quality data:', err);
        }
        finally {
            console.log('Restarting air quality data watcher...');
            retryTimeout = setTimeout(watchAirQualityData, 5000);
        }
    });
}
function shouldUpdateWidget() {
    if (prevData === null) {
        prevData = Object.assign({}, data);
        return true;
    }
    for (const key in data) {
        if (data[key].value !== prevData[key].value) {
            prevData = Object.assign({}, data);
            return true;
        }
    }
    return false;
}
function main() {
    try {
        settings = readSettings();
        if (settings.source_camera.ip.length !== 0 &&
            settings.source_camera.user.length !== 0 &&
            settings.source_camera.pass.length !== 0) {
            airQualityReader = true;
        }
        else {
            console.log('The Axis Air Quality Sensor is not configured and thus is disabled.');
        }
        if (settings.output_camera.ip.length !== 0 &&
            settings.output_camera.user.length !== 0 &&
            settings.output_camera.pass.length !== 0) {
            widget = new Widget_1.Widget(settings.output_camera, settings.widget);
        }
        else {
            console.log('The CamOverlay widget is not configured and thus is disabled.');
        }
        if (airQualityReader && widget) {
            watchAirQualityData();
        }
        console.log('Application started');
    }
    catch (err) {
        console.error('Application start:', err);
        process.exit(1);
    }
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
    console.error('Unhandled rejection:', err);
});
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received');
    process.exit(0);
});
process.on('SIGINT', () => {
    console.log('SIGINT signal received');
    process.exit(0);
});
main();
