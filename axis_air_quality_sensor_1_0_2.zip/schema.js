"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverDataSchema = exports.connectionParamsSchema = void 0;
const zod_1 = require("zod");
exports.connectionParamsSchema = zod_1.z.object({
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
    port: zod_1.z.number().positive().lt(65535),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
});
exports.serverDataSchema = zod_1.z.object({
    source_camera: exports.connectionParamsSchema,
    output_camera: exports.connectionParamsSchema,
    widget: zod_1.z.object({
        coord_system: zod_1.z.union([
            zod_1.z.literal('top_left'),
            zod_1.z.literal('top_right'),
            zod_1.z.literal('bottom_left'),
            zod_1.z.literal('bottom_right'),
        ]),
        pos_x: zod_1.z.number().nonnegative(),
        pos_y: zod_1.z.number().nonnegative(),
        stream_resolution: zod_1.z.string(),
        camera_list: zod_1.z.number().array().nonempty(),
        scale: zod_1.z.number().positive(),
        units: zod_1.z.union([zod_1.z.literal('C'), zod_1.z.literal('F')]),
    }),
});
