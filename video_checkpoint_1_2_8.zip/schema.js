"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverDataSchema = exports.connectionParamsSchema = void 0;
const zod_1 = require("zod");
exports.connectionParamsSchema = zod_1.z.object({
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
    port: zod_1.z.number().positive().lt(65535),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
});
exports.serverDataSchema = zod_1.z.object({
    barcode_validation_rule: zod_1.z.string(),
    conn_hub: exports.connectionParamsSchema,
    camera: exports.connectionParamsSchema.merge(zod_1.z.object({
        serial_number: zod_1.z.string(),
    })),
    output_camera: exports.connectionParamsSchema,
    image_upload: zod_1.z.object({
        camera_list: zod_1.z.number().array().nonempty(),
        resolution: zod_1.z.string(),
    }),
    video_upload: zod_1.z.object({
        prebuffer_sec: zod_1.z.number().nonnegative(),
        postbuffer_sec: zod_1.z.number().nonnegative(),
        timeout_enabled: zod_1.z.boolean(),
        timeout_sec: zod_1.z.number().positive(),
        closing_barcode_enabled: zod_1.z.boolean(),
        closing_barcode: zod_1.z.string(),
        starting_barcode_enabled: zod_1.z.boolean(),
        starting_barcode: zod_1.z.string(),
        camera_list: zod_1.z.number().array().nonempty(),
    }),
    widget: zod_1.z.object({
        coord_system: zod_1.z.union([
            zod_1.z.literal('top_left'),
            zod_1.z.literal('top_right'),
            zod_1.z.literal('bottom_left'),
            zod_1.z.literal('bottom_right'),
        ]),
        pos_x: zod_1.z.number().nonnegative(),
        pos_y: zod_1.z.number().nonnegative(),
        stream_resolution: zod_1.z.string(),
        camera_list: zod_1.z.number().array().nonempty(),
        scale: zod_1.z.number().positive(),
        visibility_time_sec: zod_1.z.number().positive(),
    }),
    axis_events: zod_1.z
        .object({
        conn_hub: zod_1.z.boolean(),
        camera: zod_1.z.boolean(),
    })
        .optional(),
    acs: exports.connectionParamsSchema.merge(zod_1.z.object({
        enabled: zod_1.z.boolean(),
        source_key: zod_1.z.string(),
    })),
    genetec: exports.connectionParamsSchema.merge(zod_1.z.object({
        enabled: zod_1.z.boolean(),
        base_uri: zod_1.z.string(),
        app_id: zod_1.z.string(),
        camera_list: zod_1.z.string().array(),
    })),
    milestone: zod_1.z.object({
        enabled: zod_1.z.boolean(),
        transaction_source: zod_1.z.string(),
        port: zod_1.z.number().positive().lt(65535),
    }),
    google_drive: zod_1.z.object({
        enabled: zod_1.z.boolean(),
        type: zod_1.z.string(),
        email: zod_1.z.union([zod_1.z.string().email(), zod_1.z.literal('')]),
        private_key: zod_1.z.string(),
        folder_id: zod_1.z.string(),
    }),
    ftp_server: exports.connectionParamsSchema.merge(zod_1.z.object({
        type: zod_1.z.string(),
        protocol: zod_1.z.literal('ftp'),
        enabled: zod_1.z.boolean(),
        upload_path: zod_1.z.string(),
    })),
    share_point: zod_1.z.object({
        enabled: zod_1.z.boolean(),
        url: zod_1.z.union([zod_1.z.string().url(), zod_1.z.literal('')]),
        output_dir: zod_1.z.string(),
        client_secret: zod_1.z.string(),
        client_id: zod_1.z.string(),
        tenant_id: zod_1.z.string(),
        connection_timeout_s: zod_1.z.number().nonnegative(),
        upload_timeout_s: zod_1.z.number().nonnegative(),
        number_of_retries: zod_1.z.number().nonnegative(),
    }),
    led: zod_1.z.object({
        enabled: zod_1.z.boolean(),
        led_green_port: zod_1.z.number().nonnegative().lt(100),
        led_red_port: zod_1.z.number().nonnegative().lt(100),
    }),
});
