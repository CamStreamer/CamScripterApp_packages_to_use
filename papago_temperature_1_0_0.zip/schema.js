"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = exports.papagoSchema = exports.cameraSchema = void 0;
const zod_1 = require("zod");
const connectionParams = {
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.string(),
    port: zod_1.z.number(),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
};
exports.cameraSchema = zod_1.z.object(Object.assign(Object.assign({}, connectionParams), { serviceID: zod_1.z.number(), fieldName: zod_1.z.string() }));
exports.papagoSchema = zod_1.z.object({
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.string(),
    port: zod_1.z.number(),
    portID: zod_1.z.string(),
    updateFrequency: zod_1.z.number(),
});
exports.settingsSchema = zod_1.z.object({
    camera: exports.cameraSchema,
    papago: exports.papagoSchema,
});
//# sourceMappingURL=schema.js.map