import { z } from 'zod';
export declare const cameraSchema: z.ZodObject<{
    serviceID: z.ZodNumber;
    fieldName: z.ZodString;
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodString;
    port: z.ZodNumber;
    user: z.ZodString;
    pass: z.ZodString;
}, "strip", z.ZodTypeAny, {
    serviceID: number;
    fieldName: string;
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
}, {
    serviceID: number;
    fieldName: string;
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
}>;
export declare const papagoSchema: z.ZodObject<{
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodString;
    port: z.ZodNumber;
    portID: z.ZodString;
    updateFrequency: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    portID: string;
    updateFrequency: number;
}, {
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    portID: string;
    updateFrequency: number;
}>;
export declare const settingsSchema: z.ZodObject<{
    camera: z.ZodObject<{
        serviceID: z.ZodNumber;
        fieldName: z.ZodString;
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodString;
        port: z.ZodNumber;
        user: z.ZodString;
        pass: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }, {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }>;
    papago: z.ZodObject<{
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodString;
        port: z.ZodNumber;
        portID: z.ZodString;
        updateFrequency: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        portID: string;
        updateFrequency: number;
    }, {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        portID: string;
        updateFrequency: number;
    }>;
}, "strip", z.ZodTypeAny, {
    camera: {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    };
    papago: {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        portID: string;
        updateFrequency: number;
    };
}, {
    camera: {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    };
    papago: {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        portID: string;
        updateFrequency: number;
    };
}>;
export type TCamera = z.infer<typeof cameraSchema>;
export type TPapago = z.infer<typeof papagoSchema>;
export type TSettings = z.infer<typeof settingsSchema>;
