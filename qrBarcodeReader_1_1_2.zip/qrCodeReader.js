"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QRCodeReader = void 0;
const EventEmitter = require("events");
const keyboardReader_1 = require("./keyboardReader");
class QRCodeReader extends EventEmitter {
    constructor() {
        super();
        this.keyboardReader = new keyboardReader_1.KeyboardReader();
        this.code = '';
        EventEmitter.call(this);
        this.keyboardReader.on('key_pressed', (keyInfo) => this.keyPressedCallback(keyInfo));
    }
    keyPressedCallback(keyInfo) {
        if (keyInfo.name !== 'ENTER') {
            this.code += keyInfo.char;
            return;
        }
        if (this.code.length !== 0) {
            this.emit('valid_reading', { code: this.code });
        }
        this.code = '';
    }
}
exports.QRCodeReader = QRCodeReader;
