"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const util = require("util");
const QRCode = require("qrcode");
const MemoryStream = require("memorystream");
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
const AxisCameraStationEvents_1 = require("camstreamerlib/events/AxisCameraStationEvents");
const qrCodeReader_1 = require("./qrCodeReader");
const setTimeoutPromise = util.promisify(setTimeout);
let co;
let acs;
let coConnected = false;
let barcodeFont = '';
let displayTimer;
let settings;
try {
    const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
    settings = JSON.parse(data.toString());
}
catch (err) {
    console.log('No settings file found');
    process.exit(1);
}
const coConfigured = settings.camera_ip.length !== 0 && settings.camera_user.length !== 0 && settings.camera_pass.length !== 0;
const acsConfigured = settings.acs_ip.length != 0 &&
    settings.acs_user.length != 0 &&
    settings.acs_pass.length != 0 &&
    settings.acs_source_key.length != 0;
function start() {
    const qrCodeReader = new qrCodeReader_1.QRCodeReader();
    qrCodeReader.on('valid_reading', (data) => {
        console.log('valid reading: ', data);
        displayGraphics(data.code);
        sendAcsEvent(data.code);
    });
}
function displayGraphics(text) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (!coConfigured) {
                return;
            }
            if (yield initCamOverlay()) {
                if (settings.widget_graphic_type === 'qr_code') {
                    yield createQrCodeWidget(text);
                }
                else {
                    yield createBarcodeWidget(text);
                }
                clearTimeout(displayTimer);
                if (settings.widget_visibility_time !== 0) {
                    displayTimer = setTimeout(() => {
                        if (co) {
                            co.removeImage();
                        }
                        displayTimer = undefined;
                    }, settings.widget_visibility_time * 1000);
                }
            }
        }
        catch (err) {
            console.error('Update image: ', err instanceof Error ? err.message : 'Unknown Error');
        }
    });
}
function initCamOverlay() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!coConnected) {
            co = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI({
                tls: settings.camera_protocol !== 'http',
                tlsInsecure: settings.camera_protocol === 'https_insecure',
                ip: settings.camera_ip,
                port: settings.camera_port,
                user: settings.camera_user,
                pass: settings.camera_pass,
                camera: settings.widget_camera_list,
            });
            co.on('open', () => {
                console.log('COAPI: connected');
                coConnected = true;
                uploadFont();
            });
            co.on('error', (err) => {
                console.log('COAPI-Error: ' + err);
            });
            co.on('close', () => {
                console.log('COAPI-Error: connection closed');
                coConnected = false;
            });
            yield co.connect();
            yield setTimeoutPromise(1000);
        }
        return coConnected;
    });
}
function createQrCodeWidget(text) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!co) {
            return;
        }
        const widgetWidth = Math.round(300 * settings.widget_scale);
        const widgetHeight = Math.round(320 * settings.widget_scale);
        const surfaceResponse = (yield co.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', widgetWidth, widgetHeight));
        const surface = surfaceResponse.var;
        const cairoResponse = (yield co.cairo('cairo_create', surface));
        const cairo = cairoResponse.var;
        const imageDataBuffer = yield generateQrCode(text, widgetWidth);
        const imgResponse = (yield co.uploadImageData(imageDataBuffer));
        const qrImage = imgResponse.var;
        co.cairo('cairo_translate', cairo, 0, 0);
        co.cairo('cairo_set_source_surface', cairo, qrImage, 0, 0);
        co.cairo('cairo_paint', cairo);
        co.cairo('cairo_scale', cairo, settings.widget_scale, settings.widget_scale);
        co.cairo('cairo_rectangle', cairo, 0, 300, 300, 20);
        co.cairo('cairo_set_source_rgb', cairo, 1.0, 1.0, 1.0);
        co.cairo('cairo_fill', cairo);
        co.cairo('cairo_stroke', cairo);
        co.cairo('cairo_set_source_rgb', cairo, 0.0, 0.0, 0.0);
        co.writeText(cairo, text, 5, 270, 290, 30, 'A_CENTER', 'TFM_SCALE');
        const pos = computePosition(settings.widget_coord_system, settings.widget_pos_x, settings.widget_pos_y, widgetWidth, widgetHeight, settings.widget_stream_width, settings.widget_stream_height);
        yield co.showCairoImageAbsolute(surface, pos.x, pos.y, settings.widget_stream_width, settings.widget_stream_height);
        co.cairo('cairo_surface_destroy', qrImage);
        co.cairo('cairo_surface_destroy', surface);
        co.cairo('cairo_destroy', cairo);
    });
}
function createBarcodeWidget(text) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!co) {
            return;
        }
        const widgetWidth = Math.round(600 * settings.widget_scale);
        const widgetHeight = Math.round(130 * settings.widget_scale);
        const surfaceResponse = (yield co.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', widgetWidth, widgetHeight));
        const surface = surfaceResponse.var;
        const cairoResponse = (yield co.cairo('cairo_create', surface));
        const cairo = cairoResponse.var;
        co.cairo('cairo_set_font_face', cairo, barcodeFont);
        co.cairo('cairo_set_font_size', cairo, 70);
        const textExtents = (yield co.cairo('cairo_text_extents', cairo, `*${text}*`)).var;
        const margin = 60;
        const barcodeWidth = Math.min(600 - margin, textExtents.width);
        co.cairo('cairo_scale', cairo, settings.widget_scale, settings.widget_scale);
        co.cairo('cairo_rectangle', cairo, 0, 0, barcodeWidth + margin, 320);
        co.cairo('cairo_set_source_rgb', cairo, 1.0, 1.0, 1.0);
        co.cairo('cairo_fill', cairo);
        co.cairo('cairo_stroke', cairo);
        const textPos = margin / 2;
        co.cairo('cairo_set_font_face', cairo, barcodeFont);
        co.cairo('cairo_set_font_size', cairo, 70);
        co.cairo('cairo_set_source_rgb', cairo, 0.0, 0.0, 0.0);
        co.writeText(cairo, `*${text}*`, textPos, 5, barcodeWidth, 70, 'A_CENTER', 'TFM_SCALE');
        co.cairo('cairo_set_font_face', cairo, 'NULL');
        co.writeText(cairo, text, textPos, 80, barcodeWidth, 30, 'A_CENTER', 'TFM_SCALE');
        const pos = computePosition(settings.widget_coord_system, settings.widget_pos_x, settings.widget_pos_y, (barcodeWidth + margin) * settings.widget_scale, widgetHeight, settings.widget_stream_width, settings.widget_stream_height);
        yield co.showCairoImageAbsolute(surface, pos.x, pos.y, settings.widget_stream_width, settings.widget_stream_height);
        co.cairo('cairo_surface_destroy', surface);
        co.cairo('cairo_destroy', cairo);
    });
}
function generateQrCode(text, size) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve) => {
            const chunks = [];
            const memStream = new MemoryStream();
            memStream.on('data', (chunk) => {
                chunks.push(chunk);
            });
            memStream.on('end', () => {
                resolve(Buffer.concat(chunks));
            });
            QRCode.toFileStream(memStream, text, {
                color: {
                    dark: '#000000',
                    light: '#FFFFFF',
                },
                width: size,
            });
        });
    });
}
function uploadFont() {
    return __awaiter(this, void 0, void 0, function* () {
        if (co) {
            const imgData = fs.readFileSync('fre3of9x.ttf');
            const fontRes = yield co.uploadFontData(imgData);
            barcodeFont = fontRes.var;
        }
    });
}
function computePosition(coordSystem, posX, posY, width, height, streamWidth, streamHeight) {
    let x = posX;
    let y = posY;
    switch (coordSystem) {
        case 'top_right':
            x = streamWidth - width - posX;
            break;
        case 'bottom_left':
            y = streamHeight - height - posY;
            break;
        case 'bottom_right':
            x = streamWidth - width - posX;
            y = streamHeight - height - posY;
            break;
    }
    return { x, y };
}
function initAcs() {
    if (acs === undefined && acsConfigured) {
        acs = new AxisCameraStationEvents_1.AxisCameraStationEvents(settings.acs_source_key, {
            tls: settings.acs_protocol !== 'http',
            tlsInsecure: settings.acs_protocol === 'https_insecure',
            ip: settings.acs_ip,
            port: settings.acs_port,
            user: settings.acs_user,
            pass: settings.acs_pass,
        });
    }
}
function sendAcsEvent(text) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (!acsConfigured) {
                return;
            }
            initAcs();
            yield acs.sendEvent({
                timestamp: Math.floor(Date.now() / 1000).toString(),
                text,
            }, 'qrBarCodeReader');
        }
        catch (err) {
            console.error('Send ACS event: ', err instanceof Error ? err.message : 'Unknown Error');
        }
    });
}
process.on('SIGINT', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('Configuration changed');
    cleanExit();
}));
process.on('SIGTERM', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('App exit');
    cleanExit();
}));
function cleanExit() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (co && coConnected) {
                yield co.removeImage();
            }
        }
        catch (err) {
            console.error('Hide graphics: ', err);
        }
        finally {
            process.exit();
        }
    });
}
console.log('App started');
if (coConfigured || acsConfigured) {
    start();
}
else {
    console.log('Application is not configured');
    process.exit(1);
}
