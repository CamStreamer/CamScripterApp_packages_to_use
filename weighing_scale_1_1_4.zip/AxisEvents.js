"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AxisEvents = void 0;
const CamScripterAPICameraEventsGenerator_1 = require("camstreamerlib/CamScripterAPICameraEventsGenerator");
class AxisEvents {
    constructor(cscConnectionParams) {
        this.cscEventDeclared = false;
        this.csc = new CamScripterAPICameraEventsGenerator_1.CamScripterAPICameraEventsGenerator({
            tls: cscConnectionParams.protocol !== 'http',
            tlsInsecure: cscConnectionParams.protocol === 'https_insecure',
            ip: cscConnectionParams.ip,
            port: cscConnectionParams.port,
            user: cscConnectionParams.user,
            pass: cscConnectionParams.pass,
        });
        this.connectCameraEvents();
    }
    sendEvent(active) {
        if (!this.cscEventDeclared) {
            throw new Error('AxisEvents: CSc API disconnected');
        }
        return this.csc.sendEvent({
            declaration_id: 'WeighingScaleIntegration',
            event_data: [
                {
                    namespace: '',
                    key: 'condition_active',
                    value: active,
                    value_type: 'BOOL',
                },
            ],
        });
    }
    connectCameraEvents() {
        this.csc.removeAllListeners();
        this.csc.on('open', () => __awaiter(this, void 0, void 0, function* () {
            try {
                console.log('CSc: connected');
                yield this.declareCameraEvent();
                this.cscEventDeclared = true;
            }
            catch (err) {
                console.error('AxisEvents: connectCameraEvents:', err);
            }
        }));
        this.csc.on('error', (err) => {
            console.log('CSc-Error: ' + err);
        });
        this.csc.on('close', () => {
            console.log('CSc-Error: connection closed');
            this.cscEventDeclared = false;
        });
        this.csc.connect();
    }
    declareCameraEvent() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.csc.declareEvent({
                declaration_id: 'WeighingScaleIntegration',
                stateless: false,
                declaration: [
                    {
                        namespace: 'tnsaxis',
                        key: 'topic0',
                        value: 'CameraApplicationPlatform',
                        value_type: 'STRING',
                    },
                    {
                        namespace: 'tnsaxis',
                        key: 'topic1',
                        value: 'CamScripter',
                        value_type: 'STRING',
                    },
                    {
                        namespace: 'tnsaxis',
                        key: 'topic2',
                        value: 'WeighingScaleIntegration',
                        value_type: 'STRING',
                        value_nice_name: 'CamScripter: WeighingScaleIntegration',
                    },
                    {
                        type: 'DATA',
                        namespace: '',
                        key: 'condition_active',
                        value: false,
                        value_type: 'BOOL',
                        key_nice_name: 'React on active condition (settings in the script)',
                        value_nice_name: 'Condition is active',
                    },
                ],
            });
        });
    }
}
exports.AxisEvents = AxisEvents;
