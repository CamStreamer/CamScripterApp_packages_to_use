"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isConditionActive = exports.pad = void 0;
function pad(num, size) {
    const sign = Math.sign(num) === -1 ? '-' : '';
    return (sign +
        new Array(size)
            .concat([Math.abs(num)])
            .join('0')
            .slice(-size));
}
exports.pad = pad;
function isConditionActive(weight, operator, conditionValue) {
    switch (operator) {
        case 0:
            return weight === conditionValue;
        case 1:
            return weight > conditionValue;
        case 2:
            return weight < conditionValue;
        case 3:
            return weight >= conditionValue;
        case 4:
            return weight <= conditionValue;
        default:
            return false;
    }
}
exports.isConditionActive = isConditionActive;
