"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const net = require("net");
const AxisCameraStation_1 = require("./AxisCameraStation");
const AxisEvents_1 = require("./AxisEvents");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
const utils_1 = require("./utils");
let settings;
let prevWeightData = null;
let dataBuffer = '';
let co;
let acs;
let acsEventConditionTimer = null;
let acsEventSendTimeStamp = null;
let axisEvents;
let axisEventsConditionTimer = null;
let axisEventsSentActiveState = false;
function readSettings() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return JSON.parse(data.toString());
    }
    catch (err) {
        console.log('Read settings error:', err instanceof Error ? err.message : 'unknown');
        process.exit(1);
    }
}
function sendAcsEventTimerCallback(weight, unit) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`Send ACS event, weight: ${weight} ${unit}`);
            yield (acs === null || acs === void 0 ? void 0 : acs.sendEvent(weight, unit));
            acsEventSendTimeStamp = Date.now();
        }
        catch (err) {
            console.error('ACS error:', err);
            acsEventConditionTimer = setTimeout(() => sendAcsEventTimerCallback(weight, unit), 5000);
        }
    });
}
function checkCondtionAndSendAcsEvent(weight, unit) {
    try {
        const conditionActive = (0, utils_1.isConditionActive)(Number.parseInt(weight), settings.acs.condition_operator, Number.parseInt(settings.acs.condition_value));
        if (conditionActive) {
            if (acsEventConditionTimer) {
                if (acsEventSendTimeStamp !== null &&
                    settings.acs.repeat_after !== 0 &&
                    Date.now() - acsEventSendTimeStamp >= settings.acs.repeat_after * 1000) {
                    clearTimeout(acsEventConditionTimer);
                    void sendAcsEventTimerCallback(weight, unit);
                }
            }
            else {
                const timerTime = settings.acs.condition_delay * 1000;
                acsEventConditionTimer = setTimeout(() => sendAcsEventTimerCallback(weight, unit), timerTime);
            }
        }
        else if (acsEventConditionTimer) {
            acsEventSendTimeStamp = null;
            clearTimeout(acsEventConditionTimer);
            acsEventConditionTimer = null;
        }
    }
    catch (err) {
        console.error('ACS event:', err instanceof Error ? err.message : 'unknown');
    }
}
function sendCameraEventTimerCallback(conditionActive, weight, unit) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (conditionActive) {
                console.log(`Send Axis event, weight: ${weight} ${unit}`);
            }
            yield (axisEvents === null || axisEvents === void 0 ? void 0 : axisEvents.sendEvent(conditionActive));
            axisEventsSentActiveState = conditionActive;
            axisEventsConditionTimer = null;
        }
        catch (err) {
            console.error('Camera events error:', err);
            axisEventsConditionTimer = setTimeout(() => sendCameraEventTimerCallback(conditionActive, weight, unit), 5000);
        }
    });
}
function checkCondtionAndSendCameraEvent(weight, unit) {
    try {
        const conditionActive = (0, utils_1.isConditionActive)(Number.parseInt(weight), settings.event_camera.condition_operator, Number.parseInt(settings.event_camera.condition_value));
        if (conditionActive !== axisEventsSentActiveState) {
            const timerTime = conditionActive ? settings.event_camera.condition_delay * 1000 : 0;
            if (axisEventsConditionTimer !== null) {
                clearTimeout(axisEventsConditionTimer);
            }
            axisEventsConditionTimer = setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                yield sendCameraEventTimerCallback(conditionActive, weight, unit);
                axisEventsSentActiveState = conditionActive;
            }), timerTime);
        }
    }
    catch (err) {
        console.error('Axis event:', err instanceof Error ? err.message : 'unknown');
    }
}
function main() {
    try {
        settings = readSettings();
        if (settings.acs.active) {
            if (settings.acs.ip.length !== 0 &&
                settings.acs.user.length !== 0 &&
                settings.acs.pass.length !== 0 &&
                settings.acs.source_key.length !== 0) {
                acs = new AxisCameraStation_1.AxisCameraStation(settings.acs);
            }
            else {
                console.log('Axis Camera Station is not configured and thus is disabled.');
            }
        }
        if (settings.event_camera.active) {
            if (settings.event_camera.ip.length !== 0 &&
                settings.event_camera.user.length !== 0 &&
                settings.event_camera.pass.length !== 0 &&
                settings.event_camera.condition_delay !== null &&
                settings.event_camera.condition_operator !== null &&
                settings.event_camera.condition_value !== null) {
                axisEvents = new AxisEvents_1.AxisEvents(settings.event_camera);
            }
            else {
                console.log('Axis Events is not configured and thus is disabled.');
            }
        }
        if (settings.camera.ip.length !== 0 &&
            settings.camera.user.length !== 0 &&
            settings.camera.pass.length !== 0 &&
            settings.camera.service_id >= 0) {
            co = new CamOverlayAPI_1.CamOverlayAPI({
                tls: settings.camera.protocol !== 'http',
                tlsInsecure: settings.camera.protocol === 'https_insecure',
                ip: settings.camera.ip,
                port: settings.camera.port,
                user: settings.camera.user,
                pass: settings.camera.pass,
            });
            console.log('CoAPI connected');
        }
        else {
            console.log('CamOverlay is not configured and thus is disabled.');
        }
        const scaleClient = new net.Socket();
        scaleClient.connect(settings.scale.port, settings.scale.ip);
        scaleClient.on('connect', () => {
            console.log('Scale connected');
            setInterval(() => {
                scaleClient.write(Buffer.from('1B700D0A', 'hex'));
            }, settings.scale.refresh_rate);
        });
        scaleClient.on('data', (data) => __awaiter(this, void 0, void 0, function* () {
            dataBuffer += Buffer.from(data.toString());
            const messageEnd = dataBuffer.indexOf('\r\n');
            if (messageEnd === -1) {
                return;
            }
            const weightData = dataBuffer.substring(0, messageEnd);
            dataBuffer = '';
            if (prevWeightData !== weightData) {
                prevWeightData = weightData;
                const weight = weightData.substring(0, 9).trim();
                const unit = weightData.substring(9).trim();
                if (co !== undefined) {
                    try {
                        yield co.updateCGText(settings.camera.service_id, [
                            {
                                field_name: settings.camera.value_field_name,
                                text: weight,
                            },
                            {
                                field_name: settings.camera.unit_field_name,
                                text: unit,
                            },
                        ]);
                    }
                    catch (err) {
                        console.error('CamOverlay error:', err);
                    }
                }
                if (axisEvents !== undefined && unit.length) {
                    checkCondtionAndSendCameraEvent(weight, unit);
                }
                if (acs !== undefined && weight !== '0' && unit.length) {
                    if (acsEventConditionTimer) {
                        clearTimeout(acsEventConditionTimer);
                        acsEventConditionTimer = null;
                    }
                    checkCondtionAndSendAcsEvent(weight, unit);
                }
            }
            else if (prevWeightData === weightData && acs !== undefined && settings.acs.repeat_after !== 0) {
                const weight = weightData.substring(0, 9).trim();
                const unit = weightData.substring(9).trim();
                checkCondtionAndSendAcsEvent(weight, unit);
            }
        }));
        scaleClient.on('error', (err) => {
            console.error('Scale connection error:', err);
            process.exit(1);
        });
        scaleClient.on('close', () => {
            console.log('Scale connection closed');
            process.exit(0);
        });
        console.log('Application started');
    }
    catch (err) {
        console.error('Application start:', err);
        process.exit(1);
    }
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
    console.error('Unhandled rejection:', err);
});
main();
