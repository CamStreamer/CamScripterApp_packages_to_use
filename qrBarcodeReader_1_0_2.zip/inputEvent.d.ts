/// <reference types="node" />
import * as EventEmitter from 'events';
export type InputEventData = {
    keycode: number;
    ctrl: boolean;
    shift: boolean;
    alt: boolean;
};
export declare class InputEvent extends EventEmitter {
    private device;
    private usbKeycode;
    constructor(device: string);
}
