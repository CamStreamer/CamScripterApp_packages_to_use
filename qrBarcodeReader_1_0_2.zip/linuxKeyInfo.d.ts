export type KeyInfo = {
    name: string;
    char: string;
};
export declare function keyCodeInfo(keyCode: number, shift: boolean): KeyInfo;
