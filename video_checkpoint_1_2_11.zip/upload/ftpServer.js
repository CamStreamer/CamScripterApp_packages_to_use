"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FTPServer = void 0;
const basic_ftp_1 = require("basic-ftp");
const utils_1 = require("../utils");
const stream_1 = require("stream");
const MAX_QUEUE_LENGTH = 50;
class FTPServer {
    constructor(ftpSettings) {
        this.client = new basic_ftp_1.Client(1000 * 60 * 5);
        this.accessOptions = {
            host: ftpSettings.ip,
            port: ftpSettings.port,
            user: ftpSettings.user,
            password: ftpSettings.pass,
            secure: false,
        };
        this.uploadPath = ftpSettings.upload_path;
        if (this.uploadPath[0] !== '/') {
            this.uploadPath = '/' + this.uploadPath;
        }
        this.queue = [];
        this.uploading = false;
    }
    queueVideoUpload(openStream, name, code) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`Uploading recording, code: "${code}", to FTP server...`);
            const uploaded = yield this.queueUpload({ name, openStream });
            if (uploaded) {
                console.log(`Recording ${name} uploaded successfully to FTP server.`);
            }
            return uploaded;
        });
    }
    queueImageUpload(code, images, serialNumber) {
        return __awaiter(this, void 0, void 0, function* () {
            const baseFileName = (0, utils_1.createFileName)(code, new Date(), serialNumber);
            console.log(`Uploading image(s), code: "${code}", to FTP server...`);
            const results = yield Promise.all(images.map((image) => this.queueUpload({
                name: `${baseFileName}_camera${image.camera + 1}.jpg`,
                openStream: () => Promise.resolve(stream_1.Readable.from(image.file)),
            })));
            const uploaded = !results.includes(false);
            if (uploaded) {
                console.log(`Image(s) ${baseFileName}.jpg uploaded successfully to FTP server.`);
            }
            return uploaded;
        });
    }
    queueUpload(job) {
        if (this.queue.length >= MAX_QUEUE_LENGTH) {
            console.error(`Upload queue is full, dropping ${job.name}`);
            return Promise.resolve(false);
        }
        return new Promise((resolve) => {
            this.queue.push({ job, resolve });
            void this.processQueue();
        });
    }
    processQueue() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.uploading) {
                return;
            }
            this.uploading = true;
            try {
                let queued = this.queue.shift();
                while (queued !== undefined) {
                    queued.resolve(yield this.runJob(queued.job));
                    queued = this.queue.shift();
                }
            }
            finally {
                this.uploading = false;
            }
        });
    }
    runJob(job) {
        return __awaiter(this, void 0, void 0, function* () {
            let stream;
            try {
                if (this.client.closed) {
                    yield this.client.access(this.accessOptions);
                }
                stream = yield job.openStream();
            }
            catch (err) {
                console.error(`Preparing upload of ${job.name} failed:`, err instanceof Error ? err.message : 'unknown');
                return false;
            }
            return this.uploadStream(stream, job.name);
        });
    }
    uploadStream(source, name) {
        return __awaiter(this, void 0, void 0, function* () {
            source.on('error', () => undefined);
            try {
                yield this.client.uploadFrom(source, this.uploadPath + '/' + name);
                return true;
            }
            catch (err) {
                console.error(`Upload of ${name} to FTP server failed:`, err instanceof Error ? err.message : 'unknown');
                this.client.close();
                return false;
            }
            finally {
                source.destroy();
            }
        });
    }
}
exports.FTPServer = FTPServer;
