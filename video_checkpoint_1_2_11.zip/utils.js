"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCameraOptions = exports.createFileName = exports.stripCode = exports.getDate = exports.pad = exports.isWebReadableStream = void 0;
const web_1 = require("stream/web");
const isWebReadableStream = (value) => value instanceof web_1.ReadableStream;
exports.isWebReadableStream = isWebReadableStream;
function pad(num, size) {
    const sign = Math.sign(num) === -1 ? '-' : '';
    return (sign +
        new Array(size)
            .concat([Math.abs(num)])
            .join('0')
            .slice(-size));
}
exports.pad = pad;
function getDate() {
    const d = new Date();
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1, 2)}-${pad(d.getDate(), 2)}`;
    const dateTime = `${date}_${pad(d.getHours(), 2)}-${pad(d.getMinutes(), 2)}-${pad(d.getSeconds(), 2)}`;
    return { date, dateTime };
}
exports.getDate = getDate;
function stripCode(code) {
    return code.replace(/[^\w\s]/gi, '');
}
exports.stripCode = stripCode;
function createFileName(code, date, serialNumber, camera) {
    if (camera !== undefined) {
        const channelNumber = camera + 1;
        return (date.getFullYear() +
            '-' +
            pad(date.getMonth() + 1, 2) +
            '-' +
            pad(date.getDate(), 2) +
            '_' +
            pad(date.getHours(), 2) +
            '-' +
            pad(date.getMinutes(), 2) +
            '-' +
            pad(date.getSeconds(), 2) +
            '_' +
            code +
            '_' +
            serialNumber +
            '_camera' +
            channelNumber);
    }
    else {
        return (date.getFullYear() +
            '-' +
            pad(date.getMonth() + 1, 2) +
            '-' +
            pad(date.getDate(), 2) +
            '_' +
            pad(date.getHours(), 2) +
            '-' +
            pad(date.getMinutes(), 2) +
            '-' +
            pad(date.getSeconds(), 2) +
            '_' +
            code +
            '_' +
            serialNumber);
    }
}
exports.createFileName = createFileName;
function getCameraOptions(camera) {
    return {
        tls: camera.protocol !== 'http',
        tlsInsecure: camera.protocol === 'https_insecure',
        ip: camera.ip,
        port: camera.port,
        user: camera.user,
        pass: camera.pass,
        keepAlive: true,
    };
}
exports.getCameraOptions = getCameraOptions;
