"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CameraVideo = void 0;
const jsdom_1 = require("jsdom");
const node_1 = require("camstreamerlib/cjs/node");
const utils_1 = require("../utils");
const CAMERA_BUSY_TIMEOUT_MS = 20 * 1000;
const discardBody = (response) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        yield ((_a = response.body) === null || _a === void 0 ? void 0 : _a.cancel());
    }
    catch (_b) {
    }
});
class CameraVideo {
    constructor(cameraSettings) {
        this.client = new node_1.DefaultClient((0, utils_1.getCameraOptions)(cameraSettings));
    }
    getIDs(source) {
        return __awaiter(this, void 0, void 0, function* () {
            const path = '/axis-cgi/record/list.cgi';
            const response = yield this.client.get({
                path,
                parameters: { recordingid: 'all' },
                timeout: CAMERA_BUSY_TIMEOUT_MS,
            });
            if (!response.ok) {
                yield discardBody(response);
                throw new Error(`The response from camera was not OK. Status code: ${response.status}. Download cancelled.`);
            }
            const xml = yield response.text();
            const dom = new jsdom_1.JSDOM(xml, { contentType: 'text/xml' });
            const recordingNode = dom.window.document.querySelector('recording[recordingstatus="recording"][source="' + source + '"]');
            if (!recordingNode) {
                throw new Error('Warning: Source ' + source + ' has not been found. Make sure it is currently recording.');
            }
            const diskID = recordingNode.getAttribute('diskid');
            const recordingID = recordingNode.getAttribute('recordingid');
            if (diskID === null || diskID === '' || recordingID === null || recordingID === '') {
                throw new Error('Invalid body from ' + path);
            }
            return [diskID, recordingID];
        });
    }
    getSchemaVersion() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.schemaVersion !== undefined) {
                return this.schemaVersion;
            }
            const path = '/axis-cgi/record/storage/schemaversions.cgi';
            const response = yield this.client.get({ path, timeout: CAMERA_BUSY_TIMEOUT_MS });
            if (!response.ok) {
                yield discardBody(response);
                throw new Error(`The response from camera was not OK. Status code: ${response.status}`);
            }
            const xml = yield response.text();
            const dom = new jsdom_1.JSDOM(xml, { contentType: 'text/xml' });
            const versionNumberNode = dom.window.document.querySelector('VersionNumber');
            if (!versionNumberNode) {
                throw new Error('VersionNumber element not found at ' + path);
            }
            const versionNumber = versionNumberNode.textContent;
            if (versionNumber === null || versionNumber === '') {
                throw new Error('VersionNumber is empty');
            }
            this.schemaVersion = versionNumber;
            return versionNumber;
        });
    }
    prepareExport(startTime, endTime, source) {
        return __awaiter(this, void 0, void 0, function* () {
            const [diskID, recordingID] = yield this.getIDs(source + 1);
            const schemaVersion = yield this.getSchemaVersion();
            return {
                source,
                parameters: {
                    schemaversion: schemaVersion,
                    diskid: diskID,
                    recordingid: recordingID,
                    exportformat: 'matroska',
                    starttime: this.formatDate(startTime),
                    stoptime: this.formatDate(endTime),
                },
            };
        });
    }
    openExport(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.client.get({
                path: '/axis-cgi/record/export/exportrecording.cgi',
                parameters: request.parameters,
                timeout: 30 * 60 * 1000,
            });
            if (!response.ok) {
                yield discardBody(response);
                throw new Error(`Export of source ${request.source + 1} failed with status ${response.status}`);
            }
            if (!(0, utils_1.isWebReadableStream)(response.body)) {
                throw new Error(`Export of source ${request.source + 1} returned no body`);
            }
            return response.body;
        });
    }
    formatDate(startTime) {
        const result = new Date(startTime).toISOString();
        return result.substring(0, result.length - 1) + '0Z';
    }
}
exports.CameraVideo = CameraVideo;
