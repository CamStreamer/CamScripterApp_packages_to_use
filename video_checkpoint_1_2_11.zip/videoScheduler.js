"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoScheduler = void 0;
const stream_1 = require("stream");
const utils_1 = require("./utils");
class VideoScheduler {
    constructor(server, googleDrive, camera, generalSettings, serialNumber, settings) {
        this.server = server;
        this.googleDrive = googleDrive;
        this.camera = camera;
        this.generalSettings = generalSettings;
        this.serialNumber = serialNumber;
        this.settings = settings;
        this.recordingIsOngoing = false;
        this.sourceList = this.settings.camera_list;
    }
    get getRecordingStatus() {
        return this.recordingIsOngoing;
    }
    onBarCodeScan(code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.accidentalRead(code)) {
                    return this.scanResultWithoutUpload();
                }
                const startRecording = this.willStartRecording(code);
                let video;
                if (this.willStopRecording(code)) {
                    video = this.delayedMakeVideo(this.recordingStart, this.lastCode);
                    this.clearMetadata();
                }
                if (startRecording) {
                    this.setMetadata(code);
                }
                return video === undefined ? this.scanResultWithoutUpload() : yield video;
            }
            catch (err) {
                console.error('Error while processing recording:', err);
                return false;
            }
        });
    }
    shouldShowBarcode(code) {
        let result = true;
        result && (result = !this.accidentalRead(code));
        if (this.settings.closing_barcode_enabled) {
            result && (result = code !== this.settings.closing_barcode);
        }
        if (this.settings.starting_barcode_enabled) {
            return result && code !== this.settings.starting_barcode;
        }
        else {
            return result;
        }
    }
    willStopRecording(code) {
        if (!this.recordingIsOngoing) {
            return false;
        }
        if (this.settings.closing_barcode_enabled) {
            return code === this.settings.closing_barcode;
        }
        if (this.settings.starting_barcode_enabled) {
            return code === this.settings.starting_barcode;
        }
        return true;
    }
    willStartRecording(code) {
        if (!this.willStopRecording(code) && this.recordingIsOngoing) {
            return false;
        }
        if (this.settings.starting_barcode_enabled) {
            return code === this.settings.starting_barcode;
        }
        if (this.settings.closing_barcode_enabled) {
            return code !== this.settings.closing_barcode && code !== this.lastCode;
        }
        return code !== this.lastCode;
    }
    accidentalRead(code) {
        return code === this.lastCode && this.recordingStart !== undefined && Date.now() - this.recordingStart < 3000;
    }
    scanResultWithoutUpload() {
        return this.recordingIsOngoing ? undefined : true;
    }
    setMetadata(code) {
        this.recordingIsOngoing = true;
        this.recordingStart = Date.now();
        const startTime = this.recordingStart;
        this.lastCode = code;
        if (this.settings.timeout_enabled) {
            this.timeoutID = setTimeout(() => __awaiter(this, void 0, void 0, function* () { return yield this.onTimeout(startTime, code); }), (this.settings.timeout_sec + this.settings.postbuffer_sec) * 1000);
        }
    }
    onTimeout(startTime, code) {
        return __awaiter(this, void 0, void 0, function* () {
            this.clearMetadata();
            try {
                yield this.makeVideo(startTime, code);
            }
            catch (err) {
                console.error('Error while processing recording after timeout:', err);
            }
        });
    }
    delayedMakeVideo(startTime, code) {
        return __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve) => {
                setTimeout(resolve, this.settings.postbuffer_sec * 1000);
            });
            return this.makeVideo(startTime, code);
        });
    }
    clearMetadata() {
        clearTimeout(this.timeoutID);
        this.recordingIsOngoing = false;
        this.timeoutID = undefined;
        this.recordingStart = undefined;
        this.lastCode = undefined;
    }
    makeVideo(startTime, code) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.camera === undefined) {
                return false;
            }
            if (startTime === undefined) {
                console.error('Cannot download a video, starttime was not set');
                return false;
            }
            const server = this.generalSettings.ftp_server.type === 'video' ? this.server : undefined;
            const googleDrive = this.generalSettings.google_drive.type === 'video' ? this.googleDrive : undefined;
            if (server === undefined && googleDrive === undefined) {
                console.log('No upload target is set to video, nothing will be uploaded.');
                return true;
            }
            const endTime = Date.now();
            const from = startTime - this.settings.prebuffer_sec * 1000;
            const uploads = [];
            let errorCount = 0;
            const camera = this.camera;
            for (const source of this.sourceList) {
                let request;
                try {
                    request = yield camera.prepareExport(from, endTime, source);
                }
                catch (err) {
                    errorCount += 1;
                    console.error(`Preparing video for source ${source + 1} failed:`, err);
                    continue;
                }
                const openExport = () => __awaiter(this, void 0, void 0, function* () { return stream_1.Readable.fromWeb(yield camera.openExport(request)); });
                const recordingName = `${(0, utils_1.createFileName)(code, new Date(), this.serialNumber, source)}.mkv`;
                if (server && googleDrive) {
                    uploads.push(this.uploadToBoth(server, googleDrive, openExport, recordingName, code));
                }
                else if (server) {
                    uploads.push(server.queueVideoUpload(openExport, recordingName, code));
                }
                else if (googleDrive) {
                    uploads.push(googleDrive.uploadVideo(openExport, recordingName, code));
                }
            }
            const uploaded = yield Promise.all(uploads);
            return errorCount === 0 && !uploaded.includes(false);
        });
    }
    uploadToBoth(server, googleDrive, openExport, name, code) {
        return __awaiter(this, void 0, void 0, function* () {
            let exportOpened = false;
            let driveUpload;
            const ftpUploaded = yield server.queueVideoUpload(() => __awaiter(this, void 0, void 0, function* () {
                exportOpened = true;
                const [toFtp, toDrive] = this.duplicate(yield openExport());
                driveUpload = this.uploadDriveCopy(googleDrive, toDrive, name, code);
                return toFtp;
            }), name, code);
            if (driveUpload === undefined) {
                driveUpload = exportOpened ? Promise.resolve(false) : googleDrive.uploadVideo(openExport, name, code);
            }
            const driveUploaded = yield driveUpload;
            return ftpUploaded && driveUploaded;
        });
    }
    duplicate(source) {
        const copies = [new stream_1.PassThrough(), new stream_1.PassThrough()];
        let openCopies = copies.length;
        source.on('error', (err) => copies.forEach((copy) => copy.destroy(err)));
        for (const copy of copies) {
            copy.on('error', () => undefined);
            copy.on('close', () => {
                openCopies -= 1;
                if (openCopies === 0) {
                    source.destroy();
                }
            });
            source.pipe(copy);
        }
        return copies;
    }
    uploadDriveCopy(googleDrive, copy, name, code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield googleDrive.uploadVideo(() => Promise.resolve(copy), name, code);
            }
            finally {
                copy.destroy();
            }
        });
    }
}
exports.VideoScheduler = VideoScheduler;
