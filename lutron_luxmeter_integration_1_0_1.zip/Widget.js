"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Widget = void 0;
const Painter_1 = require("camstreamerlib/CamOverlayPainter/Painter");
const imageWidth = 720;
const imageHeight = 480;
class Widget {
    constructor(opt, cameras) {
        this.luxmeter = new Painter_1.Frame({
            x: 0,
            y: 0,
            width: imageWidth,
            height: imageHeight,
            bgImage: 'Luxmeter',
        });
        this.message = new Painter_1.Frame({
            x: 65,
            y: 100,
            width: 590,
            height: 180,
            enabled: false,
        });
        this.value = new Painter_1.Frame({
            x: 75,
            y: 90,
            width: 375,
            height: 180,
        });
        this.unit = new Painter_1.Frame({
            x: 485,
            y: 95,
            width: 160,
            height: 180,
        });
        this.scale = opt.scale;
        this.painters = [];
        for (const coOpt of cameras) {
            this.painters.push(this.initialisePainter(Object.assign(Object.assign({}, opt), { width: imageWidth, height: imageHeight }), coOpt, this.luxmeter, this.message, this.value, this.unit));
        }
        this.value.setFont('Digital');
        this.message.setFont('Digital');
        this.message.setText('OUT OF RANGE', 'A_CENTER', 'TFM_SCALE', [0, 0, 0]);
    }
    display(result) {
        return __awaiter(this, void 0, void 0, function* () {
            if (result.value === 0 || isNaN(result.value)) {
                this.message.enable();
                this.value.disable();
                this.unit.disable();
            }
            else {
                this.message.disable();
                this.value.enable();
                this.unit.enable();
                this.value.setText(this.toString(result.value), 'A_RIGHT', 'TFM_SCALE', [0, 0, 0]);
                this.unit.setText(result.unit, 'A_CENTER', 'TFM_SCALE', [0, 0, 0]);
            }
            const promises = new Array();
            for (const p of this.painters) {
                promises.push(p.display(this.scale));
            }
            yield Promise.all(promises);
        });
    }
    toString(value) {
        const text = value.toPrecision(4);
        return text.substring(0, 6);
    }
    initialisePainter(opt, coOpt, ...frames) {
        const coOptions = Object.assign(Object.assign({}, coOpt), { camera: coOpt.cameraList, tls: coOpt.protocol !== 'http', tlsInsecure: coOpt.protocol !== 'https' });
        const p = new Painter_1.Painter(opt, coOptions);
        p.registerFont('Digital', 'digital_font.ttf');
        p.registerImage('Luxmeter', 'luxmeter.png');
        p.insert(...frames);
        void p.connect();
        return p;
    }
}
exports.Widget = Widget;
//# sourceMappingURL=Widget.js.map