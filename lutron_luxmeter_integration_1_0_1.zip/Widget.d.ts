import { PainterOptions } from 'camstreamerlib/CamOverlayPainter/Painter';
import type { TResult } from './LuxMeterReader';
import type { TCamera } from './settings';
export declare class Widget {
    private painters;
    private luxmeter;
    private message;
    private value;
    private unit;
    private scale;
    constructor(opt: Omit<PainterOptions, 'width' | 'height'> & {
        scale: number;
    }, cameras: TCamera[]);
    display(result: TResult): Promise<void>;
    private toString;
    private initialisePainter;
}
