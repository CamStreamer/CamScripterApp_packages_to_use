"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AxisEvents = void 0;
const CamScripterAPICameraEventsGenerator_1 = require("camstreamerlib/CamScripterAPICameraEventsGenerator");
const packageName = (_a = process.env.PACKAGE_NAME) !== null && _a !== void 0 ? _a : 'lutron_luxmeter_integration';
class AxisEvents {
    constructor(cscConnectionParams) {
        this.cscArray = [];
        for (const connection of cscConnectionParams) {
            const options = Object.assign(Object.assign({}, connection), { tls: connection.protocol !== 'http', tlsInsecure: connection.protocol === 'https' });
            const csc = new CamScripterAPICameraEventsGenerator_1.CamScripterAPICameraEventsGenerator(options);
            const eg = { csc, connected: false, eventDeclared: false };
            this.cscArray.push(eg);
            void this.prepareEvents(eg);
        }
    }
    sendEvent(type) {
        this.cscArray.forEach((eg) => {
            if (!eg.connected || !eg.eventDeclared) {
                console.error('AxisEvents: CSc API disconnected');
            }
            eg.csc
                .sendEvent({
                declaration_id: packageName + '_' + type,
                event_data: [
                    {
                        namespace: '',
                        key: 'intensity_alarm',
                        value: type === 'low' ? 'Low intensity' : 'High intensity',
                        value_type: 'STRING',
                    },
                ],
            })
                .catch((err) => {
                console.error(err);
            });
        });
    }
    prepareEvents(eg) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!(yield this.connectCameraEvents(eg))) {
                    throw new Error('Connection error');
                }
                if (!eg.eventDeclared) {
                    yield this.declareCameraEvent(eg.csc);
                    eg.eventDeclared = true;
                }
            }
            catch (err) {
                console.error('AxisEvents: prepare event:', err);
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = setTimeout(() => this.prepareEvents(eg), 10000);
            }
        });
    }
    connectCameraEvents(eg) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!eg.connected) {
                eg.csc.removeAllListeners();
                eg.csc.on('open', () => {
                    console.log('CSc: connected');
                    this.prepareEvents(eg).catch(() => console.error('AxisEvents: unhandled prepare event'));
                    eg.connected = true;
                });
                eg.csc.on('error', (err) => {
                    console.log('CSc-Error: ' + err);
                });
                eg.csc.on('close', () => {
                    console.log('CSc-Error: connection closed');
                    eg.connected = false;
                    eg.eventDeclared = false;
                    clearTimeout(this.reconnectTimer);
                    this.reconnectTimer = setTimeout(() => this.prepareEvents(eg), 10000);
                });
                yield eg.csc.connect();
            }
            return eg.connected;
        });
    }
    declareCameraEvent(csc) {
        return __awaiter(this, void 0, void 0, function* () {
            const type = {
                _low: 'Low intensity',
                _high: 'High intensity',
            };
            for (const event of ['_low', '_high']) {
                yield csc.declareEvent({
                    declaration_id: packageName + event,
                    stateless: true,
                    declaration: [
                        {
                            namespace: 'tnsaxis',
                            key: 'topic0',
                            value: 'CameraApplicationPlatform',
                            value_type: 'STRING',
                        },
                        {
                            namespace: 'tnsaxis',
                            key: 'topic1',
                            value: 'CamScripter',
                            value_type: 'STRING',
                        },
                        {
                            namespace: 'tnsaxis',
                            key: 'topic2',
                            value: packageName + event,
                            value_type: 'STRING',
                            value_nice_name: 'CamScripter: Lutron Luxmeter integration (' + type[event] + ')',
                        },
                        {
                            type: 'DATA',
                            namespace: '',
                            key: 'intensity_alarm',
                            key_nice_name: type[event] + ' alarm',
                            value: '',
                            value_type: 'STRING',
                        },
                    ],
                });
            }
        });
    }
}
exports.AxisEvents = AxisEvents;
//# sourceMappingURL=AxisEvents.js.map