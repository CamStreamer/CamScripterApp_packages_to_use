import { z } from 'zod';
declare const cameraSchema: z.ZodObject<{
    cameraList: z.ZodArray<z.ZodNumber, "atleastone">;
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodUnion<[z.ZodDefault<z.ZodString>, z.ZodLiteral<"">]>;
    port: z.ZodNumber;
    user: z.ZodString;
    pass: z.ZodString;
}, "strip", z.ZodTypeAny, {
    cameraList: [number, ...number[]];
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
}, {
    cameraList: [number, ...number[]];
    protocol: "http" | "https" | "https_insecure";
    port: number;
    user: string;
    pass: string;
    ip?: string | undefined;
}>;
declare const acsSchema: z.ZodObject<{
    source_key: z.ZodString;
    enabled: z.ZodBoolean;
    triggerDelay: z.ZodNumber;
    repeatDelay: z.ZodNumber;
    value: z.ZodNumber;
    condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodUnion<[z.ZodDefault<z.ZodString>, z.ZodLiteral<"">]>;
    port: z.ZodNumber;
    user: z.ZodString;
    pass: z.ZodString;
}, "strip", z.ZodTypeAny, {
    value: number;
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
    source_key: string;
    enabled: boolean;
    triggerDelay: number;
    repeatDelay: number;
    condition: "=" | "<" | "<=" | ">" | ">=";
}, {
    value: number;
    protocol: "http" | "https" | "https_insecure";
    port: number;
    user: string;
    pass: string;
    source_key: string;
    enabled: boolean;
    triggerDelay: number;
    repeatDelay: number;
    condition: "=" | "<" | "<=" | ">" | ">=";
    ip?: string | undefined;
}>;
declare const eventSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
    triggerDelay: z.ZodNumber;
    repeatDelay: z.ZodNumber;
    value: z.ZodNumber;
    condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
}, "strip", z.ZodTypeAny, {
    value: number;
    enabled: boolean;
    triggerDelay: number;
    repeatDelay: number;
    condition: "=" | "<" | "<=" | ">" | ">=";
}, {
    value: number;
    enabled: boolean;
    triggerDelay: number;
    repeatDelay: number;
    condition: "=" | "<" | "<=" | ">" | ">=";
}>;
declare const widgetSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
    x: z.ZodNumber;
    y: z.ZodNumber;
    scale: z.ZodNumber;
    screenWidth: z.ZodNumber;
    screenHeight: z.ZodNumber;
    coAlignment: z.ZodUnion<[z.ZodLiteral<"top_left">, z.ZodLiteral<"top_center">, z.ZodLiteral<"top_right">, z.ZodLiteral<"center_left">, z.ZodLiteral<"center">, z.ZodLiteral<"center_right">, z.ZodLiteral<"bottom_left">, z.ZodLiteral<"bottom_center">, z.ZodLiteral<"bottom_right">]>;
}, "strip", z.ZodTypeAny, {
    enabled: boolean;
    x: number;
    y: number;
    scale: number;
    screenWidth: number;
    screenHeight: number;
    coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
}, {
    enabled: boolean;
    x: number;
    y: number;
    scale: number;
    screenWidth: number;
    screenHeight: number;
    coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
}>;
declare const settingsSchema: z.ZodObject<{
    updateFrequency: z.ZodNumber;
    cameras: z.ZodArray<z.ZodObject<{
        cameraList: z.ZodArray<z.ZodNumber, "atleastone">;
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodUnion<[z.ZodDefault<z.ZodString>, z.ZodLiteral<"">]>;
        port: z.ZodNumber;
        user: z.ZodString;
        pass: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        cameraList: [number, ...number[]];
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }, {
        cameraList: [number, ...number[]];
        protocol: "http" | "https" | "https_insecure";
        port: number;
        user: string;
        pass: string;
        ip?: string | undefined;
    }>, "many">;
    acs: z.ZodObject<z.objectUtil.extendShape<{
        source_key: z.ZodString;
        enabled: z.ZodBoolean;
        triggerDelay: z.ZodNumber;
        repeatDelay: z.ZodNumber;
        value: z.ZodNumber;
        condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodUnion<[z.ZodDefault<z.ZodString>, z.ZodLiteral<"">]>;
        port: z.ZodNumber;
        user: z.ZodString;
        pass: z.ZodString;
    }, {
        enabled: z.ZodBoolean;
        triggerDelay: z.ZodNumber;
        repeatDelay: z.ZodNumber;
        value: z.ZodNumber;
        condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
    }>, "strip", z.ZodTypeAny, {
        value: number;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        source_key: string;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    }, {
        value: number;
        protocol: "http" | "https" | "https_insecure";
        port: number;
        user: string;
        pass: string;
        source_key: string;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
        ip?: string | undefined;
    }>;
    lowEvent: z.ZodObject<{
        enabled: z.ZodBoolean;
        triggerDelay: z.ZodNumber;
        repeatDelay: z.ZodNumber;
        value: z.ZodNumber;
        condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
    }, "strip", z.ZodTypeAny, {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    }, {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    }>;
    highEvent: z.ZodObject<{
        enabled: z.ZodBoolean;
        triggerDelay: z.ZodNumber;
        repeatDelay: z.ZodNumber;
        value: z.ZodNumber;
        condition: z.ZodUnion<[z.ZodLiteral<"=">, z.ZodLiteral<"<">, z.ZodLiteral<"<=">, z.ZodLiteral<">">, z.ZodLiteral<">=">, z.ZodLiteral<"<">]>;
    }, "strip", z.ZodTypeAny, {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    }, {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    }>;
    widget: z.ZodObject<{
        enabled: z.ZodBoolean;
        x: z.ZodNumber;
        y: z.ZodNumber;
        scale: z.ZodNumber;
        screenWidth: z.ZodNumber;
        screenHeight: z.ZodNumber;
        coAlignment: z.ZodUnion<[z.ZodLiteral<"top_left">, z.ZodLiteral<"top_center">, z.ZodLiteral<"top_right">, z.ZodLiteral<"center_left">, z.ZodLiteral<"center">, z.ZodLiteral<"center_right">, z.ZodLiteral<"bottom_left">, z.ZodLiteral<"bottom_center">, z.ZodLiteral<"bottom_right">]>;
    }, "strip", z.ZodTypeAny, {
        enabled: boolean;
        x: number;
        y: number;
        scale: number;
        screenWidth: number;
        screenHeight: number;
        coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
    }, {
        enabled: boolean;
        x: number;
        y: number;
        scale: number;
        screenWidth: number;
        screenHeight: number;
        coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
    }>;
}, "strip", z.ZodTypeAny, {
    updateFrequency: number;
    cameras: {
        cameraList: [number, ...number[]];
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }[];
    acs: {
        value: number;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        source_key: string;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    };
    lowEvent: {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    };
    highEvent: {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    };
    widget: {
        enabled: boolean;
        x: number;
        y: number;
        scale: number;
        screenWidth: number;
        screenHeight: number;
        coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
    };
}, {
    updateFrequency: number;
    cameras: {
        cameraList: [number, ...number[]];
        protocol: "http" | "https" | "https_insecure";
        port: number;
        user: string;
        pass: string;
        ip?: string | undefined;
    }[];
    acs: {
        value: number;
        protocol: "http" | "https" | "https_insecure";
        port: number;
        user: string;
        pass: string;
        source_key: string;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
        ip?: string | undefined;
    };
    lowEvent: {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    };
    highEvent: {
        value: number;
        enabled: boolean;
        triggerDelay: number;
        repeatDelay: number;
        condition: "=" | "<" | "<=" | ">" | ">=";
    };
    widget: {
        enabled: boolean;
        x: number;
        y: number;
        scale: number;
        screenWidth: number;
        screenHeight: number;
        coAlignment: "top_left" | "top_center" | "top_right" | "center_left" | "center" | "center_right" | "bottom_left" | "bottom_center" | "bottom_right";
    };
}>;
export type TCamera = z.infer<typeof cameraSchema>;
export type TAcs = z.infer<typeof acsSchema>;
export type TEvent = z.infer<typeof eventSchema>;
export type TWidget = z.infer<typeof widgetSchema>;
export type TSettings = z.infer<typeof settingsSchema>;
export declare function readSettings(): TSettings;
export {};
