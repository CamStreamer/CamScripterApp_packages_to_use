"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LuxMeterReader = void 0;
const fs = require("fs/promises");
const serialport_1 = require("serialport");
const bufferSize = 16;
const STX = 2;
const LF = 10;
class LuxMeterReader {
    constructor() {
        this.last = Buffer.alloc(0);
    }
    findLuxMeter() {
        return __awaiter(this, void 0, void 0, function* () {
            const list = yield serialport_1.SerialPort.list();
            for (const port of list) {
                this.device = yield fs.open(port.path, 'r');
                const buf = yield this.read();
                if (this.validResponse(buf)) {
                    this.last = buf;
                    void this.readLoop();
                    return;
                }
                else {
                    void this.device.close();
                }
            }
            throw new Error('No Lux meter found.');
        });
    }
    static connect() {
        return __awaiter(this, void 0, void 0, function* () {
            const lmr = new LuxMeterReader();
            yield lmr.findLuxMeter();
            return lmr;
        });
    }
    validResponse(buf) {
        const zeroCode = '0'.charCodeAt(0);
        const nineCode = '9'.charCodeAt(0);
        if (buf[0] !== STX || buf.at(-1) !== LF) {
            return false;
        }
        for (let f = 1; f < bufferSize - 1; f += 1) {
            if (zeroCode > buf[f] || buf[f] > nineCode) {
                return false;
            }
        }
        return true;
    }
    readLoop() {
        return __awaiter(this, void 0, void 0, function* () {
            for (;;) {
                this.last = yield this.read();
            }
        });
    }
    read() {
        return __awaiter(this, void 0, void 0, function* () {
            let buf = Buffer.alloc(0);
            const byte = Buffer.alloc(1);
            do {
                yield this.device.read(byte, 0, 1, null);
                buf = Buffer.concat([buf, byte]);
            } while (byte.at(0) !== LF);
            return buf;
        });
    }
    readParsed() {
        const s = this.last.toString();
        const value = Number.parseInt(s.substring(7, 15));
        const decimalPointPosition = Number.parseInt(s[6]);
        const unit = Number.parseInt(s.substring(3, 5));
        return {
            value: value * Math.pow(10, -decimalPointPosition),
            unit: unit === 15 ? 'Lux' : 'Ft-cd',
        };
    }
}
exports.LuxMeterReader = LuxMeterReader;
//# sourceMappingURL=LuxMeterReader.js.map