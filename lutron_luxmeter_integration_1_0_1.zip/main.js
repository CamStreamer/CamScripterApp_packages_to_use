"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const promises_1 = require("timers/promises");
const AxisCameraStationEvents_1 = require("camstreamerlib/events/AxisCameraStationEvents");
const Widget_1 = require("./Widget");
const AxisEvents_1 = require("./AxisEvents");
const LuxMeterReader_1 = require("./LuxMeterReader");
const settings_1 = require("./settings");
let widget;
let axisEvents;
let acsEvents;
function sendAcsEvent(result) {
    const message = {
        Intensity: result.value.toString(),
        Unit: result.unit,
    };
    acsEvents === null || acsEvents === void 0 ? void 0 : acsEvents.sendEvent(message, 'lutron_luxmeter_integration').catch((err) => console.error(err));
}
function compare(measuredValue, triggerValue, condition) {
    switch (condition) {
        case '=':
            return measuredValue === triggerValue;
        case '<':
            return measuredValue < triggerValue;
        case '<=':
            return measuredValue <= triggerValue;
        case '>':
            return measuredValue > triggerValue;
        case '>=':
            return measuredValue >= triggerValue;
    }
}
function loop(lmr, updateFrequency, lowEvent, highEvent, acs) {
    var _a, e_1, _b, _c;
    return __awaiter(this, void 0, void 0, function* () {
        let lowEventTimeout;
        let highEventTimeout;
        let acsEventTimeout;
        try {
            for (var _d = true, _e = __asyncValues((0, promises_1.setInterval)(updateFrequency)), _f; _f = yield _e.next(), _a = _f.done, !_a; _d = true) {
                _c = _f.value;
                _d = false;
                const c = _c;
                void c;
                const result = yield lmr.readParsed();
                if (widget) {
                    try {
                        yield widget.display(result);
                    }
                    catch (err) {
                        console.error(err);
                    }
                }
                if (lowEvent.enabled) {
                    if (compare(result.value, lowEvent.value, lowEvent.condition)) {
                        if (lowEventTimeout === undefined) {
                            const triggerEvent = () => {
                                axisEvents === null || axisEvents === void 0 ? void 0 : axisEvents.sendEvent('low');
                                if (lowEvent.repeatDelay > 0) {
                                    lowEventTimeout = setTimeout(triggerEvent, lowEvent.repeatDelay);
                                }
                            };
                            lowEventTimeout = setTimeout(() => triggerEvent(), lowEvent.triggerDelay);
                        }
                    }
                    else {
                        clearTimeout(lowEventTimeout);
                        lowEventTimeout = undefined;
                    }
                }
                if (highEvent.enabled) {
                    if (compare(result.value, highEvent.value, highEvent.condition)) {
                        if (highEventTimeout === undefined) {
                            const triggerEvent = () => {
                                axisEvents === null || axisEvents === void 0 ? void 0 : axisEvents.sendEvent('high');
                                if (highEvent.repeatDelay > 0) {
                                    highEventTimeout = setTimeout(triggerEvent, highEvent.repeatDelay);
                                }
                            };
                            highEventTimeout = setTimeout(() => triggerEvent(), highEvent.triggerDelay);
                        }
                    }
                    else {
                        clearTimeout(highEventTimeout);
                        highEventTimeout = undefined;
                    }
                }
                if (acs.enabled) {
                    if (compare(result.value, acs.value, acs.condition)) {
                        if (acsEventTimeout === undefined) {
                            const triggerEvent = () => {
                                sendAcsEvent(result);
                                if (acs.repeatDelay > 0) {
                                    acsEventTimeout = setTimeout(triggerEvent, acs.repeatDelay);
                                }
                            };
                            acsEventTimeout = setTimeout(() => triggerEvent(), acs.triggerDelay);
                        }
                    }
                    else {
                        clearTimeout(acsEventTimeout);
                        acsEventTimeout = undefined;
                    }
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
            }
            finally { if (e_1) throw e_1.error; }
        }
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = (0, settings_1.readSettings)();
        const lmr = yield LuxMeterReader_1.LuxMeterReader.connect();
        if (settings.widget.enabled) {
            widget = new Widget_1.Widget(settings.widget, settings.cameras);
        }
        if (settings.lowEvent.enabled || settings.highEvent.enabled) {
            axisEvents = new AxisEvents_1.AxisEvents(settings.cameras);
        }
        if (settings.acs.enabled) {
            const options = Object.assign(Object.assign({}, settings.acs), { tls: settings.acs.protocol !== 'http', tlsInsecure: settings.acs.protocol !== 'https' });
            acsEvents = new AxisCameraStationEvents_1.AxisCameraStationEvents(settings.acs.source_key, options);
        }
        yield loop(lmr, settings.updateFrequency, settings.lowEvent, settings.highEvent, settings.acs);
    });
}
process.on('uncaughtException', (error) => {
    console.warn('uncaughtException', error);
    process.exit(1);
});
process.on('unhandledRejection', (error) => {
    console.warn('unhandledRejection', error);
    process.exit(1);
});
void main();
//# sourceMappingURL=main.js.map