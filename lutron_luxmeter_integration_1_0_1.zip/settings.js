"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readSettings = void 0;
const zod_1 = require("zod");
const fs = require("fs");
const path = require("path");
const connectionParams = {
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.union([zod_1.z.string().ip().default('127.0.0.1'), zod_1.z.literal('')]),
    port: zod_1.z.number().positive().lt(65535),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
};
const eventParams = {
    enabled: zod_1.z.boolean(),
    triggerDelay: zod_1.z.number().nonnegative(),
    repeatDelay: zod_1.z.number().nonnegative(),
    value: zod_1.z.number().nonnegative(),
    condition: zod_1.z.union([
        zod_1.z.literal('='),
        zod_1.z.literal('<'),
        zod_1.z.literal('<='),
        zod_1.z.literal('>'),
        zod_1.z.literal('>='),
        zod_1.z.literal('<'),
    ]),
};
const cameraSchema = zod_1.z.object(Object.assign(Object.assign({}, connectionParams), { cameraList: zod_1.z.number().array().nonempty() }));
const acsSchema = zod_1.z.object(Object.assign(Object.assign(Object.assign({}, connectionParams), eventParams), { source_key: zod_1.z.string() }));
const eventSchema = zod_1.z.object(eventParams);
const widgetSchema = zod_1.z.object({
    enabled: zod_1.z.boolean(),
    x: zod_1.z.number().nonnegative(),
    y: zod_1.z.number().nonnegative(),
    scale: zod_1.z.number().positive(),
    screenWidth: zod_1.z.number().nonnegative(),
    screenHeight: zod_1.z.number().nonnegative(),
    coAlignment: zod_1.z.union([
        zod_1.z.literal('top_left'),
        zod_1.z.literal('top_center'),
        zod_1.z.literal('top_right'),
        zod_1.z.literal('center_left'),
        zod_1.z.literal('center'),
        zod_1.z.literal('center_right'),
        zod_1.z.literal('bottom_left'),
        zod_1.z.literal('bottom_center'),
        zod_1.z.literal('bottom_right'),
    ]),
});
const settingsSchema = zod_1.z.object({
    updateFrequency: zod_1.z.number(),
    cameras: cameraSchema.array(),
    acs: acsSchema.merge(eventSchema),
    lowEvent: eventSchema,
    highEvent: eventSchema,
    widget: widgetSchema,
});
function isConfigured(camera) {
    return camera.ip !== '' && camera.user !== '' && camera.pass !== '';
}
function convertSettings(settings) {
    settings.updateFrequency *= 1000;
    settings.lowEvent.triggerDelay *= 1000;
    settings.lowEvent.repeatDelay *= 1000;
    settings.highEvent.triggerDelay *= 1000;
    settings.highEvent.repeatDelay *= 1000;
    settings.acs.triggerDelay *= 1000;
    settings.acs.repeatDelay *= 1000;
    settings.widget.scale /= 100;
}
function readSettings() {
    var _a;
    const localdata = (_a = process.env.PERSISTENT_DATA_PATH) !== null && _a !== void 0 ? _a : 'localdata';
    const buffer = fs.readFileSync(path.join(localdata, 'settings.json'));
    const data = settingsSchema.parse(JSON.parse(buffer.toString()));
    convertSettings(data);
    data.cameras = data.cameras.filter((camera) => isConfigured(camera));
    return data;
}
exports.readSettings = readSettings;
//# sourceMappingURL=settings.js.map