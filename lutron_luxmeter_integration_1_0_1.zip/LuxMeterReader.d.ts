/// <reference types="node" />
export type TResult = {
    value: number;
    unit: string;
};
export declare class LuxMeterReader {
    private device;
    private last;
    private constructor();
    private findLuxMeter;
    static connect(): Promise<LuxMeterReader>;
    private validResponse;
    private readLoop;
    read(): Promise<Buffer>;
    readParsed(): TResult;
}
