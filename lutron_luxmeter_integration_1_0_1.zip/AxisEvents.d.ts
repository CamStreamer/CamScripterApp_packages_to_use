import { TCamera } from './settings';
export declare class AxisEvents {
    private cscArray;
    private reconnectTimer?;
    constructor(cscConnectionParams: TCamera[]);
    sendEvent(type: 'low' | 'high'): void;
    private prepareEvents;
    private connectCameraEvents;
    private declareCameraEvent;
}
