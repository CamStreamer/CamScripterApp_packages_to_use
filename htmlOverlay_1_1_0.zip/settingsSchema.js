"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = void 0;
const zod_1 = require("zod");
exports.settingsSchema = zod_1.z.array(zod_1.z.object({
    enabled: zod_1.z.boolean(),
    configName: zod_1.z.string(),
    imageSettings: zod_1.z.object({
        url: zod_1.z.union([zod_1.z.string().url(), zod_1.z.literal('')]),
        renderWidth: zod_1.z.number().nonnegative(),
        renderHeight: zod_1.z.number().nonnegative(),
        refreshRate: zod_1.z.number().nonnegative(),
    }),
    cameraSettings: zod_1.z.object({
        protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
        ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
        port: zod_1.z.number().positive().lt(65535),
        user: zod_1.z.string(),
        pass: zod_1.z.string(),
    }),
    coSettings: zod_1.z.object({
        cameraList: zod_1.z.array(zod_1.z.number()).nullable(),
        coordSystem: zod_1.z.union([
            zod_1.z.literal('top_left'),
            zod_1.z.literal('top_right'),
            zod_1.z.literal('bottom_left'),
            zod_1.z.literal('bottom_right'),
        ]),
        posX: zod_1.z.number(),
        posY: zod_1.z.number(),
        streamWidth: zod_1.z.number().nonnegative(),
        streamHeight: zod_1.z.number().nonnegative(),
    }),
}));
