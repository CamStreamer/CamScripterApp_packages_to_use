"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const htmlToOverlay_1 = require("./htmlToOverlay");
const settingsSchema_1 = require("./settingsSchema");
let settingsList = [];
const overlayList = [];
function start() {
    settingsList = readConfiguration();
    settingsList.forEach((settings) => {
        var _a;
        if (settings.imageSettings.url.length &&
            settings.cameraSettings.ip.length &&
            settings.cameraSettings.user.length &&
            settings.cameraSettings.pass.length &&
            settings.coSettings.cameraList !== null &&
            ((_a = settings.coSettings.cameraList) === null || _a === void 0 ? void 0 : _a.length)) {
            const htmlOvl = new htmlToOverlay_1.HtmlToOverlay(settings);
            void htmlOvl.start();
            overlayList.push(htmlOvl);
        }
    });
    if (overlayList.length === 0) {
        console.log('No configured HTML overlay found');
        setTimeout(() => { }, 300000);
    }
}
function stopAllPackages() {
    return __awaiter(this, void 0, void 0, function* () {
        yield Promise.all(overlayList.map((overlay) => overlay.stop()));
    });
}
function readConfiguration() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        const parsedData = JSON.parse(data.toString());
        const result = settingsSchema_1.settingsSchema.safeParse(parsedData);
        if (!result.success) {
            console.error('Invalid configuration:', result.error.errors);
            return [];
        }
        return result.data;
    }
    catch (err) {
        console.log('No configuration found');
        return [];
    }
}
process.on('SIGINT', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('App exit - configuration changed');
    yield stopAllPackages();
    process.exit();
}));
process.on('SIGTERM', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('App exit');
    yield stopAllPackages();
    process.exit();
}));
console.log('App started');
start();
