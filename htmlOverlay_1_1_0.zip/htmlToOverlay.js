"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlToOverlay = void 0;
const fs = require("fs");
const puppeteer_core_1 = require("puppeteer-core");
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
class HtmlToOverlay {
    constructor(options) {
        this.options = options;
        this.stopped = false;
        this.coConnected = false;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            this.stopped = false;
            if (this.options.enabled) {
                console.log('Start overlay: ' + this.options.configName);
                this.startCamOverlayConnection();
                yield this.startBrowser();
            }
        });
    }
    stop() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log('Stop overlay: ' + this.options.configName);
                this.stopped = true;
                if (this.takeScreenshotPromise) {
                    yield this.takeScreenshotPromise;
                }
                clearTimeout(this.startTimer);
                clearTimeout(this.screenshotTimer);
                yield ((_a = this.browser) === null || _a === void 0 ? void 0 : _a.close());
                yield this.removeImage();
            }
            catch (err) {
                console.log('Stop overlay: ' + this.options.configName, err);
            }
        });
    }
    startBrowser() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            try {
                (_a = this.browser) === null || _a === void 0 ? void 0 : _a.removeAllListeners();
                yield ((_b = this.browser) === null || _b === void 0 ? void 0 : _b.close());
                const executablePath = fs.existsSync('/usr/bin/chromium')
                    ? '/usr/bin/chromium'
                    : '/usr/bin/chromium-browser';
                this.browser = yield puppeteer_core_1.default.launch({
                    executablePath,
                    args: ['--no-sandbox', '--disable-setuid-sandbox'],
                    acceptInsecureCerts: true,
                    handleSIGINT: false,
                    handleSIGTERM: false,
                });
                this.browser.on('disconnected', () => {
                    console.log('Browser disconnected');
                    this.restartBrowser();
                });
                this.page = yield this.browser.newPage();
                this.page.on('error', (err) => {
                    console.log('Page error', err);
                    this.restartBrowser();
                });
                this.page.on('close', () => {
                    console.log('Page closed');
                    this.restartBrowser();
                });
                yield this.page.setViewport({
                    width: this.options.imageSettings.renderWidth,
                    height: this.options.imageSettings.renderHeight,
                });
                console.log('Go to: ' + this.options.imageSettings.url);
                yield this.page.goto(this.options.imageSettings.url);
                this.takeScreenshotPromise = this.takeScreenshot();
            }
            catch (err) {
                this.restartBrowser();
            }
        });
    }
    restartBrowser() {
        clearTimeout(this.startTimer);
        this.startTimer = setTimeout(() => __awaiter(this, void 0, void 0, function* () {
            if (!this.stopped) {
                yield this.startBrowser();
            }
        }), 5000);
    }
    takeScreenshot() {
        return __awaiter(this, void 0, void 0, function* () {
            let sleepTime = 5000;
            try {
                if (!this.co || !this.coConnected || !this.page) {
                    return;
                }
                const startTime = Date.now();
                const imageData = yield this.page.screenshot({ type: 'png', omitBackground: true });
                const surface = (yield this.co.uploadImageData(Buffer.from(imageData))).var;
                const pos = this.computePosition(this.options.coSettings.coordSystem, this.options.coSettings.posX, this.options.coSettings.posY, this.options.imageSettings.renderWidth, this.options.imageSettings.renderHeight, this.options.coSettings.streamWidth, this.options.coSettings.streamHeight);
                yield this.co.showCairoImageAbsolute(surface, pos.x, pos.y, this.options.coSettings.streamWidth, this.options.coSettings.streamHeight);
                yield this.co.cairo('cairo_surface_destroy', surface);
                const endTime = Date.now();
                sleepTime = Math.max(5, this.options.imageSettings.refreshRate - endTime + startTime);
            }
            catch (err) {
                console.error(this.options.configName, err);
            }
            finally {
                this.screenshotTimer = setTimeout(() => {
                    this.takeScreenshotPromise = this.takeScreenshot();
                }, sleepTime);
            }
        });
    }
    removeImage() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.co && this.coConnected) {
                    yield this.co.removeImage();
                }
            }
            catch (err) {
                console.log('Remove overlay: ' + this.options.configName, err);
            }
        });
    }
    startCamOverlayConnection() {
        var _a;
        if (this.co) {
            return;
        }
        this.co = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI({
            tls: this.options.cameraSettings.protocol !== 'http',
            tlsInsecure: this.options.cameraSettings.protocol === 'https_insecure',
            ip: this.options.cameraSettings.ip,
            port: this.options.cameraSettings.port,
            user: this.options.cameraSettings.user,
            pass: this.options.cameraSettings.pass,
            camera: (_a = this.options.coSettings.cameraList) !== null && _a !== void 0 ? _a : undefined,
        });
        this.co.on('open', () => {
            console.log(`COAPI: ${this.options.configName}: connected`);
            this.coConnected = true;
        });
        this.co.on('error', (err) => {
            console.log(`COAPI-Error: ${this.options.configName}:`, err.message);
        });
        this.co.on('close', () => {
            console.log(`COAPI-Error: ${this.options.configName}: connection closed`);
            this.coConnected = false;
        });
        this.co.connect();
    }
    computePosition(coordSystem, posX, posY, width, height, streamWidth, streamHeight) {
        let x = posX;
        let y = posY;
        switch (coordSystem) {
            case 'top_right':
                x = streamWidth - width - posX;
                break;
            case 'bottom_left':
                y = streamHeight - height - posY;
                break;
            case 'bottom_right':
                x = streamWidth - width - posX;
                y = streamHeight - height - posY;
                break;
        }
        return { x, y };
    }
}
exports.HtmlToOverlay = HtmlToOverlay;
