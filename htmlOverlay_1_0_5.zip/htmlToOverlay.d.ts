export type CoordSystem = 'top_left' | 'top_right' | 'bottom_left' | 'bottom_right';
export type ImageSettings = {
    url: string;
    renderWidth: number;
    renderHeight: number;
    refreshRate: number;
};
export type CameraSettings = {
    protocol: string;
    ip: string;
    port: number;
    user: string;
    pass: string;
};
export type CamOverlaySettings = {
    cameraList: number[];
    coordSystem: CoordSystem;
    posX: number;
    posY: number;
    streamWidth: number;
    streamHeight: number;
};
export type HtmlToOverlayOptions = {
    enabled: boolean;
    configName: string;
    imageSettings: ImageSettings;
    cameraSettings: CameraSettings;
    coSettings: CamOverlaySettings;
};
export declare class HtmlToOverlay {
    private options;
    private stopped;
    private browser;
    private page;
    private startTimer;
    private screenshotTimer;
    private removeImageTimer;
    private co;
    private coConnected;
    private coDowntimeTimer;
    private takeScreenshotPromise;
    constructor(options: HtmlToOverlayOptions);
    start(): Promise<void>;
    stop(): Promise<void>;
    private startBrowser;
    private restartBrowser;
    private takeScreenshot;
    private removeImage;
    private startCamOverlayConnection;
    private computePosition;
}
