"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LedIndicator = void 0;
const util_1 = require("util");
const cjs_1 = require("camstreamerlib/cjs");
const node_1 = require("camstreamerlib/cjs/node");
const utils_1 = require("../utils");
const setTimeoutPromise = (0, util_1.promisify)(setTimeout);
const FLASH_INTERVAL_MS = 500;
class LedIndicator {
    constructor(connHubSettings, ledSettings) {
        this.ledSettings = ledSettings;
        this.startFlashesCount = 0;
        this.greenLedIndicationTimeoutId = null;
        this.redLedIndicationTimeoutId = null;
        const options = (0, utils_1.getCameraOptions)(connHubSettings);
        const httpClient = new node_1.DefaultClient(options);
        this.vapix = new cjs_1.VapixAPI(httpClient);
        this.greenLedPort = ledSettings.led_green_port - 1;
        this.redLedPort = ledSettings.led_red_port - 1;
    }
    setGreenLedState(active) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.vapix.setPorts([
                    {
                        port: this.greenLedPort.toString(),
                        state: active ? 'closed' : 'open',
                    },
                ]);
            }
            catch (e) {
                console.warn('Green led error: If the problem persists, check your led configuration', e);
            }
        });
    }
    setRedLedState(active) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.vapix.setPorts([
                    {
                        port: this.redLedPort.toString(),
                        state: active ? 'closed' : 'open',
                    },
                ]);
            }
            catch (e) {
                console.warn('Red led error: If the problem persists, check your led configuration', e);
            }
        });
    }
    setBothLEDs(bothActive) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.vapix.setPorts([
                    {
                        port: this.greenLedPort.toString(),
                        state: bothActive ? 'closed' : 'open',
                    },
                    {
                        port: this.redLedPort.toString(),
                        state: bothActive ? 'closed' : 'open',
                    },
                ]);
            }
            catch (e) {
                console.warn('Red led error: Please check your led configuration', e);
            }
        });
    }
    greenFlash() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setGreenLedState(true);
            yield setTimeoutPromise(50);
            yield this.setGreenLedState(false);
        });
    }
    redFlash() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setRedLedState(true);
            yield setTimeoutPromise(50);
            yield this.setRedLedState(false);
        });
    }
    indicateOnScriptStart() {
        return __awaiter(this, void 0, void 0, function* () {
            const t1 = Date.now();
            this.startFlashesCount++;
            yield this.greenFlash();
            yield this.redFlash();
            const t2 = Date.now();
            if (this.startFlashesCount < 3) {
                setTimeout(() => this.indicateOnScriptStart(), Math.max(0, FLASH_INTERVAL_MS - (t2 - t1)));
            }
        });
    }
    abortLed(led) {
        return __awaiter(this, void 0, void 0, function* () {
            if (led === 'success' && this.greenLedIndicationTimeoutId) {
                clearTimeout(this.greenLedIndicationTimeoutId);
                this.greenLedIndicationTimeoutId = null;
                yield this.setGreenLedState(false);
            }
            else if (led === 'failure' && this.redLedIndicationTimeoutId) {
                clearTimeout(this.redLedIndicationTimeoutId);
                this.redLedIndicationTimeoutId = null;
                yield this.setRedLedState(false);
            }
        });
    }
    indicateSuccess(ms, repeatTimes) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.abortLed('failure');
            for (let i = 0; i < repeatTimes; i++) {
                yield this.setGreenLedState(true);
                yield setTimeoutPromise(ms);
                yield this.setGreenLedState(false);
                if (i < 1) {
                    yield setTimeoutPromise(100);
                }
            }
        });
    }
    indicateFailure(ms, repeatTimes) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.abortLed('success');
            for (let i = 0; i < repeatTimes; i++) {
                yield this.setRedLedState(true);
                yield setTimeoutPromise(ms);
                yield this.setRedLedState(false);
                if (i < 1) {
                    yield setTimeoutPromise(100);
                }
            }
        });
    }
    destructor() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.greenLedIndicationTimeoutId) {
                    clearTimeout(this.greenLedIndicationTimeoutId);
                    this.greenLedIndicationTimeoutId = null;
                }
                if (this.redLedIndicationTimeoutId) {
                    clearTimeout(this.redLedIndicationTimeoutId);
                    this.redLedIndicationTimeoutId = null;
                }
                yield this.setBothLEDs(false);
            }
            catch (e) {
                console.error('Led destructor error: ', e);
            }
        });
    }
}
exports.LedIndicator = LedIndicator;
