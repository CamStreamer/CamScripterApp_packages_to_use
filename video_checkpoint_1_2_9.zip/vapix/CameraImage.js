"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CameraImage = void 0;
const cjs_1 = require("camstreamerlib/cjs");
const node_1 = require("camstreamerlib/cjs/node");
const utils_1 = require("../utils");
const TIMEOUT_MS = 10000;
class CameraImage {
    constructor(cameraSettings, imageUpload) {
        this.imageUpload = imageUpload;
        const options = (0, utils_1.getCameraOptions)(cameraSettings);
        const httpClient = new node_1.DefaultClient(options);
        this.vapix = new cjs_1.VapixAPI(httpClient);
    }
    getImageDataFromCamera() {
        return __awaiter(this, void 0, void 0, function* () {
            const images = [];
            for (const cameraListIndex in this.imageUpload.camera_list) {
                const vapixCamera = this.imageUpload.camera_list[cameraListIndex] + 1;
                const image = yield this.getCameraImage(vapixCamera.toString());
                images.push({
                    file: image,
                    camera: this.imageUpload.camera_list[cameraListIndex],
                });
            }
            return images;
        });
    }
    getCameraImage(camera) {
        return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            const resolution = this.imageUpload.resolution;
            try {
                const res = yield this.vapix.getCameraImage({
                    resolution: resolution,
                    compression: 10,
                    camera: camera,
                });
                if (res.ok === false) {
                    throw new Error(`GetCameraImage: ${res.status} ${res.statusText}`);
                }
                const imageData = yield res.arrayBuffer();
                resolve(Buffer.from(imageData));
            }
            catch (err) {
                const error = err instanceof Error ? err.message : JSON.stringify(err);
                reject(new Error(`GetCameraImage: ${error}`));
            }
        }));
    }
}
exports.CameraImage = CameraImage;
