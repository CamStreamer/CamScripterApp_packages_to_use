"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Genetec = void 0;
const node_1 = require("camstreamerlib/cjs/node");
const constants_1 = require("./constants");
class Genetec {
    constructor(genetecSettings) {
        this.genetecSettings = genetecSettings;
        this.cameraList = [];
        this.appId = genetecSettings.app_id_enabled ? genetecSettings.app_id : constants_1.CAMSTREAMER_CONNECTOR_APP_ID;
        this.settings = {
            protocol: genetecSettings.protocol,
            ip: genetecSettings.ip,
            port: genetecSettings.port,
            baseUri: genetecSettings.base_uri,
            user: genetecSettings.user,
            pass: genetecSettings.pass,
            appId: this.appId,
        };
        this.agent = new node_1.GenetecAgent(this.settings);
        this.cameraList = genetecSettings.camera_list;
    }
    checkConnection(req, res) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = (_a = req.url) === null || _a === void 0 ? void 0 : _a.split('?')[1];
            const currentSettings = this.getGenetecSettings(queryString);
            try {
                const newAgent = new node_1.GenetecAgent(currentSettings);
                yield newAgent.checkConnection();
                console.log('Connection to Genetec successful');
                res.statusCode = 200;
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.end('{"message": "Genetec connection success"}');
            }
            catch (err) {
                console.error('Cannot connect to Genetec, error:', err);
                res.statusCode = 500;
                res.end('{"message": "Genetec connection error"}');
            }
        });
    }
    sendTestBookmark(req, res) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = (_a = req.url) === null || _a === void 0 ? void 0 : _a.split('?')[1];
            const params = new URLSearchParams(queryString);
            const currentSettings = this.getGenetecSettings(queryString);
            const selectedCameras = params.get('camera_list');
            try {
                if (selectedCameras !== null) {
                    const newAgent = new node_1.GenetecAgent(currentSettings);
                    yield newAgent.sendBookmark(selectedCameras.split(','), 'Testing bookmark from CamStreamer script');
                    res.statusCode = 200;
                    res.setHeader('Access-Control-Allow-Origin', '*');
                    res.end('{"message": "Test bookmark sent"}');
                }
            }
            catch (err) {
                console.error('Cannot send test bookmark, error:', err);
                res.statusCode = 500;
                res.end('{"message": "Cannot send test bookmark"}');
            }
        });
    }
    getCameraOptions(req, res) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = (_a = req.url) === null || _a === void 0 ? void 0 : _a.split('?')[1];
            const currentSettings = this.getGenetecSettings(queryString);
            try {
                const newAgent = new node_1.GenetecAgent(currentSettings);
                const cameraList = yield this.getCameraList(newAgent);
                res.statusCode = 200;
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.end(JSON.stringify(cameraList));
            }
            catch (err) {
                res.statusCode = 500;
                res.end('[]');
            }
        });
    }
    sendBookmark(code, newAgent, currentSelectedCameras) {
        return __awaiter(this, void 0, void 0, function* () {
            const genetecAgent = newAgent !== null && newAgent !== void 0 ? newAgent : this.agent;
            console.log('Sending bookmark... ', code);
            try {
                let selectedCameras = this.cameraList;
                if (currentSelectedCameras !== undefined) {
                    selectedCameras = currentSelectedCameras;
                }
                yield genetecAgent.sendBookmark(selectedCameras, code);
                console.log('Bookmark sent: ', code);
            }
            catch (err) {
                console.error('Cannot send bookmark, error: ', err);
            }
        });
    }
    getCameraList(newAgent) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const genetecAgent = newAgent !== null && newAgent !== void 0 ? newAgent : this.agent;
            const guidsArray = yield genetecAgent.getAllCameraGuids().then((res) => res.Rsp.Result);
            const camerasDetails = yield genetecAgent.getCameraDetails(guidsArray, constants_1.PARAMS);
            const cameraList = [];
            for (let i = 0; i < camerasDetails.length; i++) {
                const camera = camerasDetails[i];
                cameraList.push({
                    index: i,
                    value: (_a = camera.Guid) !== null && _a !== void 0 ? _a : '',
                    label: (_b = camera.Name) !== null && _b !== void 0 ? _b : '',
                });
            }
            return cameraList;
        });
    }
    getGenetecSettings(queryString) {
        var _a, _b, _c, _d, _e, _f;
        const params = new URLSearchParams(queryString);
        const protocolParam = params.get('protocol');
        let protocol;
        if (!this.isValidProtocol(protocolParam)) {
            throw new Error('Invalid protocol specified.');
        }
        else if (this.isValidProtocol(protocolParam)) {
            protocol = protocolParam;
        }
        const currentSettings = {
            protocol: protocol !== null && protocol !== void 0 ? protocol : 'http',
            ip: (_a = params.get('ip')) !== null && _a !== void 0 ? _a : '127.0.0.1',
            port: parseInt((_b = params.get('port')) !== null && _b !== void 0 ? _b : '80'),
            baseUri: (_c = params.get('baseUri')) !== null && _c !== void 0 ? _c : 'WebSdk',
            user: (_d = params.get('user')) !== null && _d !== void 0 ? _d : 'root',
            pass: (_e = params.get('pass')) !== null && _e !== void 0 ? _e : '',
            appId: (_f = params.get('appId')) !== null && _f !== void 0 ? _f : constants_1.CAMSTREAMER_CONNECTOR_APP_ID,
        };
        return currentSettings;
    }
    isValidProtocol(protocol) {
        return protocol === 'http' || protocol === 'https' || protocol === 'https_insecure';
    }
}
exports.Genetec = Genetec;
