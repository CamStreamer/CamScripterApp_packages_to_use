"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Milestone = void 0;
const net = require("net");
class Milestone {
    constructor(milestoneSettings) {
        this.milestoneSettings = milestoneSettings;
        this.milestoneClient = null;
        this.serverConnect();
    }
    serverConnect() {
        const server = net.createServer((client) => {
            if (this.milestoneClient) {
                console.log('Closing connection to the previous Milestone client.');
                this.milestoneClient.end();
                this.milestoneClient.destroy();
            }
            this.milestoneClient = client;
            console.log('Milestone client connected');
            client.on('end', () => {
                console.log('Milestone client disconnected.');
                this.milestoneClient = null;
            });
        });
        server.listen(this.milestoneSettings.port, () => {
            server.on('close', () => {
                console.log('Milestone: TCP server socket is closed.');
                process.exit(1);
            });
            server.on('error', (error) => {
                console.log(JSON.stringify(error));
                process.exit(1);
            });
        });
    }
    sendEvent(code) {
        const validatedCode = code.trim().split(' ').join('');
        const message = `${this.milestoneSettings.transaction_source} ${validatedCode}\n`;
        if (this.milestoneClient) {
            this.milestoneClient.write(message, (err) => {
                if (err) {
                    console.error('Error sending data to Milestone:', err);
                }
                else {
                    console.log('Data sent to Milestone:', `${this.milestoneSettings.transaction_source} ${code}`);
                }
            });
        }
        else {
            console.log('No Milestone client connected.');
        }
    }
}
exports.Milestone = Milestone;
