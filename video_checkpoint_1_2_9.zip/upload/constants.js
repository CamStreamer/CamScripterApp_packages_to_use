"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CAMSTREAMER_CONNECTOR_APP_ID = exports.PARAMS = void 0;
exports.PARAMS = ['Guid', 'Name', 'EntityType'];
exports.CAMSTREAMER_CONNECTOR_APP_ID = 'OUhW5dE35gdnqX/J4eMSIOekvkMiMjQayDmbOKWmAPIi+OQrQvdADQMaLqWcXzyN';
