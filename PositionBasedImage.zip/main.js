"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const net = require("net");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
let activeServices = [];
let settings;
let cos = {};
function deg2rad(angle) {
    return (angle * Math.PI) / 180;
}
function calculateDistance(a, b) {
    let aLatRad = deg2rad(a.latitude);
    let aLonRad = deg2rad(a.longitude);
    let bLatRad = deg2rad(b.latitude);
    let bLonRad = deg2rad(b.longitude);
    let sinDiffLat = Math.sin((aLatRad - bLatRad) / 2);
    let sinDiffLon = Math.sin((aLonRad - bLonRad) / 2);
    let aCosLat = Math.cos(aLatRad);
    let bCosLat = Math.cos(bLatRad);
    let c = Math.pow(sinDiffLat, 2) + aCosLat * bCosLat * Math.pow(sinDiffLon, 2);
    return 2000 * 6371 * Math.asin(Math.sqrt(c));
}
function serverResponseParse(lines) {
    let returnValue = null;
    for (const line of lines) {
        let items = line.split(",");
        if (items.length >= 7 &&
            items[0] === "$GPRMC" &&
            items[3] !== "" &&
            items[4] !== "" &&
            items[5] !== "" &&
            items[6] !== "") {
            let lat = Number.parseFloat(items[3]) / 100;
            let lon = Number.parseFloat(items[5]) / 100;
            let latD = Math.floor(lat);
            let latM = ((lat - Math.floor(lat)) * 100) / 60;
            lat = latD + latM;
            let lonD = Math.floor(lon);
            let lonM = ((lon - Math.floor(lon)) * 100) / 60;
            lon = lonD + lonM;
            if (items[4] == "S") {
                lat *= -1;
            }
            if (items[6] == "W") {
                lon *= -1;
            }
            returnValue = { latitude: lat, longitude: lon };
        }
    }
    return returnValue;
}
function synchroniseCamOverlay() {
    return __awaiter(this, void 0, void 0, function* () {
        for (let idString in cos) {
            let id = Number.parseInt(idString);
            let isEnabled = yield cos[id].isEnabled();
            if (!isEnabled && activeServices.includes(id)) {
                cos[id].setEnabled(true);
            }
            else if (isEnabled && !activeServices.includes(id)) {
                cos[id].setEnabled(false);
            }
        }
    });
}
function isEqual(a, b) {
    let equal = a.length == b.length;
    if (equal) {
        for (let i = 0; i < a.length && equal; i++) {
            equal = equal && a[i] == b[i];
        }
    }
    return equal;
}
function getServiceIDs(actualCoordinates) {
    for (let area of settings.areas) {
        let distance = calculateDistance(actualCoordinates, area.coordinates);
        if (distance <= area.radius) {
            return area.serviceIDs.sort();
        }
    }
    return [];
}
function serverConnect() {
    const server = net.createServer((client) => {
        client.setTimeout(30000);
        let dataBuffer = Buffer.alloc(0);
        client.on("data", (data) => {
            dataBuffer = Buffer.concat([dataBuffer, data]);
            let lines = data.toString().split("\r\n");
            lines.pop();
            const coor = serverResponseParse(lines);
            dataBuffer = Buffer.from(lines[lines.length - 1]);
            if (coor !== null) {
                const ids = getServiceIDs(coor);
                if (!isEqual(ids, activeServices)) {
                    activeServices = ids;
                    synchroniseCamOverlay();
                }
            }
        });
        client.on("timeout", () => {
            console.log("Client request time out.");
            client.end();
            process.exit(1);
        });
    });
    server.listen(10110, () => {
        server.on("close", () => {
            console.log("TCP server socket is closed.");
            process.exit(1);
        });
        server.on("error", (error) => {
            console.log(JSON.stringify(error));
            process.exit(1);
        });
        setInterval(synchroniseCamOverlay, 60000);
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const path = "./localdata/";
            const data = fs.readFileSync(path + "settings.json");
            settings = JSON.parse(data.toString());
        }
        catch (error) {
            console.log("Error with Settings file: ", error);
            return;
        }
        let serviceIDs = [];
        for (let area of settings.areas) {
            area.serviceIDs.sort();
            for (let serviceID of area.serviceIDs) {
                serviceIDs.push(serviceID);
            }
        }
        for (let serviceID of serviceIDs) {
            const options = {
                ip: settings.targetCamera.IP,
                port: settings.targetCamera.port,
                auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
                serviceID,
            };
            try {
                const co = new CamOverlayAPI_1.CamOverlayAPI(options);
                yield co.connect();
                yield co.setEnabled(false);
                cos[serviceID] = co;
            }
            catch (error) {
                console.log(`Cannot connect to CamOverlay service with ID ${serviceID}`);
                console.log(error);
            }
        }
        serverConnect();
    });
}
process.on("unhandledRejection", (reason) => {
    console.log(reason);
    process.exit(1);
});
main();
