"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const child_process_1 = require("child_process");
const settingsSchema_1 = require("./settingsSchema");
const overlayProcesses = [];
function start() {
    const settings = readConfiguration();
    if (settings === undefined || settings.linuxUser.length === 0) {
        console.error('Linux user not set');
        setTimeout(() => { }, 300000);
        return;
    }
    settings.overlayList.forEach((overlaySettings) => {
        var _a, _b, _c;
        if (overlaySettings.enabled &&
            overlaySettings.imageSettings.url.length &&
            overlaySettings.cameraSettings.ip.length &&
            overlaySettings.cameraSettings.user.length &&
            overlaySettings.cameraSettings.pass.length &&
            overlaySettings.coSettings.cameraList !== null &&
            ((_a = overlaySettings.coSettings.cameraList) === null || _a === void 0 ? void 0 : _a.length)) {
            const scriptPath = path.join(__dirname, 'htmlToOverlayProcess.js');
            const child = (0, child_process_1.spawn)('sudo', [
                '-u',
                settings.linuxUser,
                'node',
                scriptPath,
                JSON.stringify(overlaySettings),
            ]);
            (_b = child.stdout) === null || _b === void 0 ? void 0 : _b.on('data', (data) => {
                process.stdout.write(data);
            });
            (_c = child.stderr) === null || _c === void 0 ? void 0 : _c.on('data', (data) => {
                process.stderr.write(data);
            });
            child.on('error', (error) => {
                console.error(`spawn error: ${error}`);
            });
            overlayProcesses.push(child);
        }
    });
    if (overlayProcesses.length === 0) {
        console.log('No configured HTML overlay found');
        setTimeout(() => { }, 300000);
    }
}
function stopAllPackages() {
    overlayProcesses.forEach((child) => {
        child.kill();
    });
}
function readConfiguration() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        const parsedData = JSON.parse(data.toString());
        const result = settingsSchema_1.settingsSchema.safeParse(parsedData);
        if (!result.success) {
            console.error('Invalid configuration:', result.error.errors);
            return undefined;
        }
        return result.data;
    }
    catch (err) {
        console.log('No configuration found');
        return undefined;
    }
}
process.on('SIGINT', () => {
    console.log('App exit - configuration changed');
    stopAllPackages();
    process.exit();
});
process.on('SIGTERM', () => {
    console.log('App exit');
    stopAllPackages();
    process.exit();
});
console.log('App started');
start();
