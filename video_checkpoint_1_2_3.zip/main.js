"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const schema_1 = require("./schema");
const QrCodeReader_1 = require("./input/QrCodeReader");
const Widget_1 = require("./graphics/Widget");
const AxisCameraStation_1 = require("./upload/AxisCameraStation");
const LedIndicator_1 = require("./vapix/LedIndicator");
const GoogleDriveAPI_1 = require("./upload/GoogleDriveAPI");
const CameraImage_1 = require("./vapix/CameraImage");
const CameraVideo_1 = require("./vapix/CameraVideo");
const videoScheduler_1 = require("./videoScheduler");
const ftpServer_1 = require("./upload/ftpServer");
const SharePointUploader_1 = require("./upload/SharePointUploader");
const AxisEvents_1 = require("./upload/AxisEvents");
const READ_BARCODE_HIGHLIGHT_DURATION_MS = 250;
const UPLOADS_HIGHLIGHT_DURATION_MS = 250;
const FAIL_INDICATION_DURATION_MS = 250;
let settings;
let axisEventsConnHub;
let axisEventsCamera;
let ledIndicator;
let widget;
let acs;
let cameraImage;
let cameraVideo;
let googleDriveApi;
let ftpServer;
let videoScheduler;
let shouldShowWidget = false;
let sharePointUploader;
function readSettings() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return schema_1.serverDataSchema.parse(JSON.parse(data.toString()));
    }
    catch (err) {
        console.log('Read settings error:', err instanceof Error ? err.message : 'unknown');
        process.exit(1);
    }
}
function showWidget(code, visibilityTimeSec, shouldShowWidget) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (widget && shouldShowWidget) {
                console.log(`Display widget, code: "${code}"`);
                yield widget.showBarCode(code, visibilityTimeSec);
                return true;
            }
            return false;
        }
        catch (err) {
            console.error('Show widget:', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function sendAxisEventConnHub(code) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (axisEventsConnHub) {
                console.log(`Send Axis event (connection hub), code: "${code}"`);
                yield axisEventsConnHub.sendEvent(code);
            }
            return true;
        }
        catch (err) {
            console.error('Axis event (connection hub):', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function sendAxisEventCamera(code) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (axisEventsCamera) {
                console.log(`Send Axis event (camera), code: "${code}"`);
                yield axisEventsCamera.sendEvent(code);
            }
            return true;
        }
        catch (err) {
            console.error('Axis event (camera):', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function sendAcsEvent(code) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (acs) {
                console.log(`Send ACS event, code: "${code}"`);
                yield acs.sendEvent(code);
            }
            return true;
        }
        catch (err) {
            console.error('ACS event:', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function uploadImages(code) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (googleDriveApi === undefined && sharePointUploader === undefined && ftpServer === undefined) {
                return true;
            }
            const imageData = yield (cameraImage === null || cameraImage === void 0 ? void 0 : cameraImage.getImageDataFromCamera());
            if (!imageData) {
                return false;
            }
            const promiseArr = yield Promise.all([
                settings.google_drive.type === 'image'
                    ? googleDriveApi === null || googleDriveApi === void 0 ? void 0 : googleDriveApi.uploadImages(code, imageData, settings.camera.serial_number)
                    : true,
                sharePointUploader === null || sharePointUploader === void 0 ? void 0 : sharePointUploader.uploadImages(code, imageData),
                settings.ftp_server.type === 'image'
                    ? ftpServer === null || ftpServer === void 0 ? void 0 : ftpServer.queueImageUpload(code, imageData, settings.camera.serial_number)
                    : true,
            ]);
            if (promiseArr.includes(false)) {
                return false;
            }
            else {
                return true;
            }
        }
        catch (err) {
            console.error('Upload images:', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function uploadVideo(code) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (videoScheduler !== undefined) {
                return yield videoScheduler.onBarCodeScan(code);
            }
            return false;
        }
        catch (err) {
            console.error('Upload video:', err instanceof Error ? err.message : 'unknown');
            return false;
        }
    });
}
function main() {
    var _a, _b;
    try {
        settings = readSettings();
        if (settings.led.enabled) {
            if (settings.conn_hub.ip.length !== 0 &&
                settings.conn_hub.user.length !== 0 &&
                settings.conn_hub.pass.length !== 0 &&
                settings.led.led_green_port !== undefined &&
                settings.led.led_red_port !== undefined) {
                ledIndicator = new LedIndicator_1.LedIndicator(settings.conn_hub, settings.led);
            }
            else {
                console.log('Led indication is not configured and thus is disabled.');
            }
        }
        if (settings.output_camera.ip.length !== 0 &&
            settings.output_camera.user.length !== 0 &&
            settings.output_camera.pass.length !== 0) {
            widget = new Widget_1.Widget(settings.output_camera, settings.widget);
        }
        else {
            console.log('The CamOverlay widget is not configured and thus is disabled.');
        }
        if ((_a = settings.axis_events) === null || _a === void 0 ? void 0 : _a.conn_hub) {
            if (settings.conn_hub.ip.length !== 0 &&
                settings.conn_hub.user.length !== 0 &&
                settings.conn_hub.pass.length !== 0) {
                axisEventsConnHub = new AxisEvents_1.AxisEvents(settings.conn_hub);
            }
            else {
                console.log('Axis events integration for connectivity hub is not configured and thus is disabled.');
            }
        }
        if ((_b = settings.axis_events) === null || _b === void 0 ? void 0 : _b.camera) {
            if (settings.camera.ip.length !== 0 &&
                settings.camera.user.length !== 0 &&
                settings.camera.pass.length !== 0) {
                axisEventsCamera = new AxisEvents_1.AxisEvents(settings.camera);
            }
            else {
                console.log('Axis events integration for camera is not configured and thus is disabled.');
            }
        }
        if (settings.acs.enabled) {
            if (settings.acs.ip.length !== 0 &&
                settings.acs.user.length !== 0 &&
                settings.acs.pass.length !== 0 &&
                settings.acs.source_key.length !== 0) {
                acs = new AxisCameraStation_1.AxisCameraStation(settings.acs);
            }
            else {
                console.log('Axis Camera Station is not configured and thus is disabled.');
            }
        }
        if (settings.google_drive.enabled) {
            if (settings.camera.ip.length !== 0 &&
                settings.camera.user.length !== 0 &&
                settings.camera.pass.length !== 0) {
                googleDriveApi = new GoogleDriveAPI_1.GoogleDriveAPI(settings.google_drive);
            }
            else {
                console.log('The Google Drive upload is not configured and thus is disabled.');
            }
        }
        if (settings.ftp_server.enabled) {
            if (settings.ftp_server.ip.length !== 0 &&
                settings.ftp_server.user.length !== 0 &&
                settings.ftp_server.pass.length !== 0) {
                ftpServer = new ftpServer_1.FTPServer(settings.ftp_server);
            }
            else {
                console.log('FTP Server is not configured and thus is disabled.');
            }
        }
        if (settings.share_point.enabled) {
            if (settings.share_point.url.length !== 0 &&
                settings.share_point.output_dir.length !== 0 &&
                settings.share_point.client_secret.length !== 0 &&
                settings.share_point.client_id.length !== 0 &&
                settings.share_point.tenant_id.length !== 0) {
                sharePointUploader = new SharePointUploader_1.SharePointUploader(settings.share_point);
            }
            else {
                console.log('The SharePoint upload is not configured and thus is disabled.');
            }
        }
        if (cameraImage === undefined) {
            cameraImage = new CameraImage_1.CameraImage(settings.camera, settings.image_upload);
        }
        if (cameraVideo === undefined) {
            cameraVideo = new CameraVideo_1.CameraVideo(settings.camera);
        }
        if (videoScheduler === undefined) {
            videoScheduler = new videoScheduler_1.VideoScheduler(ftpServer, googleDriveApi, cameraVideo, settings, settings.camera.serial_number, settings.video_upload);
        }
        const qrCodeReader = new QrCodeReader_1.QRCodeReader(settings.barcode_validation_rule);
        qrCodeReader.on('valid_reading', (data) => __awaiter(this, void 0, void 0, function* () {
            console.log(`Reader - valid code received: "${data.code}"`);
            yield (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateSuccess(READ_BARCODE_HIGHLIGHT_DURATION_MS, 1));
            if (videoScheduler !== undefined) {
                shouldShowWidget = videoScheduler.shouldShowBarcode(data.code);
            }
            const showWidgetStatus = yield showWidget(data.code, settings.widget.visibility_time_sec, shouldShowWidget);
            yield sendAxisEventConnHub(data.code);
            yield sendAxisEventCamera(data.code);
            yield sendAcsEvent(data.code);
            const promiseArr = [];
            let imagesUploadStatus;
            let videoUploadStatus;
            if ((showWidgetStatus && googleDriveApi !== undefined && settings.google_drive.type === 'image') ||
                (showWidgetStatus && ftpServer !== undefined && settings.ftp_server.type === 'image')) {
                promiseArr.push(uploadImages(data.code).then((result) => {
                    imagesUploadStatus = result;
                    return result;
                }));
            }
            if ((showWidgetStatus && googleDriveApi !== undefined && settings.google_drive.type === 'video') ||
                (showWidgetStatus && ftpServer !== undefined && settings.ftp_server.type === 'video')) {
                promiseArr.push(uploadVideo(data.code).then((result) => {
                    videoUploadStatus = result;
                    return result;
                }));
            }
            const results = yield Promise.allSettled(promiseArr);
            if (results.length === 1) {
                if (videoUploadStatus !== undefined) {
                    if (videoUploadStatus && !(videoScheduler === null || videoScheduler === void 0 ? void 0 : videoScheduler.getRecordingStatus)) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateSuccess(UPLOADS_HIGHLIGHT_DURATION_MS, 2));
                    }
                    else if (!videoUploadStatus && !(videoScheduler === null || videoScheduler === void 0 ? void 0 : videoScheduler.getRecordingStatus)) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateFailure(FAIL_INDICATION_DURATION_MS, 2));
                    }
                }
                if (imagesUploadStatus !== undefined) {
                    if (imagesUploadStatus) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateSuccess(UPLOADS_HIGHLIGHT_DURATION_MS, 2));
                    }
                    else {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateFailure(FAIL_INDICATION_DURATION_MS, 2));
                    }
                }
            }
            if (results.length === 2) {
                if (imagesUploadStatus !== undefined) {
                    if (imagesUploadStatus) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateSuccess(UPLOADS_HIGHLIGHT_DURATION_MS, 2));
                    }
                    else {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateFailure(FAIL_INDICATION_DURATION_MS, 2));
                    }
                }
                if (videoUploadStatus !== undefined) {
                    if (videoUploadStatus && !(videoScheduler === null || videoScheduler === void 0 ? void 0 : videoScheduler.getRecordingStatus)) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateSuccess(UPLOADS_HIGHLIGHT_DURATION_MS, 2));
                    }
                    else if (!videoUploadStatus && !(videoScheduler === null || videoScheduler === void 0 ? void 0 : videoScheduler.getRecordingStatus)) {
                        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateFailure(FAIL_INDICATION_DURATION_MS, 2));
                    }
                }
            }
        }));
        qrCodeReader.on('invalid_reading', (data) => __awaiter(this, void 0, void 0, function* () {
            console.log(`Reader - invalid code received: "${data.code}"`);
            yield (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateFailure(READ_BARCODE_HIGHLIGHT_DURATION_MS, 1));
        }));
        void (ledIndicator === null || ledIndicator === void 0 ? void 0 : ledIndicator.indicateOnScriptStart());
        console.log('Application started');
    }
    catch (err) {
        console.error('Application start:', err);
        process.exit(1);
    }
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
    console.error('Unhandled rejection:', err);
});
main();
