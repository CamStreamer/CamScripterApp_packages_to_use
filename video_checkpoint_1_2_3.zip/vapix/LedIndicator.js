"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LedIndicator = void 0;
const util_1 = require("util");
const CameraVapix_1 = require("camstreamerlib/CameraVapix");
const setTimeoutPromise = (0, util_1.promisify)(setTimeout);
const FLASH_INTERVAL_MS = 500;
class LedIndicator {
    constructor(connHubSettings, ledSettings) {
        this.ledSettings = ledSettings;
        this.startFlashesCount = 0;
        this.greenLedIndicationTimeoutId = null;
        this.redLedIndicationTimeoutId = null;
        const options = {
            tls: connHubSettings.protocol !== 'http',
            tlsInsecure: connHubSettings.protocol === 'https_insecure',
            ip: connHubSettings.ip,
            port: connHubSettings.port,
            user: connHubSettings.user,
            pass: connHubSettings.pass,
        };
        this.cameraVapix = new CameraVapix_1.CameraVapix(options);
    }
    setGreenLedState(active) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.ledSettings.led_green_port !== undefined) {
                    yield this.cameraVapix.setOutputState(this.ledSettings.led_green_port, active);
                }
            }
            catch (e) {
                console.warn('Green led error: If the problem persists, check your led configuration', e);
            }
        });
    }
    setRedLedState(active) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.ledSettings.led_red_port !== undefined) {
                    yield this.cameraVapix.setOutputState(this.ledSettings.led_red_port, active);
                }
            }
            catch (e) {
                console.warn('Red led error: If the problem persists, check your led configuration', e);
            }
        });
    }
    setBothLEDs(bothActive) {
        return __awaiter(this, void 0, void 0, function* () {
            yield Promise.all([this.setGreenLedState(bothActive), this.setRedLedState(bothActive)]);
        });
    }
    greenFlash() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setGreenLedState(true);
            yield setTimeoutPromise(50);
            yield this.setGreenLedState(false);
        });
    }
    redFlash() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setRedLedState(true);
            yield setTimeoutPromise(50);
            yield this.setRedLedState(false);
        });
    }
    indicateOnScriptStart() {
        return __awaiter(this, void 0, void 0, function* () {
            const t1 = Date.now();
            this.startFlashesCount++;
            yield this.greenFlash();
            yield this.redFlash();
            const t2 = Date.now();
            if (this.startFlashesCount < 3) {
                setTimeout(() => this.indicateOnScriptStart(), Math.max(0, FLASH_INTERVAL_MS - (t2 - t1)));
            }
        });
    }
    abortLed(led) {
        return __awaiter(this, void 0, void 0, function* () {
            if (led === 'success' && this.greenLedIndicationTimeoutId) {
                clearTimeout(this.greenLedIndicationTimeoutId);
                this.greenLedIndicationTimeoutId = null;
                yield this.setGreenLedState(false);
            }
            else if (led === 'failure' && this.redLedIndicationTimeoutId) {
                clearTimeout(this.redLedIndicationTimeoutId);
                this.redLedIndicationTimeoutId = null;
                yield this.setRedLedState(false);
            }
        });
    }
    indicateSuccess(ms, repeatTimes) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.abortLed('failure');
            for (let i = 0; i < repeatTimes; i++) {
                yield this.setGreenLedState(true);
                yield setTimeoutPromise(ms);
                yield this.setGreenLedState(false);
                if (i < 1) {
                    yield setTimeoutPromise(100);
                }
            }
        });
    }
    indicateFailure(ms, repeatTimes) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.abortLed('success');
            for (let i = 0; i < repeatTimes; i++) {
                yield this.setRedLedState(true);
                yield setTimeoutPromise(ms);
                yield this.setRedLedState(false);
                if (i < 1) {
                    yield setTimeoutPromise(100);
                }
            }
        });
    }
    destructor() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.greenLedIndicationTimeoutId) {
                clearTimeout(this.greenLedIndicationTimeoutId);
                this.greenLedIndicationTimeoutId = null;
            }
            if (this.redLedIndicationTimeoutId) {
                clearTimeout(this.redLedIndicationTimeoutId);
                this.redLedIndicationTimeoutId = null;
            }
            yield this.setBothLEDs(false);
        });
    }
}
exports.LedIndicator = LedIndicator;
