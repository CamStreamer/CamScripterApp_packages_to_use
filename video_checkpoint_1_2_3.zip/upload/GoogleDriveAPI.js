"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleDriveAPI = void 0;
const Stream = require("stream");
const drive_1 = require("@googleapis/drive");
const google_auth_library_1 = require("google-auth-library");
const utils_1 = require("../utils");
class GoogleDriveAPI {
    constructor(googleDriveSettings) {
        this.googleDriveSettings = googleDriveSettings;
        this.fileType = googleDriveSettings.type;
    }
    uploadImages(code, images, serialNumber) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.fileType !== 'image') {
                return;
            }
            const stripedCode = (0, utils_1.stripCode)(code);
            const dateInfo = (0, utils_1.getDate)();
            const authClient = yield this.authorize();
            const googleDrive = (0, drive_1.drive)({ version: 'v3', auth: authClient });
            const folderId = yield this.createFolder(googleDrive, dateInfo.date);
            const baseImageName = (0, utils_1.createFileName)(stripedCode, new Date(), serialNumber);
            console.log(`Uploading image(s), code: "${code}", to Google Drive...`);
            try {
                yield Promise.all(images.map((imageData) => __awaiter(this, void 0, void 0, function* () {
                    const imageName = `${baseImageName}_camera${imageData.camera + 1}.jpg`;
                    yield this.uploadImageFile(googleDrive, folderId, imageData.file, imageName);
                })));
                console.log(`Image(s) ${baseImageName}.jpg uploaded successfully to Google Drive.`);
                return true;
            }
            catch (err) {
                console.error(`Error uploading image(s) ${baseImageName}.jpg to Google Drive:`, err instanceof Error ? err.message : 'unknown');
                return false;
            }
        });
    }
    uploadVideo(recording, name, code) {
        return __awaiter(this, void 0, void 0, function* () {
            const dateInfo = (0, utils_1.getDate)();
            console.log(`Uploading recording, code: "${code}", to Google Drive...`);
            try {
                const authClient = yield this.authorize();
                const googleDrive = (0, drive_1.drive)({ version: 'v3', auth: authClient });
                const folderId = yield this.createFolder(googleDrive, dateInfo.date);
                yield this.uploadVideoFile(googleDrive, folderId, recording, name);
                console.log(`Recording ${name} uploaded successfully to Google Drive.`);
                return true;
            }
            catch (err) {
                console.error(`Error uploading recording ${name} to Google Drive:`, err instanceof Error ? err.message : 'unknown');
                return false;
            }
        });
    }
    authorize() {
        return __awaiter(this, void 0, void 0, function* () {
            const privateKey = this.googleDriveSettings.private_key.split(String.raw `\n`).join('\n');
            const scopes = ['https://www.googleapis.com/auth/drive.file'];
            const jwtClient = new google_auth_library_1.JWT(this.googleDriveSettings.email, undefined, privateKey, scopes);
            yield jwtClient.authorize();
            return jwtClient;
        });
    }
    createFolder(drive, folderName) {
        return __awaiter(this, void 0, void 0, function* () {
            const folderSearch = yield drive.files.list({
                q: `mimeType = 'application/vnd.google-apps.folder' and name = '${folderName}' and '${this.googleDriveSettings.folder_id}' in parents`,
                fields: 'nextPageToken, files(id, name)',
                spaces: 'drive',
            });
            let folderId;
            if (folderSearch.data.files !== undefined &&
                folderSearch.data.files.length > 0 &&
                typeof folderSearch.data.files[0].id === 'string') {
                folderId = folderSearch.data.files[0].id;
            }
            else {
                const folder = yield drive.files.create({
                    fields: 'id',
                    requestBody: {
                        name: folderName,
                        mimeType: 'application/vnd.google-apps.folder',
                        parents: [this.googleDriveSettings.folder_id],
                    },
                });
                if (typeof folder.data.id !== 'string') {
                    throw new Error('GoogleDriveAPI: cannot create folder');
                }
                folderId = folder.data.id;
            }
            return folderId;
        });
    }
    uploadImageFile(drive, folderId, fileData, fileName) {
        return __awaiter(this, void 0, void 0, function* () {
            const readableStream = new Stream.Readable();
            readableStream.push(fileData);
            readableStream.push(null);
            const file = yield drive.files.create({
                media: {
                    body: readableStream,
                },
                fields: 'id',
                requestBody: {
                    name: fileName,
                    parents: [folderId],
                },
            });
            return file.data.id;
        });
    }
    uploadVideoFile(drive, folderId, recording, name) {
        return __awaiter(this, void 0, void 0, function* () {
            const readableStream = yield (0, utils_1.convertWebStreamToNodeReadable)(recording);
            const file = yield drive.files.create({
                media: {
                    body: readableStream,
                },
                fields: 'id',
                requestBody: {
                    name: name,
                    parents: [folderId],
                },
            });
            return file.data.id;
        });
    }
}
exports.GoogleDriveAPI = GoogleDriveAPI;
