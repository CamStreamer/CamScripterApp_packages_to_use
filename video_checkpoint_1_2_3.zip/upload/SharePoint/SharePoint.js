"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharePoint = void 0;
const SharePointAuthorization_1 = require("./SharePointAuthorization");
const node_fetch_1 = require("node-fetch");
const SITE_EXPIRATION_S = 24 * 60 * 60;
class SharePoint {
    constructor(data) {
        this.data = data;
        this.headers = null;
        this.site = null;
        this.siteExpiresAtS = 0;
        this.authenticate = () => __awaiter(this, void 0, void 0, function* () {
            const spAuth = new SharePointAuthorization_1.SharePointAuthorization(this.data);
            const authToken = yield spAuth.getAuthToken();
            if (!authToken) {
                throw new Error('Authorization is missing.');
            }
            this.headers = { Authorization: authToken, Accept: 'application/json;odata=verbose' };
            if (Date.now() / 1000 > this.siteExpiresAtS) {
                yield this.getWebEndpoint();
                this.siteExpiresAtS = Date.now() / 1000 + SITE_EXPIRATION_S;
            }
        });
        this.getFormDigestValue = () => __awaiter(this, void 0, void 0, function* () {
            this.checkHeaders();
            const res = yield (0, node_fetch_1.default)(`${this.data.url}/_api/contextinfo`, {
                method: 'post',
                headers: Object.assign(Object.assign({}, this.headers), { 'Content-Type': 'application/json;odata=verbose', 'Response-Type': 'json' }),
            });
            const data = (yield res.json());
            return data.d.GetContextWebInformation.FormDigestValue;
        });
    }
    getWebEndpoint() {
        return __awaiter(this, void 0, void 0, function* () {
            this.checkHeaders();
            const res = yield (0, node_fetch_1.default)(`${this.data.url}/_api/web`, {
                method: 'GET',
                headers: Object.assign(Object.assign({}, this.headers), { 'Response-Type': 'json' }),
            });
            const data = (yield res.json());
            const site = data.d;
            this.site = {
                id: site.Id,
                title: site.Title,
                description: site.Description,
                created: site.Created,
                serverRelativeUrl: site.ServerRelativeUrl,
                lastModified: site.LastItemUserModifiedDate,
            };
        });
    }
    uploadFile(file, fileName, dir) {
        return __awaiter(this, void 0, void 0, function* () {
            this.checkHeaders();
            this.checkSite();
            const formDigestValue = yield this.getFormDigestValue();
            const path = encodeURIComponent(this.data.output_dir + dir);
            const fileNameE = encodeURIComponent(fileName);
            if (!fileNameE) {
                throw new Error('You must provide a file name.');
            }
            const res = yield (0, node_fetch_1.default)(`${this.data.url}/_api/web/GetFolderByServerRelativeUrl('${this.site.serverRelativeUrl}${path}')/Files/add(url='${fileName}', overwrite=true)`, {
                method: 'post',
                body: file,
                headers: Object.assign(Object.assign({}, this.headers), { 'X-RequestDigest': formDigestValue }),
            });
            const data = (yield res.json());
            if (data.error !== undefined) {
                console.log(data.error);
                throw new Error('image was not uploaded due to error');
            }
        });
    }
    createFolder(name) {
        return __awaiter(this, void 0, void 0, function* () {
            this.checkHeaders();
            this.checkSite();
            const formDigestValue = yield this.getFormDigestValue();
            const dirPath = encodeURIComponent(`${this.data.output_dir}/${name}`);
            yield (0, node_fetch_1.default)(`${this.data.url}/_api/web/folders`, {
                method: 'post',
                headers: Object.assign(Object.assign({}, this.headers), { 'content-type': 'application/json;odata=verbose', 'X-RequestDigest': formDigestValue, 'Response-Type': 'json' }),
                body: JSON.stringify({
                    __metadata: { type: 'SP.Folder' },
                    ServerRelativeUrl: `${this.site.serverRelativeUrl}${dirPath}`,
                }),
            });
        });
    }
    checkHeaders() {
        if (!this.headers) {
            throw new Error('No headers, you must authenticate.');
        }
    }
    checkSite() {
        if (!this.site) {
            throw new Error('No site, you must call getWebEndpoint.');
        }
    }
}
exports.SharePoint = SharePoint;
