"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applicationSchema = exports.connectionParamsSchema = void 0;
const zod_1 = require("zod");
exports.connectionParamsSchema = zod_1.z.object({
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
    port: zod_1.z.number().positive().lt(65535),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
});
exports.applicationSchema = zod_1.z.object({
    acs: exports.connectionParamsSchema.merge(zod_1.z.object({
        source_key: zod_1.z.string(),
        active: zod_1.z.boolean(),
        condition_delay: zod_1.z.number().int(),
        condition_operator: zod_1.z.number().int().min(0).max(4),
        condition_value: zod_1.z.coerce.string(),
        repeat_after: zod_1.z.number().min(0),
    })),
    camera: exports.connectionParamsSchema.merge(zod_1.z.object({
        service_id: zod_1.z.number(),
        value_field_name: zod_1.z.string(),
        unit_field_name: zod_1.z.string(),
    })),
    event_camera: exports.connectionParamsSchema.merge(zod_1.z.object({
        active: zod_1.z.boolean(),
        condition_delay: zod_1.z.number().int(),
        condition_operator: zod_1.z.number().int().min(0).max(4),
        condition_value: zod_1.z.coerce.string(),
    })),
    scale: zod_1.z.object({
        ip: zod_1.z.union([zod_1.z.string().ip(), zod_1.z.literal('')]),
        port: zod_1.z.number().positive().lt(65535),
        refresh_rate: zod_1.z.number().positive(),
    }),
});
