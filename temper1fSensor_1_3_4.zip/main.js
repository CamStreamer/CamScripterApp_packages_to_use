"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const https = require("https");
const TempSensorReader_1 = require("./TempSensorReader");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
const CamScripterAPICameraEventsGenerator_1 = require("camstreamerlib/CamScripterAPICameraEventsGenerator");
let sensorReader = null;
let acsSendTimestamp = null;
let acsConditionTimer = null;
let sentActiveState = false;
let cscConnected = false;
let cscEventDeclared = false;
let cscEventConditionTimer = null;
let coUpdating = false;
let settings = null;
try {
    const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
    settings = JSON.parse(data.toString());
}
catch (err) {
    console.log('No settings file found');
    process.exit(1);
}
const coConfigured = settings.camera_ip.length !== 0 &&
    settings.camera_user.length !== 0 &&
    settings.camera_pass.length !== 0 &&
    settings.field_name.length !== 0;
const acsConfigured = ((_a = settings.acs_ip) === null || _a === void 0 ? void 0 : _a.length) != 0 &&
    ((_b = settings.acs_user) === null || _b === void 0 ? void 0 : _b.length) != 0 &&
    ((_c = settings.acs_pass) === null || _c === void 0 ? void 0 : _c.length) != 0 &&
    ((_d = settings.acs_source_key) === null || _d === void 0 ? void 0 : _d.length) != 0 &&
    settings.acs_condition_delay != null &&
    settings.acs_condition_operator != null &&
    settings.acs_condition_value != null;
const eventsConfigured = settings.event_camera_ip.length !== 0 &&
    settings.event_camera_user.length !== 0 &&
    settings.event_camera_pass.length !== 0 &&
    settings.event_condition_delay != null &&
    settings.event_condition_operator != null &&
    settings.event_condition_value != null;
let co = null;
if (coConfigured) {
    co = new CamOverlayAPI_1.CamOverlayAPI({
        tls: settings.camera_protocol !== 'http',
        tlsInsecure: settings.camera_protocol === 'https_insecure',
        ip: settings.camera_ip,
        port: settings.camera_port,
        auth: settings.camera_user + ':' + settings.camera_pass,
    });
}
let csc = null;
if (eventsConfigured) {
    csc = new CamScripterAPICameraEventsGenerator_1.CamScripterAPICameraEventsGenerator({
        tls: settings.event_camera_protocol !== 'http',
        tlsInsecure: settings.event_camera_protocol === 'https_insecure',
        ip: settings.event_camera_ip,
        port: settings.event_camera_port,
        auth: settings.event_camera_user + ':' + settings.event_camera_pass,
    });
}
function onePeriod() {
    return __awaiter(this, void 0, void 0, function* () {
        let nextCheckTimeout = 1000;
        try {
            if (sensorReader === null) {
                sensorReader = new TempSensorReader_1.TempSensorReader();
            }
            const sensorData = yield sensorReader.readSensorData();
            const temperature = convertTemperature(sensorData.temp, settings.unit);
            if (coConfigured) {
                updateCOGraphics(temperature.toFixed(1) + ' ' + UNITS[settings.unit]);
            }
            if (acsConfigured) {
                checkConditionAndSendAcsEvent(temperature);
            }
            if (eventsConfigured) {
                checkCondtionAndSendCameraEvent(temperature);
            }
        }
        catch (error) {
            nextCheckTimeout = 10000;
            sensorReader = null;
            console.error(error);
            if (coConfigured) {
                yield updateCOGraphics('No Data');
            }
        }
        finally {
            setTimeout(onePeriod, nextCheckTimeout);
        }
    });
}
const UNITS = { f: '°F', c: '°C' };
const RATIOS = { f: [1.8, 32], c: [1, 0] };
function convertTemperature(num, unitTag) {
    const r = RATIOS[unitTag];
    return num * r[0] + r[1];
}
function updateCOGraphics(text) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (coUpdating) {
                return;
            }
            coUpdating = true;
            yield co.updateCGText(settings.service_id, [
                {
                    field_name: settings.field_name,
                    text,
                },
            ]);
            coUpdating = false;
        }
        catch (err) {
            console.error('Update CamOverlay graphics error:', err);
            setTimeout(() => {
                coUpdating = false;
            }, 10000);
        }
    });
}
function checkConditionAndSendAcsEvent(temperature) {
    if (isConditionActive(temperature, settings.acs_condition_operator, settings.acs_condition_value)) {
        if (acsConditionTimer) {
            if (acsSendTimestamp &&
                settings.acs_repeat_after !== 0 &&
                Date.now() - acsSendTimestamp >= settings.acs_repeat_after * 1000) {
                clearTimeout(acsConditionTimer);
                sendAcsEventTimerCallback(temperature);
            }
        }
        else {
            const timerTime = settings.acs_condition_delay * 1000;
            acsConditionTimer = setTimeout(() => sendAcsEventTimerCallback(temperature), timerTime);
        }
    }
    else if (acsConditionTimer) {
        acsSendTimestamp = null;
        clearTimeout(acsConditionTimer);
        acsConditionTimer = null;
    }
}
function sendAcsEventTimerCallback(temperature) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield sendAcsEvent(temperature);
            acsSendTimestamp = Date.now();
        }
        catch (err) {
            console.error('ACS error:', err);
            acsConditionTimer = setTimeout(() => sendAcsEventTimerCallback(temperature), 5000);
        }
    });
}
function checkCondtionAndSendCameraEvent(temperature) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const conditionActive = isConditionActive(temperature, settings.event_condition_operator, settings.event_condition_value);
            if (!(yield connectCameraEvents())) {
                return;
            }
            if (!cscEventDeclared) {
                yield declareCameraEvent();
                cscEventDeclared = true;
            }
            if (conditionActive != sentActiveState && (!cscEventConditionTimer || !conditionActive)) {
                const timerTime = conditionActive ? settings.event_condition_delay * 1000 : 0;
                clearTimeout(cscEventConditionTimer);
                cscEventConditionTimer = setTimeout(() => sendCameraEventTimerCallback(conditionActive), timerTime);
            }
        }
        catch (err) {
            console.error('Camera events error:', err);
        }
    });
}
function sendCameraEventTimerCallback(conditionActive) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield sendCameraEvent(conditionActive);
            sentActiveState = conditionActive;
            cscEventConditionTimer = null;
        }
        catch (err) {
            console.error('Camera events error:', err);
            cscEventConditionTimer = setTimeout(() => sendCameraEventTimerCallback(conditionActive), 5000);
        }
    });
}
function isConditionActive(temperature, operator, conditionValue) {
    switch (operator) {
        case 0:
            return temperature === conditionValue;
        case 1:
            return temperature > conditionValue;
        case 2:
            return temperature < conditionValue;
        case 3:
            return temperature >= conditionValue;
        case 4:
            return temperature <= conditionValue;
    }
}
function sendAcsEvent(temperature) {
    return new Promise((resolve, reject) => {
        const date = new Date();
        const year = date.getUTCFullYear();
        const month = pad(date.getUTCMonth() + 1, 2);
        const day = pad(date.getUTCDate(), 2);
        const hours = pad(date.getUTCHours(), 2);
        const minutes = pad(date.getUTCMinutes(), 2);
        const seconds = pad(date.getUTCSeconds(), 2);
        const dateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        const event = {
            addExternalDataRequest: {
                occurrenceTime: dateString,
                source: settings.acs_source_key,
                externalDataType: 'temper1fSensor',
                data: {
                    temperature: temperature.toFixed(1),
                    unit: settings.unit.toUpperCase(),
                },
            },
        };
        const eventData = JSON.stringify(event);
        const req = https.request({
            method: 'POST',
            host: settings.acs_ip,
            port: 55756,
            path: '/Acs/Api/ExternalDataFacade/AddExternalData',
            auth: settings.acs_user + ':' + settings.acs_pass,
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': eventData.length,
            },
            rejectUnauthorized: false,
        }, (res) => {
            if (res.statusCode == 200) {
                resolve();
            }
            else {
                reject(new Error(`status code: ${res.statusCode}`));
            }
        });
        req.on('error', reject);
        req.write(eventData);
        req.end();
    });
}
function connectCameraEvents() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!cscConnected) {
            csc.removeAllListeners();
            csc.on('open', () => {
                console.log('CSc: connected');
                cscConnected = true;
            });
            csc.on('error', (err) => {
                console.log('CSc-Error: ' + err);
            });
            csc.on('close', () => {
                console.log('CSc-Error: connection closed');
                cscConnected = false;
                cscEventDeclared = false;
                sentActiveState = false;
            });
            yield csc.connect();
        }
        return cscConnected;
    });
}
function declareCameraEvent() {
    return csc.declareEvent({
        declaration_id: 'Temper1fSensor',
        stateless: false,
        declaration: [
            {
                namespace: 'tnsaxis',
                key: 'topic0',
                value: 'CameraApplicationPlatform',
                value_type: 'STRING',
            },
            {
                namespace: 'tnsaxis',
                key: 'topic1',
                value: 'CamScripter',
                value_type: 'STRING',
            },
            {
                namespace: 'tnsaxis',
                key: 'topic2',
                value: 'Temper1fSensor',
                value_type: 'STRING',
                value_nice_name: 'CamScripter: Temper1fSensor',
            },
            {
                type: 'DATA',
                namespace: '',
                key: 'condition_active',
                value: false,
                value_type: 'BOOL',
                key_nice_name: 'React on active condition (settings in the script)',
                value_nice_name: 'Condition is active',
            },
        ],
    });
}
function sendCameraEvent(active) {
    return csc.sendEvent({
        declaration_id: 'Temper1fSensor',
        event_data: [
            {
                namespace: '',
                key: 'condition_active',
                value: active,
                value_type: 'BOOL',
            },
        ],
    });
}
function pad(num, size) {
    var sign = Math.sign(num) === -1 ? '-' : '';
    return (sign +
        new Array(size)
            .concat([Math.abs(num)])
            .join('0')
            .slice(-size));
}
if (coConfigured || acsConfigured || eventsConfigured) {
    onePeriod();
}
else {
    console.log('Application is not configured.');
    process.exit(1);
}
