"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KeyboardReader = void 0;
const EventEmitter = require("events");
const glob = require("fast-glob");
const util = require("util");
const path = require("path");
const fs = require("fs");
const inputEvent_1 = require("./inputEvent");
const linuxKeyInfo_1 = require("./linuxKeyInfo");
const readFilePr = util.promisify(fs.readFile);
class KeyboardReader extends EventEmitter {
    constructor() {
        super();
        EventEmitter.call(this);
        this.start();
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            const usbDevices = yield this.getUsbDevices();
            for (const usbDevice of usbDevices) {
                for (const device of usbDevice.devices) {
                    if (device.interfaceClass === 3 && device.interfaceProtocol === 1) {
                        this.openInput(path.join('/dev', device.name));
                    }
                }
            }
        });
    }
    getUsbDevices() {
        return __awaiter(this, void 0, void 0, function* () {
            const sysPath = '/sys/bus/usb/devices';
            const usbDeviceDirList = yield glob(`${sysPath}/*`, {
                deep: 1,
                onlyDirectories: true,
                absolute: true,
            });
            const usbDevices = [];
            for (let usbDeviceDir of usbDeviceDirList) {
                try {
                    const vendorId = parseInt(yield this.readInfoFile(path.join(usbDeviceDir, 'idVendor')), 16);
                    const productId = parseInt(yield this.readInfoFile(path.join(usbDeviceDir, 'idProduct')), 16);
                    const manufacturer = yield this.readInfoFile(path.join(usbDeviceDir, 'manufacturer'));
                    const product = yield this.readInfoFile(path.join(usbDeviceDir, 'product'));
                    const busnum = parseInt(yield this.readInfoFile(path.join(usbDeviceDir, 'busnum')));
                    const devnum = parseInt(yield this.readInfoFile(path.join(usbDeviceDir, 'devnum')));
                    if (isNaN(vendorId) || isNaN(productId)) {
                        continue;
                    }
                    const devices = yield this.findDevices(usbDeviceDir);
                    if (devices.length == 0) {
                        continue;
                    }
                    usbDevices.push({
                        vendorId,
                        productId,
                        manufacturer,
                        product,
                        busnum,
                        devnum,
                        devices,
                    });
                }
                catch (err) {
                    console.error('find usb device: ', err);
                }
            }
            return usbDevices;
        });
    }
    findDevices(usbDeviceDir) {
        return __awaiter(this, void 0, void 0, function* () {
            const deviceList = yield glob(`${usbDeviceDir}/**/hidraw[0123456789]`, {
                onlyDirectories: true,
                followSymbolicLinks: false,
                absolute: true,
                unique: true,
            });
            const outputDeviceList = [];
            for (const device of deviceList) {
                const deviceRelativeDir = device.replace(usbDeviceDir, '').split('/');
                const interfacePath = path.join(usbDeviceDir, deviceRelativeDir[1]);
                outputDeviceList.push({
                    name: path.basename(device),
                    interfaceClass: parseInt(yield this.readInfoFile(path.join(interfacePath, 'bInterfaceClass'))),
                    interfaceSubClass: parseInt(yield this.readInfoFile(path.join(interfacePath, 'bInterfaceSubClass'))),
                    interfaceProtocol: parseInt(yield this.readInfoFile(path.join(interfacePath, 'bInterfaceProtocol'))),
                });
            }
            return outputDeviceList;
        });
    }
    readInfoFile(path) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const fileData = yield readFilePr(path);
                return fileData.toString();
            }
            catch (err) {
                return '';
            }
        });
    }
    openInput(devInput) {
        const input = new inputEvent_1.InputEvent(devInput);
        input.on('data', (event) => this.processEvent(event));
        input.on('disconnect', () => setTimeout(() => this.openInput(devInput), 5000));
    }
    processEvent(event) {
        const keyInfo = (0, linuxKeyInfo_1.keyCodeInfo)(event.keycode, event.shift);
        this.emit('key_pressed', keyInfo);
    }
}
exports.KeyboardReader = KeyboardReader;
