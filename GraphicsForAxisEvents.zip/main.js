"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const CameraVapix_1 = require("camstreamerlib/CameraVapix");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
function onEventMessage(event) {
    event.co.setEnabled(true);
    if (event.duration >= 1) {
        if (event.lastTimeout !== null) {
            clearTimeout(event.lastTimeout);
        }
        event.lastTimeout = setTimeout(() => {
            event.co.setEnabled(false);
            event.lastTimeout = null;
        }, event.duration);
    }
}
function getSettings() {
    try {
        const path = "./localdata/";
        const data = fs.readFileSync(path + "settings.json");
        return JSON.parse(data.toString());
    }
    catch (error) {
        console.log("Error with Settings file: ", error);
        process.exit(1);
    }
}
function prepareCamOverlay(settings) {
    return __awaiter(this, void 0, void 0, function* () {
        const cos = {};
        for (let event of settings.events) {
            const options = {
                ip: settings.targetCamera.IP,
                port: settings.targetCamera.port,
                auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
                serviceID: event.serviceID,
            };
            try {
                const co = new CamOverlayAPI_1.CamOverlayAPI(options);
                yield co.connect();
                yield co.setEnabled(false);
                cos[event.serviceID] = co;
            }
            catch (error) {
                console.log(`Cannot connect to CamOverlay service with ID ${event.serviceID} (${error})`);
                process.exit(1);
            }
        }
        return cos;
    });
}
function subscribeEventMessages(settings, cos) {
    return __awaiter(this, void 0, void 0, function* () {
        const options = {
            protocol: "http",
            ip: settings.targetCamera.IP,
            port: settings.targetCamera.port,
            auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
        };
        const cv = new CameraVapix_1.CameraVapix(options);
        cv.on("eventsDisconnect", (error) => {
            if (error == undefined) {
                console.log("Websocket disconnected.");
            }
            else {
                console.log("Websocket error: ", error);
            }
            process.exit(1);
        });
        for (let event of settings.events) {
            const time = event.duration.split(":");
            const hours = Number.parseInt(time[0]);
            const minutes = Number.parseInt(time[1]);
            const seconds = Number.parseInt(time[2]);
            let duration = (3600 * hours + 60 * minutes + seconds) * 1000;
            if (Number.isNaN(duration)) {
                duration = 0;
            }
            cv.on(event.eventName, () => {
                const e = {
                    eventName: event.eventName,
                    duration: duration,
                    co: cos[event.serviceID],
                    lastTimeout: null,
                };
                onEventMessage(e);
            });
        }
        cv.eventsConnect("websocket");
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = getSettings();
        const cos = yield prepareCamOverlay(settings);
        subscribeEventMessages(settings, cos);
    });
}
process.on("unhandledRejection", (reason) => {
    console.log(reason);
    process.exit(1);
});
main();
