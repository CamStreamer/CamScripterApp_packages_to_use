"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const CameraVapix_1 = require("camstreamerlib/CameraVapix");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
const timeouts = {};
const services = {};
function onStatelessEvent(event) {
    services[event.serviceID].setEnabled(true);
    if (event.duration >= 1) {
        if (timeouts[event.serviceID] != null) {
            clearTimeout(timeouts[event.serviceID]);
        }
        timeouts[event.serviceID] = setTimeout(() => {
            services[event.serviceID].setEnabled(false);
            timeouts[event.serviceID] = null;
        }, event.duration);
    }
}
const lastState = {};
function onStatefulEvent(event, state, invert) {
    if (event.duration >= 1) {
        if (state !== lastState[event.eventName]) {
            lastState[event.eventName] = state;
            if (state !== invert) {
                services[event.serviceID].setEnabled(true);
                if (timeouts[event.serviceID] !== null) {
                    clearTimeout(timeouts[event.serviceID]);
                }
                timeouts[event.serviceID] = setTimeout(() => {
                    services[event.serviceID].setEnabled(false);
                    timeouts[event.serviceID] = null;
                }, event.duration);
            }
            else if (timeouts[event.serviceID] != null) {
                services[event.serviceID].setEnabled(false);
                clearTimeout(timeouts[event.serviceID]);
            }
        }
    }
    else {
        services[event.serviceID].setEnabled(state !== invert);
    }
}
function getSettings() {
    try {
        const path = process.env.PERSISTENT_DATA_PATH;
        const data = fs.readFileSync(path + 'settings.json');
        return JSON.parse(data.toString());
    }
    catch (error) {
        console.log('Error with Settings file: ', error);
        process.exit(1);
    }
}
function prepareCamOverlay(settings) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let event of settings.events) {
            const options = {
                ip: settings.targetCamera.IP,
                port: settings.targetCamera.port,
                auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
                serviceID: event.serviceID,
            };
            try {
                const co = new CamOverlayAPI_1.CamOverlayAPI(options);
                yield co.connect();
                yield co.setEnabled(false);
                services[event.serviceID] = co;
            }
            catch (error) {
                console.log(`Cannot connect to CamOverlay service with ID ${event.serviceID} (${error})`);
                process.exit(1);
            }
        }
    });
}
function isStateful(eventData, stateName) {
    return eventData[stateName] !== undefined;
}
function subscribeEventMessages(settings) {
    return __awaiter(this, void 0, void 0, function* () {
        const options = {
            protocol: 'http',
            ip: settings.targetCamera.IP,
            port: settings.targetCamera.port,
            auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
        };
        const cv = new CameraVapix_1.CameraVapix(options);
        cv.on('eventsDisconnect', (error) => {
            if (error == undefined) {
                console.log('Websocket disconnected.');
            }
            else {
                console.log('Websocket error: ', error);
            }
            process.exit(1);
        });
        for (let event of settings.events) {
            const time = event.duration.split(':');
            const hours = Number.parseInt(time[0]);
            const minutes = Number.parseInt(time[1]);
            const seconds = Number.parseInt(time[2]);
            let duration = (3600 * hours + 60 * minutes + seconds) * 1000;
            if (Number.isNaN(duration)) {
                duration = 0;
            }
            cv.on(event.eventName, (data) => {
                const eventData = data.params.notification.message.data;
                const e = {
                    eventName: event.eventName,
                    duration: duration,
                    serviceID: event.serviceID,
                };
                if (isStateful(eventData, event.stateName)) {
                    onStatefulEvent(e, eventData[event.stateName] === '1', event.invert);
                }
                else {
                    onStatelessEvent(e);
                }
            });
        }
        cv.eventsConnect('websocket');
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = getSettings();
        yield prepareCamOverlay(settings);
        subscribeEventMessages(settings);
    });
}
process.on('unhandledRejection', (reason) => {
    console.log(reason);
    process.exit(1);
});
main();
