"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const HttpServer_1 = require("camstreamerlib/HttpServer");
const schema_1 = require("./schema");
const SpinelController_1 = require("./SpinelController");
const Widget_1 = require("./Widget");
let settings;
let widget;
const httpServer = new HttpServer_1.HttpServer();
httpServer.on('access', (msg) => {
    console.log(msg);
});
httpServer.on('error', (err) => {
    console.log(err);
});
httpServer.onRequest('/reset_counter.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('access: reset counter');
        if (!spinelController.isStarted()) {
            yield spinelController.reset();
            res.statusCode = 200;
        }
        else {
            console.error('Cannot reset counter when the counting is running');
            res.statusCode = 400;
        }
    }
    catch (err) {
        console.error('Cannot reset counter, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
httpServer.onRequest('/calibration_start.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('access: calibration start');
        yield spinelController.calibrationStart();
        res.statusCode = 200;
    }
    catch (err) {
        console.error('Cannot start calibration, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
httpServer.onRequest('/calibration_calibrate.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        console.log('access: calibration end');
        const url = new URL((_a = req.url) !== null && _a !== void 0 ? _a : '', 'http://127.0.0.1/');
        if (!url.searchParams.has('volume')) {
            throw new Error('volume not found');
        }
        const volume = parseFloat(url.searchParams.get('volume'));
        if (isNaN(volume)) {
            throw new Error('invalid volume specified');
        }
        yield spinelController.calibrationCalibrate(volume);
        res.statusCode = 200;
    }
    catch (err) {
        console.error('Cannot finish calibration, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
const spinelController = new SpinelController_1.SpinelController();
spinelController.on('volume', (volume) => __awaiter(void 0, void 0, void 0, function* () {
    if (widget) {
        yield widget.updateVolume(volume);
    }
}));
function readConfiguration() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return schema_1.settingsSchema.parse(JSON.parse(data.toString()));
    }
    catch (err) {
        console.log('Application is not configured or configuration error:', err);
        process.exit(1);
    }
}
function start() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log('Starting application...');
            settings = readConfiguration();
            if (widget) {
                widget.stop();
                widget = undefined;
            }
            widget = new Widget_1.Widget(settings);
            if (settings.started) {
                yield spinelController.start();
            }
            console.log('Application started');
        }
        catch (err) {
            console.log('Application start:', err);
        }
    });
}
function stop() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield spinelController.stop();
        }
        catch (err) {
            console.log('Application stop:', err);
        }
    });
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
    process.exit(1);
});
process.on('unhandledRejection', (err) => {
    console.error('Unhandled rejection:', err);
    process.exit(1);
});
process.on('SIGINT', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('SIGINT signal received');
    yield stop();
    yield start();
}));
process.on('SIGTERM', () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('SIGTERM signal received');
    httpServer.close();
    yield stop();
    process.exit(0);
}));
void start();
