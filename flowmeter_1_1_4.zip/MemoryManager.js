"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemoryManager = void 0;
const fs = require("fs");
class MemoryManager {
    constructor(co) {
        this.co = co;
        this.imgFiles = {};
        this.fontFiles = {};
        this.images = {};
        this.fonts = {};
    }
    image(moniker) {
        return __awaiter(this, void 0, void 0, function* () {
            if (moniker in this.images) {
                return this.images[moniker];
            }
            else if (moniker in this.imgFiles) {
                const imgData = fs.readFileSync(this.imgFiles[moniker]);
                this.images[moniker] = yield this.co.uploadImageData(imgData);
                return this.images[moniker];
            }
            else {
                throw new Error('Error! Unknown image requested!');
            }
        });
    }
    font(moniker) {
        return __awaiter(this, void 0, void 0, function* () {
            if (moniker in this.fonts) {
                return this.fonts[moniker];
            }
            else if (moniker in this.fontFiles) {
                this.fonts[moniker] = yield this.loadTTF(this.co, this.fontFiles[moniker]);
                return this.fonts[moniker];
            }
            else {
                throw new Error('Error! Unknown font requested!');
            }
        });
    }
    registerImage(moniker, fileName) {
        this.imgFiles[moniker] = process.env.INSTALL_PATH + '/images/' + fileName;
    }
    registerFont(moniker, fileName) {
        this.fontFiles[moniker] = process.env.INSTALL_PATH + '/fonts/' + fileName;
    }
    loadTTF(co, fileName) {
        return new Promise((resolve, reject) => {
            const imgData = fs.readFileSync(fileName);
            co.uploadFontData(imgData).then((fontRes) => {
                resolve(fontRes.var);
            }, reject);
        });
    }
}
exports.MemoryManager = MemoryManager;
