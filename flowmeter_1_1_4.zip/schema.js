"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = void 0;
const zod_1 = require("zod");
exports.settingsSchema = zod_1.z.object({
    started: zod_1.z.boolean(),
    camera_protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    camera_ip: zod_1.z.string(),
    camera_port: zod_1.z.number(),
    camera_user: zod_1.z.string(),
    camera_pass: zod_1.z.string(),
    coord: zod_1.z.string(),
    pos_x: zod_1.z.number(),
    pos_y: zod_1.z.number(),
    resolution: zod_1.z.string(),
    camera_list: zod_1.z.array(zod_1.z.number()),
    group_name: zod_1.z.string(),
    start_time: zod_1.z.string(),
    scale: zod_1.z.number(),
    glass_size: zod_1.z.number(),
    overlay_type: zod_1.z.union([zod_1.z.literal('axis_beer'), zod_1.z.literal('beer'), zod_1.z.literal('birel')]),
});
