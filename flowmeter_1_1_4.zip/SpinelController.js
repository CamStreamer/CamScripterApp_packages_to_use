"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpinelController = exports.stateSchema = exports.calibrationSchema = void 0;
const fs = require("fs/promises");
const zod_1 = require("zod");
const SpinelDevice_1 = require("./SpinelDevice");
const events_1 = require("events");
exports.calibrationSchema = zod_1.z.object({
    k_factor: zod_1.z.number().positive(),
});
exports.stateSchema = zod_1.z.object({
    aggregated_volume: zod_1.z.number().nonnegative(),
});
class SpinelController extends events_1.EventEmitter {
    constructor() {
        super();
        this.VENDOR_ID = 0x0403;
        this.PRODUCT_ID = 0x6001;
        this.calibration = { k_factor: 5509 };
        this.state = { aggregated_volume: 0 };
        this.started = false;
        void this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            this.calibration = yield this.readCalibration();
            this.state = yield this.readState();
            this.reportVolume();
        });
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.stop();
                this.started = true;
                yield this.init();
                this.spinel = new SpinelDevice_1.SpinelDevice(this.VENDOR_ID, this.PRODUCT_ID);
                yield this.spinel.connect();
                yield this.spinel.send97Request(0xfe, Buffer.from('6081', 'hex'));
                this.intervalTimer = setInterval(() => __awaiter(this, void 0, void 0, function* () {
                    yield this.getData();
                }), 1000);
            }
            catch (err) {
                console.error(err);
                yield this.stop();
                this.restartTimer = setTimeout(() => this.start(), 5000);
            }
        });
    }
    stop() {
        return __awaiter(this, void 0, void 0, function* () {
            this.started = false;
            clearTimeout(this.restartTimer);
            clearInterval(this.intervalTimer);
            if (this.spinel) {
                yield this.spinel.close();
            }
        });
    }
    isStarted() {
        return this.started;
    }
    reset() {
        return __awaiter(this, void 0, void 0, function* () {
            this.state.aggregated_volume = 0;
            yield this.updateState(this.state);
            this.emit('volume', this.state.aggregated_volume);
        });
    }
    calibrationStart() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.spinel) {
                yield this.spinel.close();
            }
            this.spinel = new SpinelDevice_1.SpinelDevice(this.VENDOR_ID, this.PRODUCT_ID);
            yield this.spinel.connect();
            yield this.spinel.send97Request(0xfe, Buffer.from('6081', 'hex'));
        });
    }
    calibrationCalibrate(calibrationVolume) {
        return __awaiter(this, void 0, void 0, function* () {
            if (calibrationVolume <= 0) {
                throw new Error('Calibration volume has to be greater than zero');
            }
            if (!this.spinel) {
                throw new Error('Spinel connection not found');
            }
            const data = yield this.spinel.send97Request(0xfe, Buffer.from('6081', 'hex'));
            const volumeDelta = this.parseCounterData(data.data);
            if (volumeDelta === 0) {
                throw new Error('Some liquid has to be poured through flow meter for calibration');
            }
            this.calibration.k_factor = volumeDelta / calibrationVolume;
            yield this.updateCalibration(this.calibration);
            yield this.spinel.close();
        });
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.spinel) {
                    const data = yield this.spinel.send97Request(0xfe, Buffer.from('6081', 'hex'));
                    const volumeDelta = this.parseCounterData(data.data);
                    this.state.aggregated_volume += volumeDelta / this.calibration.k_factor;
                    yield this.updateState(this.state);
                    this.reportVolume();
                }
            }
            catch (err) {
                console.error(err);
                yield this.stop();
                this.restartTimer = setTimeout(() => this.start(), 5000);
            }
        });
    }
    parseCounterData(data) {
        let result = 0;
        const bytesCount = data[0] / 8;
        for (let i = 1; i < data.length; i += bytesCount) {
            let res = 0;
            for (let j = 0; j < bytesCount; j++) {
                res = res << 8;
                res += data[i + j];
            }
            result += res;
        }
        return result;
    }
    readCalibration() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const fileData = yield fs.readFile(process.env.PERSISTENT_DATA_PATH + 'calibration.json');
                return exports.calibrationSchema.parse(JSON.parse(fileData.toString()));
            }
            catch (err) {
                console.error('Calibration lost, error: ', err);
                return { k_factor: 5509 };
            }
        });
    }
    updateCalibration(state) {
        return __awaiter(this, void 0, void 0, function* () {
            yield fs.writeFile(process.env.PERSISTENT_DATA_PATH + 'calibration.json', JSON.stringify(state));
        });
    }
    readState() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const fileData = yield fs.readFile(process.env.PERSISTENT_DATA_PATH + 'state.json');
                return exports.stateSchema.parse(JSON.parse(fileData.toString()));
            }
            catch (err) {
                console.error('Counter state lost, error: ', err);
                return { aggregated_volume: 0 };
            }
        });
    }
    updateState(state) {
        return __awaiter(this, void 0, void 0, function* () {
            yield fs.writeFile(process.env.PERSISTENT_DATA_PATH + 'state_tmp.json', JSON.stringify(state));
            yield fs.rename(process.env.PERSISTENT_DATA_PATH + 'state_tmp.json', process.env.PERSISTENT_DATA_PATH + 'state.json');
        });
    }
    reportVolume() {
        this.emit('volume', this.state.aggregated_volume);
        clearTimeout(this.reportVolumeTimer);
        this.reportVolumeTimer = setTimeout(() => this.reportVolume(), 5000);
    }
}
exports.SpinelController = SpinelController;
