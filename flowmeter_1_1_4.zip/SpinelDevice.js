"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpinelDevice = void 0;
const serialport_1 = require("serialport");
const parser_delimiter_1 = require("@serialport/parser-delimiter");
class SpinelDevice {
    constructor(vendorID, productID) {
        this.buffer = Buffer.alloc(0);
        this.requests = {};
        this.vendorIdStr = SpinelDevice.deviceIdToString(vendorID);
        this.productIdStr = SpinelDevice.deviceIdToString(productID);
    }
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            const list = yield serialport_1.SerialPort.list();
            console.log('device list:', JSON.stringify(list));
            let ourPort;
            for (const port of list) {
                if (port['vendorId'] === this.vendorIdStr && port['productId'] === this.productIdStr) {
                    ourPort = port;
                }
            }
            if (!ourPort) {
                throw new Error('404 no device found!');
            }
            this.serialPort = new serialport_1.SerialPort({
                path: ourPort.path,
                baudRate: 115200,
            });
            const delimiterParser = this.serialPort.pipe(new parser_delimiter_1.DelimiterParser({
                delimiter: '\r',
                includeDelimiter: true,
            }));
            delimiterParser.on('data', (rawData) => {
                this.buffer = Buffer.concat([this.buffer, Buffer.from(rawData)]);
                this.parseDataBuffer();
            });
        });
    }
    parseDataBuffer() {
        if (this.buffer.length < 4) {
            return;
        }
        if (this.buffer[0] === 0x2a) {
            switch (this.buffer[1]) {
                case 0x61: {
                    const byteCount = (this.buffer[2] << 8) + this.buffer[3] + 4;
                    if (byteCount <= this.buffer.length) {
                        const checksum = this.buffer[byteCount - 2];
                        const dataload = this.buffer.subarray(0, byteCount - 2);
                        this.buffer = this.buffer.subarray(byteCount);
                        if (this.checksum(dataload) === checksum) {
                            this.accept97Request(dataload);
                        }
                        else {
                            throw new Error('Spinell Parse Error - Bad Checksum. ' +
                                `Recived: ${checksum} Expected: ${this.checksum(dataload)}`);
                        }
                    }
                    break;
                }
                default:
                    throw new Error('Spinell Parse Error - Unknown Format');
            }
        }
        else {
            throw new Error('Spinel Parse Error - Unknown Protocol');
        }
    }
    send97Request(addr, sdataBuff, timeout = 5000) {
        const sign = Math.floor(Math.random() * 256);
        return new Promise((resolve, reject) => {
            this.send97Data(addr, sign, sdataBuff);
            this.requests[sign] = resolve;
            setTimeout(() => reject(new Error('Request timeout')), timeout);
        });
    }
    send97Data(addr, sign, sdataBuff) {
        const instruction = this.assemble97Instruction(addr, sign, sdataBuff);
        this.sendData(instruction);
    }
    assemble97Instruction(addr, sign, sdataBuff) {
        const bCount = sdataBuff.length + 4;
        const pre = Buffer.from([0x2a, 0x61, (bCount & 0xff00) >> 8, bCount & 0xff, addr, sign]);
        const load = Buffer.concat([pre, sdataBuff]);
        const suffix = Buffer.from([this.checksum(load), 0x0d]);
        return Buffer.concat([load, suffix]);
    }
    accept97Request(dataload) {
        const outJson = {
            format: dataload[1],
            byteCount: (dataload[2] << 8) + dataload[3],
            data: dataload.subarray(7),
            address: dataload[4],
            sign: dataload[5],
            ack: dataload[6],
        };
        if (outJson.sign in this.requests) {
            this.requests[outJson.sign](outJson);
        }
    }
    sendData(buffer) {
        if (this.serialPort) {
            this.serialPort.write(buffer, (err) => {
                if (err) {
                    throw new Error(`Error on spinel write: ${err.message}`);
                }
            });
        }
    }
    checksum(buff) {
        const base = 255;
        let sum = 0x00;
        for (let i = 0; i < buff.length; i++) {
            sum = (sum + buff[i]) & 0xff;
        }
        return (base - sum) & 0xff;
    }
    close() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.serialPort) {
                    this.serialPort.unpipe();
                    this.serialPort.removeAllListeners();
                    this.serialPort.destroy();
                    if ((_a = this.serialPort) === null || _a === void 0 ? void 0 : _a.isOpen) {
                        yield this.serialPort.close();
                    }
                }
                console.log('serial port closed');
            }
            catch (err) {
                console.log('serial port close error:', err);
            }
        });
    }
    static deviceIdToString(deviceId) {
        let deviceIdStr = deviceId.toString(16);
        if (deviceIdStr.length < 4) {
            for (let i = 0; i < 4 - deviceIdStr.length; i++) {
                deviceIdStr = '0' + deviceIdStr;
            }
        }
        return deviceIdStr;
    }
}
exports.SpinelDevice = SpinelDevice;
