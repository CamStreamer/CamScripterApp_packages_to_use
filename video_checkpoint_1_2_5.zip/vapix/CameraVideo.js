"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CameraVideo = void 0;
const jsdom_1 = require("jsdom");
const CameraVapix_1 = require("camstreamerlib/CameraVapix");
class CameraVideo {
    constructor(cameraSettings) {
        this.cameraVapix = this.setCameraVapix(cameraSettings);
    }
    setCameraVapix(cameraSettings) {
        const options = {
            tls: cameraSettings.protocol !== 'http',
            tlsInsecure: cameraSettings.protocol === 'https_insecure',
            ip: cameraSettings.ip,
            port: cameraSettings.port,
            user: cameraSettings.user,
            pass: cameraSettings.pass,
        };
        return new CameraVapix_1.CameraVapix(options);
    }
    getIDs(source) {
        return __awaiter(this, void 0, void 0, function* () {
            const path = '/axis-cgi/record/list.cgi';
            const response = yield yield this.cameraVapix.vapixGet(path, { recordingid: 'all' });
            if (!response.ok) {
                throw new Error(`The response from camera was not OK. Status code: ${response.status}. Download cancelled.`);
            }
            const xml = yield response.text();
            const dom = new jsdom_1.JSDOM(xml, { contentType: 'text/xml' });
            const recordingNode = dom.window.document.querySelector('recording[recordingstatus="recording"][source="' + source + '"]');
            if (!recordingNode) {
                throw new Error('Warning: Source ' + source + ' has not been found. Make sure it is currently recording.');
            }
            const diskID = recordingNode.getAttribute('diskid');
            const recordingID = recordingNode.getAttribute('recordingid');
            if (diskID === null || diskID === '' || recordingID === null || recordingID === '') {
                throw new Error('Invalid body from ' + path);
            }
            return [diskID, recordingID];
        });
    }
    getSchemaVersion() {
        return __awaiter(this, void 0, void 0, function* () {
            const path = '/axis-cgi/record/storage/schemaversions.cgi';
            const xml = yield (yield this.cameraVapix.vapixGet(path)).text();
            const dom = new jsdom_1.JSDOM(xml, { contentType: 'text/xml' });
            const versionNumberNode = dom.window.document.querySelector('VersionNumber');
            if (!versionNumberNode) {
                throw new Error('VersionNumber element not found at ' + path);
            }
            const versionNumber = versionNumberNode.textContent;
            if (versionNumber === null || versionNumber === '') {
                throw new Error('VersionNumber is empty');
            }
            return versionNumber;
        });
    }
    downloadRecording(startTime, endTime, source) {
        return __awaiter(this, void 0, void 0, function* () {
            const ids = yield this.getIDs(source + 1);
            if (ids.length === 0) {
                return undefined;
            }
            const [diskID, recordingID] = ids;
            const schemaVersion = yield this.getSchemaVersion();
            const path = '/axis-cgi/record/export/exportrecording.cgi';
            const parameters = {
                schemaversion: schemaVersion,
                diskid: diskID,
                recordingid: recordingID,
                exportformat: 'matroska',
                starttime: this.formatDate(startTime),
                endtime: this.formatDate(endTime),
            };
            const video = yield this.cameraVapix.vapixGet(path, parameters);
            if (!video.ok) {
                throw new Error('The response was not OK. Status code: ' + video.status);
            }
            const clonedVideo = video.clone();
            return clonedVideo.body;
        });
    }
    formatDate(startTime) {
        const result = new Date(startTime).toISOString();
        return result.substring(0, result.length - 1) + '0Z';
    }
}
exports.CameraVideo = CameraVideo;
