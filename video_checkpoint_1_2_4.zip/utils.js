"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateUrl = exports.convertWebStreamToNodeReadable = exports.createFileName = exports.stripCode = exports.getDate = exports.pad = void 0;
const Stream = require("stream");
function pad(num, size) {
    const sign = Math.sign(num) === -1 ? '-' : '';
    return (sign +
        new Array(size)
            .concat([Math.abs(num)])
            .join('0')
            .slice(-size));
}
exports.pad = pad;
function getDate() {
    const d = new Date();
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1, 2)}-${pad(d.getDate(), 2)}`;
    const dateTime = `${date}_${pad(d.getHours(), 2)}-${pad(d.getMinutes(), 2)}-${pad(d.getSeconds(), 2)}`;
    return { date, dateTime };
}
exports.getDate = getDate;
function stripCode(code) {
    return code.replace(/[^\w\s]/gi, '');
}
exports.stripCode = stripCode;
function createFileName(code, date, serialNumber, camera) {
    if (camera !== undefined) {
        const channelNumber = camera + 1;
        return (date.getFullYear() +
            '-' +
            pad(date.getMonth() + 1, 2) +
            '-' +
            pad(date.getDate(), 2) +
            '_' +
            pad(date.getHours(), 2) +
            '-' +
            pad(date.getMinutes(), 2) +
            '-' +
            pad(date.getSeconds(), 2) +
            '_' +
            code +
            '_' +
            serialNumber +
            '_camera' +
            channelNumber);
    }
    else {
        return (date.getFullYear() +
            '-' +
            pad(date.getMonth() + 1, 2) +
            '-' +
            pad(date.getDate(), 2) +
            '_' +
            pad(date.getHours(), 2) +
            '-' +
            pad(date.getMinutes(), 2) +
            '-' +
            pad(date.getSeconds(), 2) +
            '_' +
            code +
            '_' +
            serialNumber);
    }
}
exports.createFileName = createFileName;
function convertWebStreamToNodeReadable(webStream) {
    return __awaiter(this, void 0, void 0, function* () {
        const nodeReadable = new Stream.Readable({
            read() { },
        });
        const reader = webStream.getReader();
        function pushChunks() {
            return __awaiter(this, void 0, void 0, function* () {
                try {
                    const { done, value } = yield reader.read();
                    if (done) {
                        nodeReadable.push(null);
                        return;
                    }
                    nodeReadable.push(value);
                    yield pushChunks();
                }
                catch (err) {
                    nodeReadable.emit('error', err);
                }
            });
        }
        yield pushChunks();
        return Promise.resolve(nodeReadable);
    });
}
exports.convertWebStreamToNodeReadable = convertWebStreamToNodeReadable;
function generateUrl(proxy) {
    return `${proxy.protocol}://${proxy.ip}:${proxy.port}/${proxy.base_uri}`;
}
exports.generateUrl = generateUrl;
