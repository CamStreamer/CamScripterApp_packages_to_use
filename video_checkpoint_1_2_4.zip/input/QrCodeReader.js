"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QRCodeReader = void 0;
const EventEmitter = require("events");
const KeyboardReader_1 = require("./KeyboardReader");
class QRCodeReader extends EventEmitter {
    constructor(validationRule) {
        super();
        this.validationRule = validationRule;
        this.code = '';
        EventEmitter.call(this);
        this.keyboardReader = new KeyboardReader_1.KeyboardReader();
        this.keyboardReader.on('key_pressed', (keyInfo) => this.keyPressedCallback(keyInfo));
    }
    keyPressedCallback(keyInfo) {
        if (keyInfo.name !== 'ENTER') {
            this.code += keyInfo.char;
            return;
        }
        if (this.validate()) {
            this.emit('valid_reading', { code: this.code });
        }
        else {
            this.emit('invalid_reading', { code: this.code });
        }
        this.code = '';
    }
    validate() {
        if (this.code.length === 0) {
            return false;
        }
        if (this.validationRule.length !== 0 && this.code.match(this.validationRule) === null) {
            return false;
        }
        return true;
    }
}
exports.QRCodeReader = QRCodeReader;
