"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Genetec = void 0;
const utils_1 = require("../utils");
const ACTION = 'AddCameraBookmark';
const GET_CAMERAS_URL = 'report/EntityConfiguration?q=EntityTypes@Camera';
const GET_CAMERAS_DETAILS_URL = '/entity?q=';
const PARAMS = 'Guid,Name,EntityType';
class Genetec {
    constructor(genetecSettings) {
        this.genetecSettings = genetecSettings;
        this.baseUrl = (0, utils_1.generateUrl)(genetecSettings);
        this.credentials = btoa(`${genetecSettings.user};${genetecSettings.app_id}:${genetecSettings.pass}`);
    }
    checkConnection(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = req.url.split('?')[1];
            const params = new URLSearchParams(queryString);
            const currentSettings = {
                protocol: params.get('protocol'),
                ip: params.get('ip'),
                port: params.get('port'),
                base_uri: params.get('base_uri'),
                credentials: params.get('credentials'),
            };
            const baseUrl = (0, utils_1.generateUrl)(currentSettings);
            const credentials = `${currentSettings.credentials}`;
            try {
                const isConnected = yield this.checkConnectionToGenetec(baseUrl, credentials).then((res) => res.Rsp.Status);
                console.log('Connection to Genetec successful');
                res.statusCode = 200;
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.end(isConnected === 'Ok'
                    ? '{"message": "Genetec connection success"}'
                    : '{"message": "Genetec connection unsuccessful"}');
            }
            catch (err) {
                console.error('Cannot connect to Genetec, error:', err);
                res.statusCode = 500;
                res.end('{"message": "Genetec connection error"}');
            }
        });
    }
    sendTestBookmark(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = req.url.split('?')[1];
            const params = new URLSearchParams(queryString);
            const currentSettings = {
                protocol: params.get('protocol'),
                ip: params.get('ip'),
                port: params.get('port'),
                base_uri: params.get('base_uri'),
                credentials: params.get('credentials'),
                camera_list: params.get('camera_list'),
                selected_cameras: params.get('selected_cameras'),
            };
            const baseUrl = (0, utils_1.generateUrl)(currentSettings);
            const credentials = `${currentSettings.credentials}`;
            try {
                if (currentSettings.camera_list !== null && currentSettings.selected_cameras !== null) {
                    yield this.sendBookmark('Testing bookmark from CamStreamer script', baseUrl, credentials, JSON.parse(currentSettings.camera_list), JSON.parse(currentSettings.selected_cameras));
                    res.statusCode = 200;
                    res.setHeader('Access-Control-Allow-Origin', '*');
                    res.end('{"message": "Test bookmark sent"}');
                }
            }
            catch (err) {
                console.error('Cannot send test bookmark, error:', err);
                res.statusCode = 500;
                res.end('{"message": "Cannot send test bookmark"}');
            }
        });
    }
    getCameraOptions(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryString = req.url.split('?')[1];
            const params = new URLSearchParams(queryString);
            const currentSettings = {
                protocol: params.get('protocol'),
                ip: params.get('ip'),
                port: params.get('port'),
                base_uri: params.get('base_uri'),
                credentials: params.get('credentials'),
            };
            const baseUrl = (0, utils_1.generateUrl)(currentSettings);
            const credentials = `${currentSettings.credentials}`;
            try {
                const cameraList = yield this.getCameraList(baseUrl, credentials);
                res.statusCode = 200;
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.end(JSON.stringify(cameraList));
            }
            catch (err) {
                res.statusCode = 500;
                res.end('[]');
            }
        });
    }
    sendBookmark(code, baseUrl, credentials, currentCameraList, currentSelectedCameras) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('Sending bookmark... ', code);
            try {
                if (baseUrl === undefined) {
                    baseUrl = this.baseUrl;
                }
                if (credentials === undefined) {
                    credentials = this.credentials;
                }
                if (currentCameraList === undefined) {
                    currentCameraList = yield this.getCameraList(baseUrl, credentials);
                }
                if (currentSelectedCameras === undefined) {
                    currentSelectedCameras = this.genetecSettings.camera_list;
                }
                const date = new Date();
                const year = date.getUTCFullYear();
                const month = (0, utils_1.pad)(date.getUTCMonth() + 1, 2);
                const day = (0, utils_1.pad)(date.getUTCDate(), 2);
                const hours = (0, utils_1.pad)(date.getUTCHours(), 2);
                const minutes = (0, utils_1.pad)(date.getUTCMinutes(), 2);
                const seconds = (0, utils_1.pad)(date.getUTCSeconds(), 2);
                const miliSeconds = (0, utils_1.pad)(date.getUTCMilliseconds(), 2);
                const timeStamp = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}.${miliSeconds}Z`;
                const bookmarkText = code;
                const selectedCamerasToSend = currentCameraList.filter((camera) => currentSelectedCameras === null || currentSelectedCameras === void 0 ? void 0 : currentSelectedCameras.includes(camera.index));
                const cameraEntitiesUrl = [];
                for (const camera of selectedCamerasToSend) {
                    cameraEntitiesUrl.push(`${ACTION}(${camera.value},${timeStamp},${bookmarkText})`);
                }
                const requestOptions = this.requestOptionsCreator('POST', credentials !== undefined ? credentials : this.credentials);
                yield fetch(`${baseUrl !== undefined ? baseUrl : this.baseUrl}/action?q=${cameraEntitiesUrl.join(',')}`, requestOptions);
                console.log('Bookmark sent: ', code);
            }
            catch (err) {
                console.error('Cannot send bookmark, error: ', err);
            }
        });
    }
    getCameraList(baseUrl, credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            const guidsArray = yield this.getAllCamerasGuids(baseUrl, credentials).then((res) => res.Rsp.Result);
            const camerasGuids = guidsArray.map((guid) => guid.Guid);
            const camerasDetailsUrl = [];
            for (const guid of camerasGuids) {
                camerasDetailsUrl.push(`entity=${guid},${PARAMS}`);
            }
            const requestOptions = this.requestOptionsCreator('GET', credentials);
            const camerasDetails = yield fetch(`${baseUrl}/${GET_CAMERAS_DETAILS_URL}${camerasDetailsUrl.join(',')}`, requestOptions)
                .then((res) => res.json())
                .then((response) => response.Rsp.Result);
            const cameraList = [];
            if (!Array.isArray(camerasDetails)) {
                cameraList.push({
                    index: 0,
                    value: camerasDetails.Guid,
                    label: camerasDetails.Name,
                });
            }
            else {
                for (let i = 0; i < camerasDetails.length; i++) {
                    const camera = camerasDetails[i];
                    cameraList.push({
                        index: i,
                        value: camera.Guid,
                        label: camera.Name,
                    });
                }
            }
            return cameraList;
        });
    }
    getAllCamerasGuids(baseUrl, credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            const requestOptions = this.requestOptionsCreator('GET', credentials);
            return yield fetch(`${baseUrl}/${GET_CAMERAS_URL}`, requestOptions).then((res) => res.json());
        });
    }
    checkConnectionToGenetec(baseUrl, credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            const requestOptions = this.requestOptionsCreator('GET', credentials);
            return fetch(`${baseUrl}/`, requestOptions).then((res) => res.json());
        });
    }
    requestOptionsCreator(method, credentials) {
        return {
            method: method,
            headers: new Headers({
                Authorization: `Basic ${credentials}`,
                Accept: 'text/json',
            }),
            redirect: 'follow',
        };
    }
}
exports.Genetec = Genetec;
