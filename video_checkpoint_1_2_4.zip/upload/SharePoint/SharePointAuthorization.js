"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharePointAuthorization = void 0;
const urlLib = require("url");
const node_fetch_1 = require("node-fetch");
const TOKEN_SAFE_EXPIRE_ZONE_S = 5;
let tokenCache = {
    key: '',
    token: '',
    expiresS: 0,
};
const SharePointServicePrincipal = '00000003-0000-0ff1-ce00-000000000000';
class SharePointAuthorization {
    constructor(auth) {
        this.auth = auth;
        this.getAuthToken = () => __awaiter(this, void 0, void 0, function* () {
            const sharepointhostname = urlLib.parse(this.auth.url).hostname;
            const cacheKey = `${sharepointhostname}@${this.auth.client_secret}@${this.auth.client_id}`;
            if (tokenCache.key === cacheKey && Date.now() / 1000 < tokenCache.expiresS) {
                return tokenCache.token;
            }
            const authUrl = yield this.getAuthUrl();
            const resource = `${SharePointServicePrincipal}/${sharepointhostname}@${this.auth.tenant_id}`;
            const fullClientId = `${this.auth.client_id}@${this.auth.tenant_id}`;
            const data = paramToUrlEncoded({
                grant_type: 'client_credentials',
                client_id: fullClientId,
                client_secret: this.auth.client_secret,
                resource: resource,
            });
            const { token, expiresS } = yield this.fetchToken(authUrl, data);
            tokenCache = {
                key: cacheKey,
                token,
                expiresS,
            };
            return token;
        });
        this.fetchToken = (authUrl, body) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            const res = yield (0, node_fetch_1.default)(authUrl, {
                method: 'POST',
                body,
                headers: {
                    'content-type': 'application/x-www-form-urlencoded',
                },
            });
            const data = (yield res.json());
            const rawToken = data === null || data === void 0 ? void 0 : data.access_token;
            const tokenType = data === null || data === void 0 ? void 0 : data.token_type;
            const tokenExpire = Date.now() / 1000 + Number((_a = data === null || data === void 0 ? void 0 : data.expires_in) !== null && _a !== void 0 ? _a : 0);
            if (rawToken === undefined || tokenType === undefined) {
                throw new Error('Authorization error. Check your share point credentials.');
            }
            return {
                token: `${tokenType} ${data.access_token}`,
                expiresS: tokenExpire - TOKEN_SAFE_EXPIRE_ZONE_S,
            };
        });
        this.getAuthUrl = () => __awaiter(this, void 0, void 0, function* () {
            const ascUrl = this.createAscUrl();
            const res = yield (0, node_fetch_1.default)(ascUrl);
            const data = (yield res.json());
            for (let i = 0; i < data.endpoints.length; i++) {
                if (data.endpoints[i].protocol === 'OAuth2') {
                    return data.endpoints[i].location;
                }
            }
            throw new Error('No OAuth2 in while asking for authUrl');
        });
        this.createAscUrl = () => {
            const endpoints = {
                Production: 'accounts.accesscontrol.windows.net',
                China: 'accounts.accesscontrol.chinacloudapi.cn',
                German: 'login.microsoftonline.de',
                USDefence: 'accounts.accesscontrol.windows.net',
                USGovernment: 'accounts.accesscontrol.windows.net',
            };
            let endpoint = endpoints.Production;
            const host = urlLib.parse(this.auth.url).host;
            if (host === null || host === void 0 ? void 0 : host.endsWith('.sharepoint.cn')) {
                endpoint = endpoints.China;
            }
            else if (host === null || host === void 0 ? void 0 : host.endsWith('.sharepoint.de')) {
                endpoint = endpoints.German;
            }
            else if (host === null || host === void 0 ? void 0 : host.endsWith('.sharepoint-mil.us')) {
                endpoint = endpoints.USDefence;
            }
            else if (host === null || host === void 0 ? void 0 : host.endsWith('.sharepoint.us')) {
                endpoint = endpoints.USGovernment;
            }
            return `https://${endpoint}/metadata/json/1?realm=${this.auth.tenant_id}`;
        };
    }
}
exports.SharePointAuthorization = SharePointAuthorization;
const paramToUrlEncoded = (params) => {
    let output = '';
    if (params) {
        const reducer = (res, key) => {
            if (params[key] !== undefined) {
                return `${res}${key}=${encodeURIComponent(String(params[key]))}&`;
            }
            return res;
        };
        output = Object.keys(params).reduce(reducer, '');
        output = output.slice(0, output.length - 1);
    }
    return output;
};
