"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const util = require("util");
const https = require("https");
const url_1 = require("url");
const HttpRequest_1 = require("camstreamerlib/HttpRequest");
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
const CairoFrame_1 = require("./CairoFrame");
const CairoPainter_1 = require("./CairoPainter");
const setTimeoutPromise = util.promisify(setTimeout);
let settings;
let co = null;
let coConnected = false;
let mapCO = null;
let mapCOconnected = false;
let images;
let regular;
let bold;
let mapCP;
let cp;
let frames;
function allSettled(promises) {
    return new Promise((resolve) => {
        let numberOfFulfilledPromise = 0;
        for (const promise of promises) {
            promise.then(() => {
                numberOfFulfilledPromise += 1;
                if (numberOfFulfilledPromise === promises.length) {
                    resolve();
                }
            }, (error) => {
                console.error(error);
                numberOfFulfilledPromise += 1;
                if (numberOfFulfilledPromise === promises.length) {
                    resolve();
                }
            });
        }
    });
}
function readSettings() {
    try {
        const data = fs.readFileSync(path.join(process.env.PERSISTENT_DATA_PATH, 'settings.json'));
        return JSON.parse(data.toString());
    }
    catch (error) {
        console.error('Cannot read Settings file: ', error.message);
        process.exit(1);
    }
}
function isSetup() {
    return settings.modem.device !== null && settings.modem.token !== '' && (co !== null || mapCO !== null);
}
function coSetup() {
    const coCamera = settings.co_camera;
    const options = {
        ip: coCamera.ip,
        port: coCamera.port,
        auth: `${coCamera.user}:${coCamera.password}`,
        tls: coCamera.protocol !== 'http',
        tlsInsecure: coCamera.protocol === 'https_insecure',
    };
    co = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI(options);
    prepareCairoPainter();
}
function coConfigured() {
    const coCamera = settings.co_camera;
    return (coCamera.protocol !== '' &&
        coCamera.port !== null &&
        coCamera.ip !== '' &&
        coCamera.user !== '' &&
        coCamera.password !== '');
}
function prepareCairoPainter() {
    const overlay = settings.overlay;
    cp = new CairoPainter_1.default({
        x: overlay.x,
        y: overlay.y,
        screen_width: overlay.width,
        screen_height: overlay.height,
        co_ord: overlay.alignment,
        width: 902,
        height: 930,
    });
    frames = {};
    frames.wanState = new CairoFrame_1.default({
        x: 55,
        y: 62,
        width: 62,
        height: 59,
    });
    frames.routerName = new CairoFrame_1.default({
        x: 148,
        y: 64,
        width: 301,
        height: 35,
    });
    frames.routerIP = new CairoFrame_1.default({
        x: 632,
        y: 64,
        width: 221,
        height: 35,
    });
    frames.simInserted1 = new CairoFrame_1.default({
        x: 55,
        y: 158,
        width: 109,
        height: 146,
    });
    frames.operator1 = new CairoFrame_1.default({
        x: 189,
        y: 204,
        width: 281,
        height: 28,
    });
    frames.connectionType1 = new CairoFrame_1.default({
        x: 189,
        y: 244,
        width: 70,
        height: 37,
    });
    frames.signalStrenght1 = new CairoFrame_1.default({
        x: 265,
        y: 243,
        width: 51,
        height: 41,
    });
    frames.simInserted2 = new CairoFrame_1.default({
        x: 478,
        y: 158,
        width: 109,
        height: 146,
    });
    frames.operator2 = new CairoFrame_1.default({
        x: 620,
        y: 204,
        width: 281,
        height: 28,
    });
    frames.connectionType2 = new CairoFrame_1.default({
        x: 620,
        y: 244,
        width: 70,
        height: 37,
    });
    frames.signalStrenght2 = new CairoFrame_1.default({
        x: 695,
        y: 243,
        width: 51,
        height: 41,
    });
    frames.port1 = new CairoFrame_1.default({
        x: 55,
        y: 356,
        width: 94,
        height: 70,
    });
    frames.port2 = new CairoFrame_1.default({
        x: 200,
        y: 356,
        width: 94,
        height: 70,
    });
    frames.port3 = new CairoFrame_1.default({
        x: 345,
        y: 356,
        width: 94,
        height: 70,
    });
    frames.port4 = new CairoFrame_1.default({
        x: 490,
        y: 356,
        width: 94,
        height: 70,
    });
    frames.port5 = new CairoFrame_1.default({
        x: 634,
        y: 356,
        width: 94,
        height: 70,
    });
    frames.wifi2 = new CairoFrame_1.default({
        x: 55,
        y: 445,
        width: 306,
        height: 65,
    });
    frames.wifi5 = new CairoFrame_1.default({
        x: 483,
        y: 445,
        width: 270,
        height: 65,
    });
    frames.uptimeLogo = new CairoFrame_1.default({
        x: 55,
        y: 556,
        width: 57,
        height: 59,
    });
    frames.uptime = new CairoFrame_1.default({
        x: 148,
        y: 568,
        width: 508,
        height: 29,
    });
    frames.coordinatesLogo = new CairoFrame_1.default({
        x: 55,
        y: 645,
        width: 59,
        height: 79,
    });
    frames.coordinates = new CairoFrame_1.default({
        x: 148,
        y: 653,
        width: 525,
        height: 29,
    });
    frames.lastUpdate = new CairoFrame_1.default({
        x: 148,
        y: 694,
        width: 554,
        height: 25,
    });
    cp.insertAll(frames);
}
function mapCOsetup() {
    const map = settings.map;
    const mapCamera = settings.map_camera;
    const options = {
        ip: mapCamera.ip,
        port: mapCamera.port,
        auth: `${mapCamera.user}:${mapCamera.password}`,
        tls: mapCamera.protocol !== 'http',
        tlsInsecure: mapCamera.protocol === 'https_insecure',
    };
    mapCO = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI(options);
    mapCP = new CairoPainter_1.default({
        x: map.x,
        y: map.y,
        width: map.map_width,
        height: map.map_height,
        screen_width: map.width,
        screen_height: map.height,
        co_ord: map.alignment,
    });
}
function mapCOconfigured() {
    const mapCamera = settings.map_camera;
    return (mapCamera.protocol !== '' &&
        mapCamera.port !== null &&
        mapCamera.ip !== '' &&
        mapCamera.user !== '' &&
        mapCamera.password !== '');
}
let portsInfo = [false, false, false, false, false];
function transformSignalStrenght(strenght) {
    if (strenght > -57) {
        return 5;
    }
    else if (strenght > -67) {
        return 4;
    }
    else if (strenght > -82) {
        return 3;
    }
    else if (strenght > -97) {
        return 2;
    }
    else if (strenght > -111) {
        return 1;
    }
    else {
        return 0;
    }
}
function transformConnectionType(connectionType) {
    if (['5G-NSA', '5G-SA'].includes(connectionType)) {
        return '5G';
    }
    else if (['LTE', 'CAT-M1', 'FDD LTE', 'TDD LTE'].includes(connectionType)) {
        return '4G';
    }
    else if ([
        'WCDMA',
        'HSDPA',
        'HSUPA',
        'HSPA',
        'HSPA+',
        'HSDPA and HSUPA',
        'HSDPA and H',
        'HSDPA+HSUPA',
        'DC-HSPA+',
    ].includes(connectionType)) {
        return '3G';
    }
    else if (['CDMA', 'EDGE', 'GPRS', 'GSM', 'CAT-NB1'].includes(connectionType)) {
        return '2G';
    }
    else {
        return connectionType;
    }
}
function getUpdateTime(date) {
    const d = new Date(date);
    let hour = d.getHours().toString();
    let minute = d.getMinutes().toString();
    let second = d.getSeconds().toString();
    if (hour.length === 1) {
        hour = '0' + hour;
    }
    if (minute.length === 1) {
        minute = '0' + minute;
    }
    if (second.length === 1) {
        second = '0' + second;
    }
    return `${d.getDate()}. ${d.getMonth()}. ${d.getFullYear()} ${hour}:${minute}:${second}`;
}
function parseUptime(uptime) {
    let second = (uptime % 60).toString();
    uptime = Math.floor(uptime / 60);
    let minute = (uptime % 60).toString();
    uptime = Math.floor(uptime / 60);
    let hour = (uptime % 24).toString();
    uptime = Math.floor(uptime / 24);
    if (hour.length === 1) {
        hour = '0' + hour;
    }
    if (minute.length === 1) {
        minute = '0' + minute;
    }
    if (second.length === 1) {
        second = `0` + second;
    }
    return `${uptime}:${hour}:${minute}:${second}`;
}
function parseTeltonikaResponse(response, wireless, ports) {
    let wifi2 = false;
    let wifi5 = false;
    for (const { ssid, active } of wireless) {
        if (ssid === 'RUT_C52E_2G' && active === 1) {
            wifi2 = true;
        }
        else if (ssid === 'RUT_C52F_5G' && active === 1) {
            wifi5 = true;
        }
    }
    if (ports) {
        portsInfo = [false, false, false, false, false];
        for (const { name } of ports) {
            portsInfo[parseInt(name.split(' ')[1]) - 1] = true;
        }
    }
    return {
        name: response.name,
        wanIP: response.wan_ip,
        wanState: response.wan_state,
        sim: {
            active: response.sim_state === 'Inserted',
            slot: response.sim_slot,
            strenght: transformSignalStrenght(response.signal),
            operator: response.operator,
            connectionType: transformConnectionType(response.connection_type),
        },
        wifi2,
        wifi5,
        ports: portsInfo,
        uptime: parseUptime(response.router_uptime),
        latitude: response.latitude,
        longitude: response.longitude,
        lastUpdateTime: getUpdateTime(response.last_update_at),
    };
}
function getModemInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const deviceID = settings.modem.device;
            const requestOptions = {
                method: 'GET',
                protocol: 'https:',
                host: 'rms.teltonika-networks.com',
                port: 443,
                path: '/api/devices/' + deviceID,
                headers: {
                    accept: 'application/json',
                    Authorization: `Bearer ${settings.modem.token}`,
                },
            };
            let response = (yield (0, HttpRequest_1.httpRequest)(requestOptions));
            const parsedResponse = JSON.parse(response);
            requestOptions.path += '/wireless';
            response = (yield (0, HttpRequest_1.httpRequest)(requestOptions));
            const wireless = JSON.parse(response);
            requestOptions.path = `/api/devices/${deviceID}/port-scan?type=ethernet`;
            response = (yield (0, HttpRequest_1.httpRequest)(requestOptions));
            const channel = JSON.parse(response).meta.channel;
            requestOptions.path = '/status/channel/' + channel;
            yield setTimeoutPromise(2000);
            response = (yield (0, HttpRequest_1.httpRequest)(requestOptions));
            const ports = JSON.parse(response).data[deviceID][0].ports;
            const mi = parseTeltonikaResponse(parsedResponse.data, wireless.data, ports);
            const promises = new Array();
            if (co !== null && (yield coConnect())) {
                promises.push(displayGraphics(mi));
            }
            if (mapCO !== null && (yield mapCOconnect())) {
                promises.push(displayMap({ latitude: mi.latitude, longitude: mi.longitude }));
            }
            yield allSettled(promises);
        }
        catch (error) {
            console.error(error.message);
        }
        finally {
            setTimeout(getModemInfo, 1000 * settings.modem.refresh_period);
        }
    });
}
function loadImages() {
    return __awaiter(this, void 0, void 0, function* () {
        const imageNames = ['background', 'uptime_logo', 'coordinates_logo', 'wan_wifi', 'wan_wired'];
        for (let f = 1; f <= 5; f += 1) {
            imageNames.push(`port_${f}_active`);
            imageNames.push(`port_${f}_inactive`);
        }
        for (let f = 1; f <= 2; f += 1) {
            imageNames.push(`wan_sim_${f}`);
            imageNames.push(`sim_${f}_active`);
            imageNames.push(`sim_${f}_inactive`);
        }
        for (let f = 2; f <= 5; f += 3) {
            imageNames.push(`wifi_${f}_active`);
            imageNames.push(`wifi_${f}_inactive`);
        }
        for (let f = 0; f <= 5; f += 1) {
            imageNames.push(`strength_${f}`);
        }
        images = {};
        for (const image of imageNames) {
            images[image] = yield co.uploadImageData(fs.readFileSync('img/' + image + '.png'));
        }
    });
}
function loadFonts() {
    return __awaiter(this, void 0, void 0, function* () {
        regular = (yield co.uploadFontData(fs.readFileSync('./fonts/gotham_regular.ttf'))).var;
        bold = (yield co.uploadFontData(fs.readFileSync('./fonts/gotham_bold.ttf'))).var;
    });
}
function updateFrames() {
    cp.setBgImage(images['background'], 'plain');
    frames.routerName.setFont(bold);
    frames.routerIP.setFont(bold);
    frames.connectionType1.setFont(bold);
    frames.operator1.setFont(bold);
    frames.connectionType2.setFont(bold);
    frames.operator2.setFont(bold);
    frames.uptime.setFont(bold);
    frames.coordinates.setFont(bold);
    frames.lastUpdate.setFont(regular);
    frames.uptimeLogo.setBgImage(images['uptime_logo'], 'fit');
    frames.coordinatesLogo.setBgImage(images['coordinates_logo'], 'fit');
}
function coConnect() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!coConnected) {
            co.removeAllListeners();
            co.on('open', () => {
                console.log('COAPI connected');
                coConnected = true;
            });
            co.on('error', function (err) {
                console.log('COAPI-Error: ' + err);
            });
            co.on('close', function () {
                console.log('COAPI-Error: connection closed');
                coConnected = false;
            });
            yield co.connect();
            yield loadImages();
            yield loadFonts();
            updateFrames();
        }
        return coConnected;
    });
}
function displayGraphics(mi) {
    return __awaiter(this, void 0, void 0, function* () {
        const img = mi.sim.slot;
        if (mi.wanState === 'Mobile') {
            frames.wanState.setBgImage(images[`wan_sim_${img}`], 'stretch');
        }
        else if (mi.wanState === 'Wired') {
            frames.wanState.setBgImage(images[`wan_wired`], 'stretch');
        }
        else {
            frames.wanState.setBgImage(images[`wan_wifi`], 'stretch');
        }
        frames.routerName.setText(mi.name, 'A_LEFT');
        frames.routerIP.setText(mi.wanIP, 'A_RIGHT');
        if (img === 1) {
            frames.simInserted1.setBgImage(mi.sim.active ? images[`sim_1_active`] : images[`sim_1_inactive`], 'fit');
            frames.operator1.setText(mi.sim.operator, 'A_LEFT', 'TFM_TRUNCATE');
            frames.connectionType1.setText(mi.sim.connectionType, 'A_LEFT');
            frames.signalStrenght1.setBgImage(images['strength_' + mi.sim.strenght], 'fit');
            frames.simInserted2.setBgImage(images[`sim_2_inactive`], 'fit');
            frames.operator2.setText('', 'A_LEFT');
            frames.connectionType2.setText('', 'A_LEFT');
            frames.signalStrenght2.removeImage();
        }
        else {
            frames.simInserted2.setBgImage(mi.sim.active ? images[`sim_2_active`] : images[`sim_2_inactive`], 'fit');
            frames.operator2.setText(mi.sim.operator, 'A_LEFT', 'TFM_TRUNCATE');
            frames.connectionType2.setText(mi.sim.connectionType, 'A_LEFT');
            frames.signalStrenght2.setBgImage(images['strength_' + mi.sim.strenght], 'fit');
            frames.simInserted1.setBgImage(images[`sim_1_inactive`], 'fit');
            frames.operator1.setText('', 'A_LEFT');
            frames.connectionType1.setText('', 'A_LEFT');
            frames.signalStrenght1.removeImage();
        }
        frames.port1.setBgImage(mi.ports[0] ? images['port_1_active'] : images['port_1_inactive'], 'fit');
        frames.port2.setBgImage(mi.ports[1] ? images['port_2_active'] : images['port_2_inactive'], 'fit');
        frames.port3.setBgImage(mi.ports[2] ? images['port_3_active'] : images['port_3_inactive'], 'fit');
        frames.port4.setBgImage(mi.ports[3] ? images['port_4_active'] : images['port_4_inactive'], 'fit');
        frames.port5.setBgImage(mi.ports[4] ? images['port_5_active'] : images['port_5_inactive'], 'fit');
        frames.wifi2.setBgImage(mi.wifi2 ? images['wifi_2_active'] : images['wifi_2_inactive'], 'fit');
        frames.wifi5.setBgImage(mi.wifi5 ? images['wifi_5_active'] : images['wifi_5_inactive'], 'fit');
        frames.uptime.setText('Device uptime: ' + mi.uptime, 'A_LEFT');
        frames.coordinates.setText(`${mi.latitude} N, ${mi.longitude} E`, 'A_LEFT');
        frames.lastUpdate.setText('Last update: ' + mi.lastUpdateTime, 'A_LEFT');
        yield cp.generate(co, (2 * settings.overlay.scale) / 3);
    });
}
function deg2rad(angle) {
    return (angle * Math.PI) / 180;
}
function calculateDistance(a, b) {
    const aLatRad = deg2rad(a.latitude);
    const aLonRad = deg2rad(a.longitude);
    const bLatRad = deg2rad(b.latitude);
    const bLonRad = deg2rad(b.longitude);
    const sinDiffLat = Math.sin((aLatRad - bLatRad) / 2);
    const sinDiffLon = Math.sin((aLonRad - bLonRad) / 2);
    const aCosLat = Math.cos(aLatRad);
    const bCosLat = Math.cos(bLatRad);
    const c = Math.pow(sinDiffLat, 2) + aCosLat * bCosLat * Math.pow(sinDiffLon, 2);
    return 2000 * 6371 * Math.asin(Math.sqrt(c));
}
let lastCoordinates = null;
function getMapImage(actualCoordinates) {
    return __awaiter(this, void 0, void 0, function* () {
        const map = settings.map;
        return new Promise((resolve, reject) => {
            const params = {
                center: `${actualCoordinates.latitude},${actualCoordinates.longitude}`,
                zoom: map.zoomLevel.toString(),
                size: `${map.map_width}x${map.map_height}`,
                key: map.APIkey,
                markers: `${actualCoordinates.latitude},${actualCoordinates.longitude}`,
            };
            const path = '/maps/api/staticmap?' + new url_1.URLSearchParams(params).toString();
            const options = {
                host: 'maps.googleapis.com',
                port: 443,
                path: path,
            };
            let dataBuffer = Buffer.alloc(0);
            const request = https.request(options, (response) => {
                response.on('data', (chunk) => {
                    dataBuffer = Buffer.concat([dataBuffer, chunk]);
                });
                response.on('error', (err) => {
                    reject(err);
                });
                response.on('end', () => {
                    resolve(dataBuffer);
                });
            });
            request.on('error', (err) => {
                reject(err);
            });
            request.end();
        });
    });
}
function displayMap(actualCoordinates) {
    return __awaiter(this, void 0, void 0, function* () {
        const map = settings.map;
        try {
            if (actualCoordinates === null ||
                (lastCoordinates !== null && calculateDistance(lastCoordinates, actualCoordinates) < map.tolerance)) {
                return;
            }
            lastCoordinates = actualCoordinates;
            const buffer = yield getMapImage(actualCoordinates);
            const image = (yield mapCO.uploadImageData(buffer));
            mapCP.setBgImage(image, 'stretch');
            yield mapCP.generate(mapCO);
        }
        catch (e) {
            console.error(e);
        }
    });
}
function mapCOconnect() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!mapCOconnected) {
            mapCO.removeAllListeners();
            mapCO.on('open', () => {
                console.log('COAPI connected (map)');
                mapCOconnected = true;
            });
            mapCO.on('error', function (err) {
                console.log('COAPI-Error (map): ' + err);
            });
            mapCO.on('close', function () {
                console.log('COAPI-Error (map): connection closed');
                mapCOconnected = false;
            });
            yield mapCO.connect();
        }
        return mapCOconnected;
    });
}
function main() {
    process.on('uncaughtException', (e) => {
        console.error('Uncaught exception:', e);
        process.exit(1);
    });
    process.on('unhandledRejection', (e) => {
        console.error('Unhandled rejection:', e);
        process.exit(1);
    });
    settings = readSettings();
    if (coConfigured()) {
        coSetup();
    }
    if (mapCOconfigured()) {
        mapCOsetup();
    }
    if (!isSetup()) {
        console.error('Application is not configured');
        process.exit(1);
    }
    getModemInfo();
}
main();
