"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const CairoFrame_1 = require("./CairoFrame");
const COORD = {
    top_left: [-1, -1],
    center_left: [-1, 0],
    bottom_left: [-1, 1],
    top_center: [0, -1],
    center: [0, 0],
    bottom_center: [0, 1],
    top_right: [1, -1],
    center_right: [1, 0],
    bottom_right: [1, 1],
};
class CairoPainter extends CairoFrame_1.default {
    constructor(opt) {
        super(opt);
        this.surface = null;
        this.cairo = null;
        this.co_ord = COORD[opt.co_ord];
        this.screen_width = opt.screen_width;
        this.screen_height = opt.screen_height;
    }
    generate(co, scale = 1) {
        return __awaiter(this, void 0, void 0, function* () {
            const access = yield this.begin(co, scale);
            this.surface = access[0];
            this.cairo = access[1];
            const promises = new Array();
            promises.push(this.generateOwnImage(co, this.cairo, 0, 0, scale));
            for (const child of this.children) {
                promises.push(child.generateImage(co, this.cairo, [0, 0], scale));
            }
            promises.push(co.showCairoImage(this.surface, this.convertor(this.co_ord[0], this.screen_width, this.posX, scale * this.width), this.convertor(this.co_ord[1], this.screen_height, this.posY, scale * this.height)));
            yield Promise.all(promises);
            yield this.destroy(co);
        });
    }
    convertor(alignment, screen_size, position, graphics_size) {
        switch (alignment) {
            case -1:
                return alignment + (2.0 * position) / screen_size;
            case 0:
                return alignment - (2.0 * (position + graphics_size / 2)) / screen_size;
            case 1:
                return alignment - (2.0 * (position + graphics_size)) / screen_size;
            default:
                throw new Error('Invalid graphics alignment.');
        }
    }
    begin(co, scale) {
        return __awaiter(this, void 0, void 0, function* () {
            const surface = (yield co.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', Math.floor(this.width * scale), Math.floor(this.height * scale)));
            const cairo = (yield co.cairo('cairo_create', surface.var));
            return [surface.var, cairo.var];
        });
    }
    destroy(co) {
        return __awaiter(this, void 0, void 0, function* () {
            yield co.cairo('cairo_surface_destroy', this.surface);
            yield co.cairo('cairo_destroy', this.cairo);
        });
    }
}
exports.default = CairoPainter;
