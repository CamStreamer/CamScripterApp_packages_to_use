"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseSettingsData = exports.getApiData = void 0;
const http = require("http");
const getAccuweatherPositionAPi = (apiKey, lat, lon) => `http://dataservice.accuweather.com/locations/v1/cities/geoposition/search?apikey=${apiKey}&q=${lat},${lon}`;
const getAccuweatherTemperatureAPi = (apiKey, position) => `http://dataservice.accuweather.com/currentconditions/v1/${position}?apikey=${apiKey}&details=true`;
const fetchApiData = (url) => __awaiter(void 0, void 0, void 0, function* () {
    return new Promise((resolve, reject) => {
        http.get(url, (res) => {
            const data = [];
            res.on('data', (chunk) => {
                data.push(chunk);
            });
            res.on('end', () => {
                const response = Buffer.concat(data).toString();
                if (!(res.statusCode >= 200 && res.statusCode < 300)) {
                    reject(`API returned with error. Status: ${res.statusCode}, ${res.statusMessage}. Response from server: ${response}`);
                }
                else {
                    resolve(response);
                }
            });
        }).on('error', (e) => {
            reject(new NetworkError(`NETWORK ERROR: ${e}`));
        });
    });
});
const getApiData = (apiKey, lat, lon, unit) => __awaiter(void 0, void 0, void 0, function* () {
    const positionResponse = yield fetchApiData(getAccuweatherPositionAPi(apiKey, lat, lon));
    const { Key: locationID, EnglishName } = JSON.parse(positionResponse);
    const temperatureResponse = yield fetchApiData(getAccuweatherTemperatureAPi(apiKey, locationID));
    const { Temperature, Wind, WindGust, RelativeHumidity } = JSON.parse(temperatureResponse)[0];
    return {
        location: EnglishName,
        temperature: `${Temperature[unit].Value}\xB0${Temperature[unit].Unit}`,
        wind: `${Wind.Speed[unit].Value}${Wind.Speed[unit].Unit}`,
        wind_gust: `${WindGust.Speed[unit].Value}${WindGust.Speed[unit].Unit}`,
        humidity: `${RelativeHumidity}%`,
    };
});
exports.getApiData = getApiData;
class NetworkError extends Error {
    constructor(message) {
        super(message);
        this.name = 'Network error';
    }
}
const parseSettingsData = (settings, text) => {
    if (settings.fieldName === '' || settings.serviceId === '') {
        return null;
    }
    return {
        text,
        serviceId: settings.serviceId,
        fieldName: settings.fieldName,
    };
};
exports.parseSettingsData = parseSettingsData;
