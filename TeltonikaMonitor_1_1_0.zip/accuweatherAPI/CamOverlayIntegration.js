"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CamOverlayIntegration = void 0;
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
class CamOverlayIntegration {
    constructor(_options) {
        this._options = _options;
        this._camOverlayApi = new CamOverlayAPI_1.CamOverlayAPI(Object.assign({}, this._options));
    }
    updateCustomGraphicsFieldTextInAllServices(serviceID, fieldName, text) {
        return __awaiter(this, void 0, void 0, function* () {
            const fieldData = [
                {
                    field_name: fieldName,
                    text,
                },
            ];
            try {
                yield this._camOverlayApi.updateCGText(serviceID, fieldData);
            }
            catch (e) {
                console.error(`Error while trying to update custom graphics text. Error: ${e}`);
            }
        });
    }
}
exports.CamOverlayIntegration = CamOverlayIntegration;
