import { z } from 'zod';
export declare const settingsSchema: z.ZodObject<{
    camera_ip: z.ZodString;
    camera_port: z.ZodNumber;
    camera_user: z.ZodString;
    camera_pass: z.ZodString;
    rss_url: z.ZodString;
    channel_name: z.ZodString;
    content_type: z.ZodUnion<[z.ZodLiteral<"title">, z.ZodLiteral<"description">]>;
    output_type: z.ZodUnion<[z.ZodLiteral<"infoticker">, z.ZodLiteral<"custom_graphics">]>;
    service_id: z.ZodNumber;
    cg_field_name: z.ZodString;
    update_interval_s: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    camera_ip: string;
    camera_port: number;
    camera_user: string;
    camera_pass: string;
    rss_url: string;
    channel_name: string;
    content_type: "title" | "description";
    output_type: "infoticker" | "custom_graphics";
    service_id: number;
    cg_field_name: string;
    update_interval_s: number;
}, {
    camera_ip: string;
    camera_port: number;
    camera_user: string;
    camera_pass: string;
    rss_url: string;
    channel_name: string;
    content_type: "title" | "description";
    output_type: "infoticker" | "custom_graphics";
    service_id: number;
    cg_field_name: string;
    update_interval_s: number;
}>;
export type TSettings = z.infer<typeof settingsSchema>;
