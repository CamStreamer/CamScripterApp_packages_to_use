"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseXmlFeed = parseXmlFeed;
exports.fetchFeed = fetchFeed;
const https = require("https");
const http = require("http");
const xml_js_1 = require("xml-js");
function getText(el) {
    if (!el)
        return '';
    if (typeof el === 'string')
        return el;
    return el._text || el._cdata || '';
}
function stripHtml(html) {
    return html.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#8217;/g, "'").replace(/&#8216;/g, "'").replace(/&#8220;/g, '"').replace(/&#8221;/g, '"').replace(/&#8211;/g, '-').replace(/&#8230;/g, '...').replace(/&nbsp;/g, ' ').trim();
}
function toArray(val) {
    if (!val)
        return [];
    return Array.isArray(val) ? val : [val];
}
function parseRSS2(rss) {
    const channel = rss.channel;
    if (!channel) {
        return { channels: [], items: [] };
    }
    const channels = [{
            title: getText(channel.title) || 'Untitled Channel',
        }];
    const rawItems = toArray(channel.item);
    const items = rawItems.map((item) => ({
        title: stripHtml(getText(item.title)),
        description: stripHtml(getText(item.description) || getText(item['content:encoded'])),
    }));
    return { channels, items };
}
function parseAtom(feed) {
    const channels = [{
            title: getText(feed.title) || 'Untitled Feed',
        }];
    const rawEntries = toArray(feed.entry);
    const items = rawEntries.map((entry) => ({
        title: stripHtml(getText(entry.title)),
        description: stripHtml(getText(entry.summary) || getText(entry.content)),
    }));
    return { channels, items };
}
function parseXmlFeed(xml) {
    const parsed = (0, xml_js_1.xml2js)(xml, { compact: true });
    if (parsed.rss) {
        return parseRSS2(parsed.rss);
    }
    if (parsed.feed) {
        return parseAtom(parsed.feed);
    }
    const rdfKey = Object.keys(parsed).find((k) => k.toLowerCase().includes('rdf'));
    if (rdfKey) {
        const rdf = parsed[rdfKey];
        const channelEl = rdf.channel;
        const channels = channelEl
            ? [{ title: getText(channelEl.title) || 'Untitled Channel' }]
            : [];
        const rawItems = toArray(rdf.item);
        const items = rawItems.map((item) => ({
            title: stripHtml(getText(item.title)),
            description: stripHtml(getText(item.description)),
        }));
        return { channels, items };
    }
    return { channels: [], items: [] };
}
function fetchFeed(url, maxRedirects = 5) {
    return new Promise((resolve, reject) => {
        if (maxRedirects <= 0) {
            reject(new Error('Too many redirects'));
            return;
        }
        const client = url.startsWith('https') ? https : http;
        client
            .get(url, (res) => {
            if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                res.resume();
                fetchFeed(res.headers.location, maxRedirects - 1).then(resolve).catch(reject);
                return;
            }
            if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) {
                reject(new Error('HTTP error: ' + res.statusCode));
                return;
            }
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
            res.on('error', (err) => reject(err));
        })
            .on('error', (err) => reject(err));
    });
}
//# sourceMappingURL=rssParser.js.map