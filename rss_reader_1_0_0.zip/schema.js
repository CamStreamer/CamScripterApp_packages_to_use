"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = void 0;
const zod_1 = require("zod");
exports.settingsSchema = zod_1.z.object({
    camera_ip: zod_1.z.string(),
    camera_port: zod_1.z.number(),
    camera_user: zod_1.z.string(),
    camera_pass: zod_1.z.string(),
    rss_url: zod_1.z.string(),
    channel_name: zod_1.z.string(),
    content_type: zod_1.z.union([zod_1.z.literal('title'), zod_1.z.literal('description')]),
    output_type: zod_1.z.union([zod_1.z.literal('infoticker'), zod_1.z.literal('custom_graphics')]),
    service_id: zod_1.z.number(),
    cg_field_name: zod_1.z.string(),
    update_interval_s: zod_1.z.number(),
});
//# sourceMappingURL=schema.js.map