"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const url = require("url");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
const HttpServer_1 = require("camstreamerlib/HttpServer");
const schema_1 = require("./schema");
const rssParser_1 = require("./rssParser");
let settings;
let co;
let items = [];
let currentIndex = 0;
let intervalHandle = null;
let fetchCount = 0;
function readSettings() {
    const dataPath = process.env.PERSISTENT_DATA_PATH || './localdata/';
    const data = fs.readFileSync(dataPath + 'settings.json');
    return schema_1.settingsSchema.parse(JSON.parse(data.toString()));
}
function getDisplayText(item) {
    if (settings.content_type === 'description') {
        return item.description || item.title;
    }
    return item.title;
}
function pushText(text) {
    return __awaiter(this, void 0, void 0, function* () {
        const serviceId = settings.service_id || 1;
        if (settings.output_type === 'custom_graphics') {
            const fieldName = settings.cg_field_name || 'field1';
            yield co.updateCGText(serviceId, [{ field_name: fieldName, text }]);
        }
        else {
            yield co.updateInfoticker(serviceId, encodeURIComponent(text));
        }
    });
}
function displayNextItem() {
    return __awaiter(this, void 0, void 0, function* () {
        if (items.length === 0)
            return;
        if (currentIndex >= items.length) {
            clearInterval(intervalHandle);
            intervalHandle = null;
            yield fetchAndStart();
            return;
        }
        const item = items[currentIndex];
        const text = getDisplayText(item);
        currentIndex++;
        try {
            yield pushText(text);
        }
        catch (err) {
            console.log('Error pushing text: ' + err);
        }
    });
}
function fetchAndStart() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const feedUrl = settings.rss_url || 'https://www.nasa.gov/rss/dyn/breaking_news.rss';
        const interval = (settings.update_interval_s || 10) * 1000;
        try {
            const xml = yield (0, rssParser_1.fetchFeed)(feedUrl);
            const feed = (0, rssParser_1.parseXmlFeed)(xml);
            if (feed.items.length === 0) {
                console.log('No items found in RSS feed, retrying in ' + (interval / 1000) + 's');
                setTimeout(fetchAndStart, interval);
                return;
            }
            items = feed.items;
            currentIndex = 0;
            fetchCount++;
            if (fetchCount % 100 === 1) {
                console.log(`Fetched ${items.length} items from: ${((_a = feed.channels[0]) === null || _a === void 0 ? void 0 : _a.title) || feedUrl}`);
            }
            yield displayNextItem();
            intervalHandle = setInterval(() => {
                displayNextItem();
            }, interval);
        }
        catch (err) {
            console.log('Error fetching RSS: ' + err);
            setTimeout(fetchAndStart, interval);
        }
    });
}
function startHttpServer() {
    const httpServer = new HttpServer_1.HttpServer();
    httpServer.onRequest('/load_feed.cgi', (req, res) => __awaiter(this, void 0, void 0, function* () {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Content-Type', 'application/json');
        const parsedUrl = url.parse(req.url, true);
        const feedUrl = parsedUrl.query.url;
        if (!feedUrl) {
            res.statusCode = 400;
            res.end(JSON.stringify({ error: 'Missing url parameter' }));
            return;
        }
        try {
            const xml = yield (0, rssParser_1.fetchFeed)(feedUrl);
            const feed = (0, rssParser_1.parseXmlFeed)(xml);
            res.statusCode = 200;
            res.end(JSON.stringify(feed));
        }
        catch (err) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: err.message || String(err) }));
        }
    }));
}
function main() {
    try {
        settings = readSettings();
    }
    catch (err) {
        console.log('Failed to read settings: ' + err);
        return;
    }
    co = new CamOverlayAPI_1.CamOverlayAPI({
        ip: settings.camera_ip || '127.0.0.1',
        port: settings.camera_port || 80,
        user: settings.camera_user,
        pass: settings.camera_pass,
    });
    startHttpServer();
    fetchAndStart();
}
process.on('unhandledRejection', (error) => {
    console.log('unhandledRejection', (error === null || error === void 0 ? void 0 : error.message) || error);
});
process.on('uncaughtException', (error) => {
    console.log('uncaughtException', (error === null || error === void 0 ? void 0 : error.message) || error);
});
main();
//# sourceMappingURL=main.js.map