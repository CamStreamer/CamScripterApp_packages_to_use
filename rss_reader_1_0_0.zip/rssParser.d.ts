export type FeedChannel = {
    title: string;
};
export type FeedItem = {
    title: string;
    description: string;
};
export type ParsedFeed = {
    channels: FeedChannel[];
    items: FeedItem[];
};
export declare function parseXmlFeed(xml: string): ParsedFeed;
export declare function fetchFeed(url: string, maxRedirects?: number): Promise<string>;
