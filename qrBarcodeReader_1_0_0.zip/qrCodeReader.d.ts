/// <reference types="node" />
import * as EventEmitter from 'events';
export declare class QRCodeReader extends EventEmitter {
    private keyboardReader;
    private code;
    constructor();
    private keyPressedCallback;
}
