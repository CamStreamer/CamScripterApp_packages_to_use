/// <reference types="node" />
import * as EventEmitter from 'events';
export declare class KeyboardReader extends EventEmitter {
    constructor();
    private start;
    private getUsbDevices;
    private findDevices;
    private readInfoFile;
    private openInput;
    private processEvent;
}
