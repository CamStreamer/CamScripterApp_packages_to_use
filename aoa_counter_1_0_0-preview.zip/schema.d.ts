import { z } from 'zod';
export declare const cameraSchema: z.ZodObject<{
    serviceID: z.ZodNumber;
    fieldName: z.ZodString;
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodString;
    port: z.ZodNumber;
    user: z.ZodString;
    pass: z.ZodString;
}, "strip", z.ZodTypeAny, {
    serviceID: number;
    fieldName: string;
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
}, {
    serviceID: number;
    fieldName: string;
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
}>;
export declare const aoaSchema: z.ZodObject<{
    updateFrequency: z.ZodNumber;
    scenarioId: z.ZodNumber;
    method: z.ZodUnion<[z.ZodLiteral<"getOccupancy">, z.ZodLiteral<"getAccumulatedCounts">]>;
    protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
    ip: z.ZodString;
    port: z.ZodNumber;
    user: z.ZodString;
    pass: z.ZodString;
}, "strip", z.ZodTypeAny, {
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
    updateFrequency: number;
    scenarioId: number;
    method: "getOccupancy" | "getAccumulatedCounts";
}, {
    protocol: "http" | "https" | "https_insecure";
    ip: string;
    port: number;
    user: string;
    pass: string;
    updateFrequency: number;
    scenarioId: number;
    method: "getOccupancy" | "getAccumulatedCounts";
}>;
export declare const settingsSchema: z.ZodObject<{
    camera: z.ZodObject<{
        serviceID: z.ZodNumber;
        fieldName: z.ZodString;
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodString;
        port: z.ZodNumber;
        user: z.ZodString;
        pass: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }, {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    }>;
    aoa: z.ZodObject<{
        updateFrequency: z.ZodNumber;
        scenarioId: z.ZodNumber;
        method: z.ZodUnion<[z.ZodLiteral<"getOccupancy">, z.ZodLiteral<"getAccumulatedCounts">]>;
        protocol: z.ZodUnion<[z.ZodLiteral<"http">, z.ZodLiteral<"https">, z.ZodLiteral<"https_insecure">]>;
        ip: z.ZodString;
        port: z.ZodNumber;
        user: z.ZodString;
        pass: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        updateFrequency: number;
        scenarioId: number;
        method: "getOccupancy" | "getAccumulatedCounts";
    }, {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        updateFrequency: number;
        scenarioId: number;
        method: "getOccupancy" | "getAccumulatedCounts";
    }>;
}, "strip", z.ZodTypeAny, {
    camera: {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    };
    aoa: {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        updateFrequency: number;
        scenarioId: number;
        method: "getOccupancy" | "getAccumulatedCounts";
    };
}, {
    camera: {
        serviceID: number;
        fieldName: string;
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
    };
    aoa: {
        protocol: "http" | "https" | "https_insecure";
        ip: string;
        port: number;
        user: string;
        pass: string;
        updateFrequency: number;
        scenarioId: number;
        method: "getOccupancy" | "getAccumulatedCounts";
    };
}>;
export type TCamera = z.infer<typeof cameraSchema>;
export type TAoa = z.infer<typeof aoaSchema>;
export type TSettings = z.infer<typeof settingsSchema>;
