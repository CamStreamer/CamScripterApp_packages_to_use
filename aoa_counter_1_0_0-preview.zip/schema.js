"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = exports.aoaSchema = exports.cameraSchema = void 0;
const zod_1 = require("zod");
const connectionParams = {
    protocol: zod_1.z.union([zod_1.z.literal('http'), zod_1.z.literal('https'), zod_1.z.literal('https_insecure')]),
    ip: zod_1.z.string(),
    port: zod_1.z.number(),
    user: zod_1.z.string(),
    pass: zod_1.z.string(),
};
exports.cameraSchema = zod_1.z.object(Object.assign(Object.assign({}, connectionParams), { serviceID: zod_1.z.number(), fieldName: zod_1.z.string() }));
exports.aoaSchema = zod_1.z.object(Object.assign(Object.assign({}, connectionParams), { updateFrequency: zod_1.z.number(), scenarioId: zod_1.z.number(), method: zod_1.z.union([zod_1.z.literal('getOccupancy'), zod_1.z.literal('getAccumulatedCounts')]) }));
exports.settingsSchema = zod_1.z.object({
    camera: exports.cameraSchema,
    aoa: exports.aoaSchema,
});
//# sourceMappingURL=schema.js.map