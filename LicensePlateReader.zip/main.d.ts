declare const fs: any;
declare const http: any;
declare const CameraVapix: any;
declare const CamOverlayAPI: any;
declare type Camera = {
    IP: string;
    port: number;
    user: string;
    password: string;
};
declare type Settings = {
    sourceCamera: Camera;
    targetCamera: Camera;
    serviceID: number;
    lpFieldName: string;
    tsFieldName: string;
    timeFormat: string;
    dateFormat: string;
    visibilityTime: number;
};
declare type Format = {
    date: string;
    time: string;
};
declare let settings: Settings;
declare function format_12(hour: number, minute: number, second: number): string;
declare function format_24(hour: number, minute: number, second: number): string;
declare function dateFromTimestamp(timestamp: number, format: Format): string;
declare function sendEnabledRequest(enabledParameter: number): void;
declare let isCamOverlayVisible: boolean;
declare function hideCamOverlay(): void;
declare function showCamOverlay(): void;
declare let timeoutID: any;
declare function displayInCamOverlay(data: any): Promise<void>;
declare function onMessage(data: any): void;
declare function startCameraVapixLibraryWebsocket(): void;
declare function main(): void;
