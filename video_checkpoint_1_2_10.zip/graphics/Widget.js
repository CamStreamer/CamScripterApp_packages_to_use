"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Widget = void 0;
const fs = require("fs");
const cjs_1 = require("camstreamerlib/cjs");
class Widget {
    constructor(cameraSettings, widgetSettings) {
        this.widgetSettings = widgetSettings;
        this.coReady = false;
        const options = {
            tls: cameraSettings.protocol !== 'http',
            tlsInsecure: cameraSettings.protocol === 'https_insecure',
            ip: cameraSettings.ip,
            port: cameraSettings.port,
            user: cameraSettings.user,
            pass: cameraSettings.pass,
            camera: widgetSettings.camera_list,
        };
        this.cod = new cjs_1.CamOverlayDrawingAPI(options);
        this.coConnect();
    }
    showBarCode(text, visibilityTimeSec) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!this.coReady) {
                    return;
                }
                if (this.barcodeFont === undefined) {
                    this.barcodeFont = yield this.uploadFont();
                }
                yield this.renderWidget(text, this.cod);
                clearTimeout(this.visibilityTimer);
                if (visibilityTimeSec !== 0) {
                    this.visibilityTimer = setTimeout(() => {
                        if (this.coReady) {
                            void this.cod.removeImage();
                        }
                    }, visibilityTimeSec * 1000);
                }
            }
            catch (err) {
                console.error(err);
            }
        });
    }
    coConnect() {
        this.cod.removeAllListeners();
        this.cod.on('open', () => {
            console.log('COAPI connected');
            this.coReady = true;
        });
        this.cod.on('error', (err) => {
            console.log('COAPI-Error: ' + err);
        });
        this.cod.on('close', () => {
            console.log('COAPI-Error: connection closed');
            this.coReady = false;
            this.barcodeFont = undefined;
        });
        this.cod.connect();
    }
    renderWidget(text, cod) {
        return __awaiter(this, void 0, void 0, function* () {
            const scaleFactor = this.widgetSettings.scale / 100;
            const resolution = this.widgetSettings.stream_resolution.split('x').map(Number);
            const widgetWidth = Math.round(600 * scaleFactor);
            const widgetHeight = Math.round(130 * scaleFactor);
            const surfaceResponse = (yield cod.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', widgetWidth, widgetHeight));
            const surface = surfaceResponse.var;
            const cairoResponse = (yield cod.cairo('cairo_create', surface));
            const cairo = cairoResponse.var;
            void cod.cairo('cairo_set_font_face', cairo, this.barcodeFont);
            void cod.cairo('cairo_set_font_size', cairo, 70);
            const textExtents = (yield cod.cairo('cairo_text_extents', cairo, `*${text}*`)).var;
            const margin = 60;
            const barcodeWidth = Math.min(600 - margin, textExtents.width);
            void cod.cairo('cairo_scale', cairo, scaleFactor, scaleFactor);
            void cod.cairo('cairo_rectangle', cairo, 0, 0, barcodeWidth + margin, 320);
            void cod.cairo('cairo_set_source_rgb', cairo, 1.0, 1.0, 1.0);
            void cod.cairo('cairo_fill', cairo);
            void cod.cairo('cairo_stroke', cairo);
            const textPos = margin / 2;
            void cod.cairo('cairo_set_font_face', cairo, this.barcodeFont);
            void cod.cairo('cairo_set_font_size', cairo, 70);
            void cod.cairo('cairo_set_source_rgb', cairo, 0.0, 0.0, 0.0);
            void cod.writeText(cairo, `*${text}*`, textPos, 5, barcodeWidth, 70, 'A_CENTER', 'TFM_SCALE');
            void cod.cairo('cairo_set_font_face', cairo, 'NULL');
            void cod.writeText(cairo, text, textPos, 80, barcodeWidth, 30, 'A_CENTER', 'TFM_SCALE');
            const pos = this.computePosition(this.widgetSettings.coord_system, this.widgetSettings.pos_x, this.widgetSettings.pos_y, (barcodeWidth + margin) * scaleFactor, widgetHeight, resolution[0], resolution[1]);
            yield cod.showCairoImageAbsolute(surface, pos.x, pos.y, resolution[0], resolution[1]);
            void cod.cairo('cairo_surface_destroy', surface);
            void cod.cairo('cairo_destroy', cairo);
        });
    }
    uploadFont() {
        return __awaiter(this, void 0, void 0, function* () {
            const imgData = fs.readFileSync('fonts/fre3of9x.ttf');
            const fontRes = yield this.cod.uploadFontData(imgData);
            return fontRes.var;
        });
    }
    computePosition(coordSystem, posX, posY, width, height, streamWidth, streamHeight) {
        let x = posX;
        let y = posY;
        switch (coordSystem) {
            case 'top_right':
                x = streamWidth - width - posX;
                break;
            case 'bottom_left':
                y = streamHeight - height - posY;
                break;
            case 'bottom_right':
                x = streamWidth - width - posX;
                y = streamHeight - height - posY;
                break;
        }
        return { x, y };
    }
}
exports.Widget = Widget;
