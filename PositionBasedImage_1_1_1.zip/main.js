"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const net = require("net");
const https = require("https");
const url_1 = require("url");
const CamOverlayAPI_1 = require("camstreamerlib/CamOverlayAPI");
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
let activeServices = [];
let settings;
const serviceIDs = [];
const co = null;
let mapCO = null;
function deg2rad(angle) {
    return (angle * Math.PI) / 180;
}
function calculateDistance(a, b) {
    const aLatRad = deg2rad(a.latitude);
    const aLonRad = deg2rad(a.longitude);
    const bLatRad = deg2rad(b.latitude);
    const bLonRad = deg2rad(b.longitude);
    const sinDiffLat = Math.sin((aLatRad - bLatRad) / 2);
    const sinDiffLon = Math.sin((aLonRad - bLonRad) / 2);
    const aCosLat = Math.cos(aLatRad);
    const bCosLat = Math.cos(bLatRad);
    const c = Math.pow(sinDiffLat, 2) + aCosLat * bCosLat * Math.pow(sinDiffLon, 2);
    return 2000 * 6371 * Math.asin(Math.sqrt(c));
}
function serverResponseParse(lines) {
    let returnValue = null;
    for (const line of lines) {
        const items = line.split(',');
        if (items.length >= 7 &&
            items[0] === '$GPRMC' &&
            items[3] !== '' &&
            items[4] !== '' &&
            items[5] !== '' &&
            items[6] !== '') {
            let lat = Number.parseFloat(items[3]) / 100;
            let lon = Number.parseFloat(items[5]) / 100;
            const latD = Math.floor(lat);
            const latM = ((lat - Math.floor(lat)) * 100) / 60;
            lat = latD + latM;
            const lonD = Math.floor(lon);
            const lonM = ((lon - Math.floor(lon)) * 100) / 60;
            lon = lonD + lonM;
            if (items[4] == 'S') {
                lat *= -1;
            }
            if (items[6] == 'W') {
                lon *= -1;
            }
            returnValue = { latitude: lat, longitude: lon };
        }
    }
    return returnValue;
}
function synchroniseCamOverlay() {
    return __awaiter(this, void 0, void 0, function* () {
        for (const id of serviceIDs) {
            const isEnabled = yield co.isEnabled(id);
            if (!isEnabled && activeServices.includes(id)) {
                co.setEnabled(id, true);
            }
            else if (isEnabled && !activeServices.includes(id)) {
                co.setEnabled(id, false);
            }
        }
    });
}
function isEqual(a, b) {
    let equal = a.length == b.length;
    if (equal) {
        for (let i = 0; i < a.length && equal; i++) {
            equal = equal && a[i] == b[i];
        }
    }
    return equal;
}
function getServiceIDs(actualCoordinates) {
    for (const area of settings.areas) {
        const distance = calculateDistance(actualCoordinates, area.coordinates);
        if (distance <= area.radius) {
            return area.serviceIDs.sort();
        }
    }
    return [];
}
function serverConnect() {
    const server = net.createServer((client) => {
        client.setTimeout(30000);
        let dataBuffer = Buffer.alloc(0);
        client.on('data', (data) => {
            dataBuffer = Buffer.concat([dataBuffer, data]);
            const lines = data.toString().split('\r\n');
            lines.pop();
            const coor = serverResponseParse(lines);
            dataBuffer = Buffer.from(lines[lines.length - 1]);
            if (coor !== null) {
                actualCoordinates = coor;
                const ids = getServiceIDs(coor);
                if (!isEqual(ids, activeServices)) {
                    activeServices = ids;
                    synchroniseCamOverlay();
                }
            }
        });
        client.on('timeout', () => {
            console.log('Client request time out.');
            client.end();
            process.exit(1);
        });
    });
    server.listen(10110, () => {
        server.on('close', () => {
            console.log('TCP server socket is closed.');
            process.exit(1);
        });
        server.on('error', (error) => {
            console.log(JSON.stringify(error));
            process.exit(1);
        });
        setInterval(synchroniseCamOverlay, 60000);
    });
}
let actualCoordinates = null;
let lastCoordinates = null;
function getMapImage() {
    return new Promise((resolve, reject) => {
        const params = {
            center: `${actualCoordinates.latitude},${actualCoordinates.longitude}`,
            zoom: settings.zoomLevel.toString(),
            size: `${settings.width}x${settings.height}`,
            key: settings.APIkey,
            markers: `${actualCoordinates.latitude},${actualCoordinates.longitude}`,
        };
        const path = '/maps/api/staticmap?' + new url_1.URLSearchParams(params).toString();
        const options = {
            host: 'maps.googleapis.com',
            port: 443,
            path: path,
        };
        let dataBuffer = Buffer.alloc(0);
        const request = https.request(options, (response) => {
            response.on('data', (chunk) => {
                dataBuffer = Buffer.concat([dataBuffer, chunk]);
            });
            response.on('end', () => {
                resolve(dataBuffer);
            });
        });
        request.on('error', (err) => {
            reject(err);
        });
        request.end();
    });
}
function synchroniseMap() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (actualCoordinates == null ||
                (lastCoordinates != null && calculateDistance(lastCoordinates, actualCoordinates) < settings.tolerance)) {
                return;
            }
            lastCoordinates = actualCoordinates;
            const buffer = yield getMapImage();
            const image = (yield mapCO.uploadImageData(buffer)).var;
            const surface = (yield mapCO.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', settings.width, settings.height)).var;
            const cairo = (yield mapCO.cairo('cairo_create', surface)).var;
            mapCO.cairo('cairo_set_source_surface', cairo, image, 0, 0);
            mapCO.cairo('cairo_paint', cairo);
            mapCO.showCairoImageAbsolute(surface, settings.positionX, settings.positionY, settings.streamWidth, settings.streamHeight);
            mapCO.cairo('cairo_surface_destroy', image);
            mapCO.cairo('cairo_surface_destroy', surface);
            mapCO.cairo('cairo_destroy', cairo);
        }
        catch (e) {
            console.log(e);
        }
        finally {
            setTimeout(synchroniseMap, 1000 * settings.updatePeriod);
        }
    });
}
function openMap() {
    return __awaiter(this, void 0, void 0, function* () {
        const options = {
            ip: settings.targetCamera.IP,
            port: settings.targetCamera.port,
            auth: settings.targetCamera.user + ':' + settings.targetCamera.password,
            serviceName: 'Position Based Image',
        };
        mapCO = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI(options);
        mapCO.on('error', (error) => {
            console.log(error);
            process.exit(1);
        });
        yield mapCO.connect();
        if (settings.enableMapCO) {
            synchroniseMap();
        }
        else {
            mapCO.removeImage();
        }
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const path = process.env.PERSISTENT_DATA_PATH;
            const data = fs.readFileSync(path + 'settings.json');
            settings = JSON.parse(data.toString());
            if (settings.updatePeriod == null || settings.updatePeriod < 1) {
                settings.updatePeriod = 4;
            }
        }
        catch (error) {
            console.log('Error with Settings file: ', error);
            return;
        }
        for (const area of settings.areas) {
            area.serviceIDs.sort();
            for (const serviceID of area.serviceIDs) {
                serviceIDs.push(serviceID);
            }
        }
        try {
            const options = {
                ip: settings.targetCamera.IP,
                port: settings.targetCamera.port,
                auth: `${settings.targetCamera.user}:${settings.targetCamera.password}`,
            };
            const co = new CamOverlayAPI_1.CamOverlayAPI(options);
            for (const serviceID of serviceIDs) {
                yield co.setEnabled(serviceID, false);
            }
        }
        catch (error) {
            console.log(`Cannot connect to CamOverlay.`);
            console.log(error);
        }
        yield openMap();
        serverConnect();
    });
}
process.on('unhandledRejection', (reason) => {
    console.log(reason);
    process.exit(1);
});
main();
