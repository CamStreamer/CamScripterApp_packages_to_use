"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const schema_1 = require("./schema");
const Widget_1 = require("./graphics/Widget");
const utils_1 = require("./utils");
const constants_1 = require("./constants");
let settings;
let widget;
let airQualityReader = false;
let retryTimeout = null;
let dataBuffer = '';
let prevData = null;
let data = constants_1.DEFAULT_DATA;
function readSettings() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return schema_1.serverDataSchema.parse(JSON.parse(data.toString()));
    }
    catch (err) {
        console.log('Read settings error:', err instanceof Error ? err.message : 'unknown');
        process.exit(1);
    }
}
function watchAirQualityData() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Watching air quality data...');
        if (retryTimeout) {
            clearTimeout(retryTimeout);
            retryTimeout = null;
        }
        try {
            const response = yield fetch(`${settings.source_camera.protocol}://${settings.source_camera.ip}/axis-cgi/airquality/metadata.cgi`, {
                headers: { Accept: 'text/event-stream' },
            });
            if (response.body === null) {
                console.error('No data:', response.statusText);
                return;
            }
            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            while (true) {
                try {
                    const { done, value } = yield reader.read();
                    if (done) {
                        console.warn('Stream ended unexpectedly.');
                        break;
                    }
                    dataBuffer += decoder.decode(value, { stream: true });
                    const lines = dataBuffer.split('\n');
                    if (lines.length < 2) {
                        continue;
                    }
                    const lineIndex = lines.length - 2;
                    const values = lines[lineIndex].split(', ').map((value) => value.split(' = '));
                    dataBuffer = lines[lines.length - 1];
                    const unit = settings.widget.units;
                    for (const v of values) {
                        const [key, value] = v;
                        if (key === 'Temperature') {
                            data.Temperature = {
                                value: (0, utils_1.getTemperature)(value, unit),
                                severity: (0, utils_1.getSeverity)(key, parseFloat(value)),
                            };
                        }
                        else {
                            const typedKey = key;
                            data[typedKey] = {
                                value: Number(value) % 1 === 0 ? Number(value) : Number(value).toFixed(1),
                                severity: (0, utils_1.getSeverity)(typedKey, Number(value)),
                            };
                        }
                    }
                    const shouldUpdate = shouldUpdateWidget();
                    if (shouldUpdate) {
                        widget === null || widget === void 0 ? void 0 : widget.displayWidget(data, unit);
                    }
                }
                catch (err) {
                    console.error('Error processing stream data:', err);
                    break;
                }
            }
        }
        catch (err) {
            console.error('Error fetching air quality data:', err);
        }
        finally {
            console.log('Restarting air quality data watcher...');
            retryTimeout = setTimeout(watchAirQualityData, 5000);
        }
    });
}
function shouldUpdateWidget() {
    if (prevData === null) {
        prevData = Object.assign({}, data);
        return true;
    }
    for (const key in data) {
        if (data[key].value !== prevData[key].value) {
            prevData = Object.assign({}, data);
            return true;
        }
    }
    return false;
}
function main() {
    try {
        settings = readSettings();
        if (settings.source_camera.ip.length !== 0 &&
            settings.source_camera.user.length !== 0 &&
            settings.source_camera.pass.length !== 0) {
            airQualityReader = true;
        }
        else {
            console.log('The Axis Air Quality Sensor is not configured and thus is disabled.');
        }
        if (settings.output_camera.ip.length !== 0 &&
            settings.output_camera.user.length !== 0 &&
            settings.output_camera.pass.length !== 0) {
            widget = new Widget_1.Widget(settings.output_camera, settings.widget);
        }
        else {
            console.log('The CamOverlay widget is not configured and thus is disabled.');
        }
        if (airQualityReader && widget) {
            watchAirQualityData();
        }
        console.log('Application started');
    }
    catch (err) {
        console.error('Application start:', err);
        process.exit(1);
    }
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
    console.error('Unhandled rejection:', err);
});
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received');
    process.exit(0);
});
process.on('SIGINT', () => {
    console.log('SIGINT signal received');
    process.exit(0);
});
main();
