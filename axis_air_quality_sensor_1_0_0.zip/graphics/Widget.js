"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Widget = void 0;
const fs = require("fs");
const constants_1 = require("../constants");
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
class Widget {
    constructor(cameraSettings, widgetSettings) {
        this.widgetSettings = widgetSettings;
        this.coReady = false;
        const options = {
            tls: cameraSettings.protocol !== 'http',
            tlsInsecure: cameraSettings.protocol === 'https_insecure',
            ip: cameraSettings.ip,
            port: cameraSettings.port,
            user: cameraSettings.user,
            pass: cameraSettings.pass,
            camera: widgetSettings.camera_list,
        };
        this.cod = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI(options);
        this.coConnect();
    }
    displayWidget(data, unit) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!this.coReady) {
                    return;
                }
                if (this.fontRegular === undefined) {
                    this.fontRegular = yield this.uploadFont('OpenSans-Regular.ttf');
                }
                if (this.fontBold === undefined) {
                    this.fontBold = yield this.uploadFont('OpenSans-Bold.ttf');
                }
                if (this.background === undefined) {
                    this.background = yield this.uploadImage('background/axis-air-quality-widget.png');
                }
                yield this.renderWidget(data, `°${unit}`, this.cod);
            }
            catch (err) {
                console.error(err);
            }
        });
    }
    coConnect() {
        this.cod.removeAllListeners();
        this.cod.on('open', () => {
            console.log('COAPI connected');
            this.fontRegular = undefined;
            this.fontBold = undefined;
            this.background = undefined;
            this.gif = undefined;
            this.coReady = true;
        });
        this.cod.on('error', (err) => {
            console.log('COAPI-Error: ' + err);
        });
        this.cod.on('close', () => {
            console.log('COAPI-Error: connection closed');
            this.coReady = false;
        });
        this.cod.connect();
    }
    renderWidget(data, unit, cod) {
        return __awaiter(this, void 0, void 0, function* () {
            const scaleFactor = this.widgetSettings.scale / 100;
            const resolution = this.widgetSettings.stream_resolution.split('x').map(Number);
            const widgetWidth = Math.round(1700 * scaleFactor);
            const widgetHeight = Math.round(544 * scaleFactor);
            const surfaceResponse = (yield cod.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', widgetWidth, widgetHeight));
            const surface = surfaceResponse.var;
            const cairoResponse = (yield cod.cairo('cairo_create', surface));
            const cairo = cairoResponse.var;
            void cod.cairo('cairo_scale', cairo, scaleFactor, scaleFactor);
            if (this.background) {
                void cod.cairo('cairo_set_source_surface', cairo, this.background, 0, 0);
                void cod.cairo('cairo_paint', cairo);
            }
            void cod.cairo('cairo_set_font_face', cairo, this.fontBold);
            this.drawLine(cod, cairo, 43, 533, 121, constants_1.SEVERITY[data.Humidity.severity]);
            this.drawLine(cod, cairo, 43, 533, 247, constants_1.SEVERITY[data.Temperature.severity]);
            this.drawLine(cod, cairo, 43, 533, 373, constants_1.SEVERITY[data.Vaping.severity]);
            this.drawLine(cod, cairo, 620, 800, 247, constants_1.SEVERITY[data['PM1.0'].severity]);
            this.drawLine(cod, cairo, 620, 800, 373, constants_1.SEVERITY[data['PM2.5'].severity]);
            this.drawLine(cod, cairo, 850, 1030, 247, constants_1.SEVERITY[data['PM4.0'].severity]);
            this.drawLine(cod, cairo, 850, 1030, 373, constants_1.SEVERITY[data['PM10.0'].severity]);
            this.drawLine(cod, cairo, 1109, 1650, 120, constants_1.SEVERITY[data.VOC.severity]);
            this.drawLine(cod, cairo, 1109, 1650, 247, constants_1.SEVERITY[data.NOx.severity]);
            this.drawLine(cod, cairo, 1109, 1650, 373, constants_1.SEVERITY[data.CO2.severity]);
            this.drawLine(cod, cairo, 40, 800, 540, constants_1.SEVERITY[data.AQI.severity]);
            void cod.cairo('cairo_set_font_face', cairo, this.fontBold);
            this.writeText(cod, cairo, data.Humidity.value, 260, constants_1.POS.firstRow);
            this.writeText(cod, cairo, data.Temperature.value, 260, constants_1.POS.secondRow);
            this.writeText(cod, cairo, data['PM1.0'].value, 600, constants_1.POS.secondRow);
            this.writeText(cod, cairo, data['PM2.5'].value, 600, constants_1.POS.thirdRow);
            this.writeText(cod, cairo, data['PM4.0'].value, 830, constants_1.POS.secondRow);
            this.writeText(cod, cairo, data['PM10.0'].value, 830, constants_1.POS.thirdRow);
            this.writeText(cod, cairo, data.VOC.value, 1380, constants_1.POS.firstRow);
            this.writeText(cod, cairo, data.NOx.value, 1380, constants_1.POS.secondRow);
            this.writeText(cod, cairo, data.CO2.value, 1380, constants_1.POS.thirdRow);
            this.writeText(cod, cairo, data.AQI.value === 0 ? 'Calculating' : data.AQI.value.toString(), 350, constants_1.POS.fourthRow);
            void cod.cairo('cairo_set_font_face', cairo, this.fontRegular);
            this.writeText(cod, cairo, '%RH', 470, 50, 'small');
            this.writeText(cod, cairo, constants_1.GRAM_UNIT, 940, 50, 'small');
            this.writeText(cod, cairo, data.Vaping.value === 0 ? 'UNDETECTED' : 'DETECTED', 330, constants_1.POS.thirdRow + 15, 'small');
            this.writeText(cod, cairo, unit, 470, 170, 'small');
            this.writeText(cod, cairo, 'ppm', 1450, constants_1.POS.thirdRow + 10, 'small', true);
            const pos = this.computePosition(this.widgetSettings.coord_system, this.widgetSettings.pos_x, this.widgetSettings.pos_y, widgetWidth, widgetHeight, resolution[0], resolution[1]);
            yield cod.showCairoImageAbsolute(surface, pos.x, pos.y, resolution[0], resolution[1]);
            void cod.cairo('cairo_surface_destroy', surface);
            void cod.cairo('cairo_destroy', cairo);
        });
    }
    uploadFont(fontName) {
        return __awaiter(this, void 0, void 0, function* () {
            const imgData = fs.readFileSync(`fonts/${fontName}`);
            const fontRes = yield this.cod.uploadFontData(imgData);
            return fontRes.var;
        });
    }
    uploadImage(fileName) {
        return __awaiter(this, void 0, void 0, function* () {
            const imgData = fs.readFileSync(fileName);
            const imgResponse = yield this.cod.uploadImageData(imgData);
            return imgResponse.var;
        });
    }
    drawLine(cod, cairo, startPosX, endPosX, posY, color) {
        const radius = 8 / 2;
        void cod.cairo('cairo_set_source_rgb', cairo, color[0], color[1], color[2]);
        void cod.cairo('cairo_arc', cairo, startPosX, posY, radius, 0, 2 * Math.PI);
        void cod.cairo('cairo_fill', cairo);
        void cod.cairo('cairo_arc', cairo, endPosX, posY, radius, 0, 2 * Math.PI);
        void cod.cairo('cairo_fill', cairo);
        void cod.cairo('cairo_set_line_width', cairo, 8);
        void cod.cairo('cairo_move_to', cairo, startPosX, posY);
        void cod.cairo('cairo_line_to', cairo, endPosX, posY);
        void cod.cairo('cairo_stroke', cairo);
        void cod.cairo('cairo_set_source_rgb', cairo, 1, 1, 1);
    }
    writeText(cod, cairo, value, posX, posY, fontSize, ppm) {
        void cod.writeText(cairo, value.toString(), posX, posY, 200, fontSize === 'small' ? constants_1.FONT.small : constants_1.FONT.big, fontSize === 'small' ? (ppm ? 'A_RIGHT' : 'A_LEFT') : 'A_RIGHT', 'TFM_SCALE');
    }
    computePosition(coordSystem, posX, posY, width, height, streamWidth, streamHeight) {
        let x = posX;
        let y = posY;
        switch (coordSystem) {
            case 'top_right':
                x = streamWidth - width - posX;
                break;
            case 'bottom_left':
                y = streamHeight - height - posY;
                break;
            case 'bottom_right':
                x = streamWidth - width - posX;
                y = streamHeight - height - posY;
                break;
        }
        return { x, y };
    }
}
exports.Widget = Widget;
