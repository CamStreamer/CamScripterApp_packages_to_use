"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSeverity = exports.getTemperature = void 0;
const constants_1 = require("./constants");
const getTemperature = (temperature, unit) => {
    if (unit === 'F') {
        return ((parseFloat(temperature) * 9) / 5 + 32).toFixed(1);
    }
    return parseFloat(temperature).toFixed(1);
};
exports.getTemperature = getTemperature;
const getSeverity = (param, value) => {
    if (param === 'Vaping') {
        return value > 0 ? 'unhealthy' : 'good';
    }
    const tiers = constants_1.QUALITY_TIERS[param];
    const tierKeys = Object.keys(tiers);
    if (tierKeys.length === 0) {
        return 'good';
    }
    for (const tier of tierKeys) {
        const [lowest, highest] = tiers[tier];
        if (value >= lowest && value <= highest) {
            return tier;
        }
    }
    return 'hazardous';
};
exports.getSeverity = getSeverity;
