"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Widget = void 0;
const CamOverlayDrawingAPI_1 = require("camstreamerlib/CamOverlayDrawingAPI");
const MemoryManager_1 = require("./MemoryManager");
const CairoPainter_1 = require("./CairoPainter");
const CairoFrame_1 = require("./CairoFrame");
class Widget {
    constructor(settings) {
        this.settings = settings;
        this.coConnected = false;
        this.layoutReady = false;
        const options = {
            ip: this.settings.camera_ip,
            port: this.settings.camera_port,
            auth: `${this.settings.camera_user}:${this.settings.camera_pass}`,
            tls: false,
        };
        this.cod = new CamOverlayDrawingAPI_1.CamOverlayDrawingAPI(options);
    }
    stop() {
        this.cod.removeAllListeners();
        this.cod.disconnect();
    }
    updateVolume(volume) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!(yield this.coConnect())) {
                    return;
                }
                if (!this.layout || !this.mm) {
                    return;
                }
                const date = new Date();
                const hours = date.getHours();
                const minutes = date.getMinutes().toString().padStart(2, '0');
                this.layout.currentTime.setText(hours + ':' + minutes, 'A_CENTER');
                this.layout.currentBeer.setBgImage(yield this.mm.image(this.getBeerIndex(volume)), 'fit');
                this.layout.volume.setText(volume.toFixed(2) + ' l', 'A_CENTER');
                this.layout.beerCount.setText(Math.floor(volume * 2).toString(), 'A_RIGHT');
                yield this.layout.background.generate(this.cod, this.settings.scale / 100);
            }
            catch (err) {
                console.error('Generate widget error: ', err);
            }
        });
    }
    coConnect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.coConnected) {
                this.coConnected = true;
                this.cod.removeAllListeners();
                this.cod.on('open', () => __awaiter(this, void 0, void 0, function* () {
                    console.log('COAPI connected');
                    this.mm = new MemoryManager_1.MemoryManager(this.cod);
                    this.prepareImages(this.mm);
                    this.layout = yield this.createLayout(this.mm);
                    this.layoutReady = true;
                }));
                this.cod.on('error', (err) => {
                    console.log('COAPI-Error: ' + err);
                });
                this.cod.on('close', () => {
                    console.log('COAPI-Error: connection closed');
                    this.coConnected = false;
                    this.layoutReady = false;
                });
                yield this.cod.connect();
            }
            return this.layoutReady;
        });
    }
    prepareImages(mm) {
        mm.registerImage('1', '1-empty.png');
        mm.registerImage('2', '2-almost-empty.png');
        mm.registerImage('3', '3-almost-full.png');
        mm.registerImage('4', '4-full.png');
        mm.registerImage('bg', 'axis_bg.png');
    }
    createLayout(mm) {
        return __awaiter(this, void 0, void 0, function* () {
            const background = new CairoPainter_1.default({
                x: this.settings.pos_x,
                y: this.settings.pos_y,
                width: 500,
                height: 760,
                screenWidth: this.settings.res_w,
                screenHeight: this.settings.res_h,
                coAlignment: this.settings.coord,
            });
            background.setBgImage(yield mm.image('bg'), 'fit');
            const startTime = new CairoFrame_1.default({
                x: 35,
                y: 205,
                width: 180,
                height: 48,
            });
            startTime.setText(this.settings.start_time, 'A_CENTER');
            const currentTime = new CairoFrame_1.default({
                x: 260,
                y: 205,
                width: 180,
                height: 48,
            });
            currentTime.setText('12:20', 'A_CENTER');
            const beerBackground = new CairoFrame_1.default({
                x: 90,
                y: 355,
                width: 110,
                height: 128,
            });
            beerBackground.setBgImage(yield mm.image('4'), 'fit');
            const currentBeer = new CairoFrame_1.default({
                x: 310,
                y: 355,
                width: 110,
                height: 128,
            });
            currentBeer.setBgImage(yield mm.image('1'), 'fit');
            const beerCount = new CairoFrame_1.default({
                x: 45,
                y: 275,
                width: 100,
                height: 48,
            });
            beerCount.setText('24', 'A_RIGHT');
            const volume = new CairoFrame_1.default({
                x: 50,
                y: 500,
                width: 400,
                height: 80,
            });
            volume.setText('62.00 l', 'A_CENTER');
            const groupName = new CairoFrame_1.default({
                x: 50,
                y: 595,
                width: 400,
                height: 40,
            });
            groupName.setText(this.settings.group_name, 'A_CENTER');
            background.insert(startTime, currentTime, beerBackground, currentBeer, beerCount, volume, groupName);
            return {
                background,
                startTime,
                currentTime,
                currentBeer,
                beerBackground,
                beerCount,
                volume,
                groupName,
            };
        });
    }
    getBeerIndex(volumeLiters) {
        const ml = (volumeLiters % 0.5) * 1000;
        if (ml < 125) {
            return '1';
        }
        else if (ml < 250) {
            return '2';
        }
        else if (ml < 375) {
            return '3';
        }
        else {
            return '4';
        }
    }
}
exports.Widget = Widget;
