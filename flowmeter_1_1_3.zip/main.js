"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const HttpServer_1 = require("camstreamerlib/HttpServer");
const schema_1 = require("./schema");
const SpinelController_1 = require("./SpinelController");
const Widget_1 = require("./Widget");
console.log('Starting Flowmeter Package...');
let settings;
let widget;
const httpServer = new HttpServer_1.HttpServer();
httpServer.on('access', (msg) => {
    console.log(msg);
});
httpServer.on('error', (err) => {
    console.log(err);
});
httpServer.onRequest('/reset_counter.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('access: reset counter');
        if (!spinelController.isStarted()) {
            yield spinelController.reset();
            res.statusCode = 200;
        }
        else {
            console.error('Cannot reset counter when the counting is running');
            res.statusCode = 400;
        }
    }
    catch (err) {
        console.error('Cannot reset counter, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
httpServer.onRequest('/calibration_start.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('access: calibration start');
        yield spinelController.calibrationStart();
        res.statusCode = 200;
    }
    catch (err) {
        console.error('Cannot start calibration, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
httpServer.onRequest('/calibration_calibrate.cgi', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        console.log('access: calibration end');
        const url = new URL((_a = req.url) !== null && _a !== void 0 ? _a : '', 'http://127.0.0.1/');
        if (!url.searchParams.has('volume')) {
            throw new Error('volume not found');
        }
        const volume = parseFloat(url.searchParams.get('volume'));
        if (isNaN(volume)) {
            throw new Error('invalid volume specified');
        }
        yield spinelController.calibrationCalibrate(volume);
        res.statusCode = 200;
    }
    catch (err) {
        console.error('Cannot finish calibration, error:', err);
        res.statusCode = 500;
    }
    finally {
        res.end();
    }
}));
const spinelController = new SpinelController_1.SpinelController();
spinelController.on('volume', (volume) => __awaiter(void 0, void 0, void 0, function* () {
    if (widget) {
        yield widget.updateVolume(volume);
    }
}));
function start() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let oldSettings = '';
            if (settings) {
                const { started: tmp1 } = settings, restOfSettingsOld = __rest(settings, ["started"]);
                void tmp1;
                oldSettings = JSON.stringify(restOfSettingsOld);
            }
            settings = readConfiguration();
            const { started: tmp2 } = settings, restOfSettings = __rest(settings, ["started"]);
            void tmp2;
            const newSettings = JSON.stringify(restOfSettings);
            if (widget && oldSettings !== newSettings) {
                yield widget.stop();
                widget = undefined;
            }
            if (!widget) {
                widget = new Widget_1.Widget(settings);
            }
            if (settings.started) {
                yield spinelController.start();
            }
        }
        catch (err) {
            console.log(err);
        }
    });
}
function stop() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield spinelController.stop();
        }
        catch (err) {
            console.log(err);
        }
    });
}
function readConfiguration() {
    try {
        const data = fs.readFileSync(process.env.PERSISTENT_DATA_PATH + 'settings.json');
        return schema_1.settingsSchema.parse(JSON.parse(data.toString()));
    }
    catch (err) {
        console.log('Application is not configured or configuration error:', err);
        process.exit(1);
    }
}
process.on('SIGINT', () => __awaiter(void 0, void 0, void 0, function* () {
    yield stop();
    yield start();
}));
process.on('SIGTERM', () => __awaiter(void 0, void 0, void 0, function* () {
    yield httpServer.close();
    yield stop();
    process.exit(0);
}));
void start();
