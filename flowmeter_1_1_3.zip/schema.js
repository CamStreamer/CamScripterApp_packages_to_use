"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsSchema = void 0;
const zod_1 = require("zod");
exports.settingsSchema = zod_1.z.object({
    started: zod_1.z.boolean(),
    camera_ip: zod_1.z.string().min(1),
    camera_port: zod_1.z.number().positive(),
    camera_user: zod_1.z.string().min(1),
    camera_pass: zod_1.z.string().min(1),
    coord: zod_1.z.string(),
    pos_x: zod_1.z.number(),
    pos_y: zod_1.z.number(),
    res_w: zod_1.z.number().positive(),
    res_h: zod_1.z.number().positive(),
    group_name: zod_1.z.string(),
    start_time: zod_1.z.string(),
    scale: zod_1.z.number().positive(),
});
