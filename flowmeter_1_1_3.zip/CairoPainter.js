"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const CairoFrame_1 = require("./CairoFrame");
const COORD = {
    top_left: [-1, -1],
    center_left: [-1, 0],
    bottom_left: [-1, 1],
    top_center: [0, -1],
    center: [0, 0],
    bottom_center: [0, 1],
    top_right: [1, -1],
    center_right: [1, 0],
    bottom_right: [1, 1],
};
class CairoPainter extends CairoFrame_1.default {
    constructor(opt) {
        super(opt);
        this.coAlignment = COORD[opt.coAlignment];
        this.screenWidth = opt.screenWidth;
        this.screenHeight = opt.screenHeight;
    }
    generate(cod, scale = 1) {
        return __awaiter(this, void 0, void 0, function* () {
            const access = yield this.begin(cod, scale);
            this.surface = access[0];
            this.cairo = access[1];
            this.generateOwnImage(cod, this.cairo, 0, 0, scale);
            for (const child of this.children) {
                child.generateImage(cod, this.cairo, [0, 0], scale);
            }
            yield cod.showCairoImage(this.surface, this.convertor(this.coAlignment[0], this.screenWidth, this.posX, scale * this.width), this.convertor(this.coAlignment[1], this.screenHeight, this.posY, scale * this.height));
            yield this.destroy(cod);
        });
    }
    convertor(alignment, screenSize, position, graphicsSize) {
        switch (alignment) {
            case -1:
                return alignment + (2.0 * position) / screenSize;
            case 0:
                return alignment - (2.0 * (position + graphicsSize / 2)) / screenSize;
            case 1:
                return alignment - (2.0 * (position + graphicsSize)) / screenSize;
            default:
                throw new Error('Invalid graphics alignment.');
        }
    }
    begin(cod, scale) {
        return __awaiter(this, void 0, void 0, function* () {
            const surface = (yield cod.cairo('cairo_image_surface_create', 'CAIRO_FORMAT_ARGB32', Math.floor(this.width * scale), Math.floor(this.height * scale)));
            const cairo = (yield cod.cairo('cairo_create', surface.var));
            return [surface.var, cairo.var];
        });
    }
    destroy(cod) {
        return __awaiter(this, void 0, void 0, function* () {
            yield cod.cairo('cairo_surface_destroy', this.surface);
            yield cod.cairo('cairo_destroy', this.cairo);
        });
    }
}
exports.default = CairoPainter;
