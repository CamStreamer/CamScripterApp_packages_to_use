"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoScheduler = void 0;
const utils_1 = require("./utils");
class VideoScheduler {
    constructor(server, googleDrive, camera, generalSettings, serialNumber, settings) {
        this.server = server;
        this.googleDrive = googleDrive;
        this.camera = camera;
        this.generalSettings = generalSettings;
        this.serialNumber = serialNumber;
        this.settings = settings;
        this.recordingIsOngoing = false;
        this.sourceList = this.settings.camera_list;
        this.recordingStatus = false;
    }
    get getRecordingStatus() {
        return this.recordingStatus;
    }
    onBarCodeScan(code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (!this.accidentalRead(code)) {
                    const startRecording = this.willStartRecording(code);
                    if (this.willStopRecording(code)) {
                        this.recordingStatus = false;
                        const result = yield this.delayedMakeVideo();
                        this.clearMetadata();
                        return result;
                    }
                    if (startRecording) {
                        this.recordingStatus = true;
                        this.setMetadata(code);
                    }
                }
                return true;
            }
            catch (err) {
                console.error('Error while processing recording:', err);
                return false;
            }
        });
    }
    shouldShowBarcode(code) {
        let result = true;
        result && (result = !this.accidentalRead(code));
        if (this.settings.closing_barcode_enabled) {
            result && (result = code !== this.settings.closing_barcode);
        }
        if (this.settings.starting_barcode_enabled) {
            return result && code !== this.settings.starting_barcode;
        }
        else {
            return result;
        }
    }
    willStopRecording(code) {
        if (!this.recordingIsOngoing) {
            return false;
        }
        if (this.settings.closing_barcode_enabled) {
            return code === this.settings.closing_barcode;
        }
        if (this.settings.starting_barcode_enabled) {
            return code === this.settings.starting_barcode;
        }
        return true;
    }
    willStartRecording(code) {
        if (!this.willStopRecording(code) && this.recordingIsOngoing) {
            return false;
        }
        if (this.settings.starting_barcode_enabled) {
            return code === this.settings.starting_barcode;
        }
        if (this.settings.closing_barcode_enabled) {
            return code !== this.settings.closing_barcode && code !== this.lastCode;
        }
        return code !== this.lastCode;
    }
    accidentalRead(code) {
        return code === this.lastCode && this.recordingStart !== undefined && Date.now() - this.recordingStart < 3000;
    }
    setMetadata(code) {
        this.recordingIsOngoing = true;
        this.recordingStart = Date.now();
        const startTime = this.recordingStart;
        this.lastCode = code;
        if (this.settings.timeout_enabled) {
            this.timeoutID = setTimeout(() => __awaiter(this, void 0, void 0, function* () { return yield this.onTimeout(startTime, code); }), (this.settings.timeout_sec + this.settings.postbuffer_sec) * 1000);
        }
    }
    onTimeout(startTime, code) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.makeVideo(startTime, code);
            this.clearMetadata();
        });
    }
    delayedMakeVideo() {
        return __awaiter(this, void 0, void 0, function* () {
            const startTime = this.recordingStart;
            const codeToPass = this.lastCode;
            const result = new Promise((resolve) => {
                setTimeout(() => __awaiter(this, void 0, void 0, function* () {
                    const res = yield this.makeVideo(startTime, codeToPass);
                    resolve(res);
                }), this.settings.postbuffer_sec * 1000);
            });
            return yield result;
        });
    }
    clearMetadata() {
        clearTimeout(this.timeoutID);
        this.recordingIsOngoing = false;
        this.timeoutID = undefined;
        this.recordingStart = undefined;
        this.lastCode = undefined;
    }
    downloadVideos(startTime) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const endTime = Date.now();
            const promiseArr = [];
            for (const source of this.sourceList) {
                try {
                    promiseArr.push((_a = this.camera) === null || _a === void 0 ? void 0 : _a.downloadRecording(startTime - this.settings.prebuffer_sec * 1000, endTime, source));
                }
                catch (err) {
                    console.error('Error while downloading video:', err);
                }
            }
            if (promiseArr.length === 0) {
                console.log('Warning: There are no ongoing recordings from selected sources. Nothing will be downloaded nor uploaded.');
            }
            return Promise.all(promiseArr);
        });
    }
    makeVideo(startTime, code) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (startTime === undefined) {
                    throw Error('Cannot download a video, starttime was not set');
                }
                const recordings = yield this.downloadVideos(startTime);
                const promiseArr = [];
                let sourceIter = 0;
                for (const recording of recordings) {
                    if (recording) {
                        const source = this.sourceList[sourceIter];
                        const [ftpRecording, googleDriveRecording] = recording.tee();
                        const recordingName = `${(0, utils_1.createFileName)(code, new Date(), this.serialNumber, source)}.mkv`;
                        if (this.server && this.generalSettings.ftp_server.type === 'video') {
                            promiseArr.push(this.server.queueVideoUpload(ftpRecording, recordingName, code));
                        }
                        if (this.googleDrive && this.generalSettings.google_drive.type === 'video') {
                            promiseArr.push(this.googleDrive.uploadVideo(googleDriveRecording, recordingName, code));
                        }
                        sourceIter += 1;
                    }
                }
                const res = yield Promise.all(promiseArr);
                if (res.includes(false)) {
                    return false;
                }
                else {
                    return true;
                }
            }
            catch (err) {
                console.error('Error while working with video:', err);
                return false;
            }
        });
    }
}
exports.VideoScheduler = VideoScheduler;
