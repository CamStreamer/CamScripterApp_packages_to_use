"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FTPServer = void 0;
const basic_ftp_1 = require("basic-ftp");
const utils_1 = require("../utils");
const stream_1 = require("stream");
class FTPServer {
    constructor(ftpSettings) {
        this.client = new basic_ftp_1.Client(1000 * 60 * 5);
        this.accessOptions = {
            host: ftpSettings.ip,
            port: ftpSettings.port,
            user: ftpSettings.user,
            password: ftpSettings.pass,
            secure: false,
        };
        this.uploadPath = ftpSettings.upload_path;
        if (this.uploadPath[0] !== '/') {
            this.uploadPath = '/' + this.uploadPath;
        }
        this.recordingsBuffer = [];
        this.imageUploadQueue = [];
        this.uploading = false;
    }
    queueVideoUpload(recording, name, code) {
        return __awaiter(this, void 0, void 0, function* () {
            this.recordingsBuffer.push([recording, name]);
            return yield this.uploadRecordings(code, name);
        });
    }
    uploadRecordings(code, recordingName) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.uploading) {
                return false;
            }
            let result = true;
            this.uploading = true;
            console.log(`Uploading recording, code: "${code}", to FTP server...`);
            for (let i = 0; i < this.recordingsBuffer.length; i++) {
                try {
                    const [recording, name] = this.recordingsBuffer[i];
                    if (this.client.closed) {
                        yield this.client.access(this.accessOptions);
                    }
                    yield this.client.uploadFrom(stream_1.Readable.fromWeb(recording), this.uploadPath + '/' + name);
                    console.log(`Recording ${recordingName} uploaded successfully to FTP server.`);
                }
                catch (err) {
                    result = false;
                    console.error(`Error uploading recording ${recordingName} to FTP server:`, err instanceof Error ? err.message : 'unknown');
                }
            }
            this.uploading = false;
            this.recordingsBuffer = [];
            return result;
        });
    }
    queueImageUpload(code, images, serialNumber) {
        return __awaiter(this, void 0, void 0, function* () {
            const baseFileName = (0, utils_1.createFileName)(code, new Date(), serialNumber);
            for (let i = 0; i < images.length; i++) {
                const fileName = `${baseFileName}_camera${images[i].camera + 1}.jpg`;
                this.imageUploadQueue.push([fileName, images[i]]);
            }
            return yield this.uploadImages(code, baseFileName);
        });
    }
    uploadImages(code, baseImageName) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.uploading) {
                return false;
            }
            let result = true;
            this.uploading = true;
            console.log(`Uploading image(s), code: "${code}", to FTP server...`);
            for (let i = 0; i < this.imageUploadQueue.length; i++) {
                try {
                    const [imageName, imageBuffer] = this.imageUploadQueue[i];
                    if (this.client.closed) {
                        yield this.client.access(this.accessOptions);
                    }
                    yield this.client.uploadFrom(stream_1.Readable.from(imageBuffer.file), `${this.uploadPath}/${imageName}`);
                    console.log(`Image(s) ${baseImageName}.jpg uploaded successfully to FTP server.`);
                }
                catch (err) {
                    result = false;
                    console.error(`Error uploading image(s) ${baseImageName}.jpg to FTP server:`, err);
                }
            }
            this.imageUploadQueue = [];
            this.uploading = false;
            return result;
        });
    }
}
exports.FTPServer = FTPServer;
