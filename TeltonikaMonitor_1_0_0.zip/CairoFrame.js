"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const white = [255, 255, 255];
class CairoFrame {
    constructor(opt) {
        var _a, _b, _c, _d;
        this.bg_width = null;
        this.bg_height = null;
        this.posX = opt.x;
        this.posY = opt.y;
        this.width = opt.width;
        this.height = opt.height;
        this.bg_image = (_a = opt.bg) !== null && _a !== void 0 ? _a : null;
        this.text = (_b = opt.text) !== null && _b !== void 0 ? _b : '';
        this.font_color = (_c = opt.font_color) !== null && _c !== void 0 ? _c : [1.0, 1.0, 1.0];
        this.bg_color = (_d = opt.bg_color) !== null && _d !== void 0 ? _d : null;
        this.children = [];
        this.font = null;
        this.fill = true;
        this.bg_type = 'plain';
        this.text_type = 'TFM_OVERFLOW';
        this.align = 'A_LEFT';
    }
    setText(text, align, text_type = 'TFM_OVERFLOW', color = white) {
        this.text = text;
        this.font_color = color;
        this.align = align;
        this.text_type = text_type;
    }
    insert(...frames) {
        this.children.push(...frames);
    }
    insertAll(frames) {
        for (const name in frames) {
            this.insert(frames[name]);
        }
    }
    generateOwnImage(co, cairo, ppX, ppY, scale) {
        const promises = new Array();
        promises.push(co.cairo('cairo_identity_matrix', cairo));
        if (this.font) {
            promises.push(co.cairo('cairo_set_font_face', cairo, this.font));
        }
        if (this.bg_color) {
            promises.push(co.cairo('cairo_set_source_rgba', cairo, this.bg_color[0], this.bg_color[1], this.bg_color[2], this.bg_color[3]));
            promises.push(this.drawFrame(co, cairo));
        }
        if (this.bg_image) {
            if (this.bg_type == 'fit') {
                const sx = this.width / this.bg_width;
                const sy = this.height / this.bg_height;
                promises.push(co.cairo('cairo_scale', cairo, scale * sx, scale * sy));
            }
            else {
                promises.push(co.cairo('cairo_scale', cairo, scale, scale));
            }
            promises.push(co.cairo('cairo_translate', cairo, ppX, ppY));
            promises.push(co.cairo('cairo_set_source_surface', cairo, this.bg_image, 0, 0));
            promises.push(co.cairo('cairo_paint', cairo));
        }
        if (this.text) {
            promises.push(co.cairo('cairo_set_source_rgb', cairo, this.font_color[0], this.font_color[1], this.font_color[2]));
            promises.push(co.writeText(cairo, '' + this.text, Math.floor(scale * this.posX), Math.floor(scale * this.posY), Math.floor(scale * this.width), Math.floor(scale * this.height), this.align, this.text_type));
        }
        return Promise.all(promises);
    }
    generateImage(co, cairo, parentPos, scale = 1) {
        const ppX = parentPos[0];
        const ppY = parentPos[1];
        const promises = new Array();
        promises.push(this.generateOwnImage(co, cairo, this.posX + ppX, this.posY + ppY, scale));
        for (const child of this.children) {
            promises.push(child.generateImage(co, cairo, [this.posX + ppX, this.posY + ppY], scale));
        }
        return Promise.all(promises);
    }
    drawFrame(co, cairo) {
        const degrees = Math.PI / 180.0;
        const radius = 30.0;
        const promises = new Array();
        promises.push(co.cairo('cairo_new_sub_path', cairo));
        promises.push(co.cairo('cairo_arc', cairo, this.posX + this.width - radius, this.posY + radius, radius, -90 * degrees, 0 * degrees));
        promises.push(co.cairo('cairo_arc', cairo, this.posX + this.width - radius, this.posY + this.height - radius, radius, 0 * degrees, 90 * degrees));
        promises.push(co.cairo('cairo_arc', cairo, this.posX + radius, this.posY + this.height - radius, radius, 90 * degrees, 180 * degrees));
        promises.push(co.cairo('cairo_arc', cairo, this.posX + radius, this.posY + radius, radius, 180 * degrees, 270 * degrees));
        promises.push(co.cairo('cairo_close_path', cairo));
        if (this.fill) {
            promises.push(co.cairo('cairo_fill', cairo));
        }
        promises.push(co.cairo('cairo_paint', cairo));
        return Promise.all(promises);
    }
    setFont(fontdata) {
        this.font = fontdata;
    }
    setBgImage(image_data, type) {
        this.bg_image = image_data.var;
        this.bg_width = image_data.width;
        this.bg_height = image_data.height;
        if (type == 'stretch') {
            this.width = this.bg_width;
            this.height = this.bg_height;
        }
        this.bg_type = type;
    }
    removeImage() {
        this.bg_image = null;
        this.bg_width = 0;
        this.bg_height = 0;
    }
}
exports.default = CairoFrame;
