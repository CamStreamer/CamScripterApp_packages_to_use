# Spinel
OpenSource protocol by Papouch company.
## Instruction Format
Spinel has two data formats.
- `a` designates binary communication with precisely defined packets and checksums etc.
- `B` designates text communication
Some isntructions are only available in the `a` format.